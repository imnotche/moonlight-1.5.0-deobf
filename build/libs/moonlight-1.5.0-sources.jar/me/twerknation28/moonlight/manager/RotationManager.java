package me.twerknation28.moonlight.manager;

import java.util.ArrayList;
import org.jetbrains.annotations.NotNull;
import me.twerknation28.moonlight.util.MathUtil;
import java.util.List;
import me.twerknation28.moonlight.util.Rotation;
import me.twerknation28.moonlight.util.Util;
import net.minecraft.class_1297;
import net.minecraft.class_1309;
import net.minecraft.class_1675;
import net.minecraft.class_2338;
import net.minecraft.class_2374;
import net.minecraft.class_238;
import net.minecraft.class_239;
import net.minecraft.class_243;
import net.minecraft.class_2596;
import net.minecraft.class_2828;
import net.minecraft.class_3532;
import net.minecraft.class_3959;
import net.minecraft.class_3966;

public class RotationManager implements Util
{
    private float yaw;
    private float pitch;
    private Rotation rotation;
    private static final List<Rotation> requests;
    
    public void updateRotations() {
        this.yaw = RotationManager.mc.field_1724.method_36454();
        this.pitch = RotationManager.mc.field_1724.method_36455();
    }
    
    public void restoreRotations() {
        RotationManager.mc.field_1724.method_36456(this.yaw);
        RotationManager.mc.field_1724.field_6241 = this.yaw;
        RotationManager.mc.field_1724.method_36457(this.pitch);
    }
    
    public static class_2338 from(final class_2374 vec) {
        return from(vec.method_10216(), vec.method_10214(), vec.method_10215());
    }
    
    public static class_2338 from(final double x, final double y, final double z) {
        return new class_2338((int)Math.floor(x), (int)Math.floor(y), (int)Math.floor(z));
    }
    
    public static class_2338 from(final float x, final float y, final float z) {
        return new class_2338((int)Math.floor(x), (int)Math.floor(y), (int)Math.floor(z));
    }
    
    public static void setPlayerRotations(final float yaw, final float pitch) {
        RotationManager.mc.field_1724.method_36456(yaw);
        RotationManager.mc.field_1724.field_6241 = yaw;
        RotationManager.mc.field_1724.method_36457(pitch);
    }
    
    public void setPlayerYaw(final float yaw) {
        RotationManager.mc.field_1724.method_36456(yaw);
        RotationManager.mc.field_1724.field_6241 = yaw;
    }
    
    public static float[] getRotationsTo(final class_243 src, final class_243 dest) {
        final float yaw = (float)(Math.toDegrees(Math.atan2(dest.method_1020(src).field_1350, dest.method_1020(src).field_1352)) - 90.0);
        final float pitch = (float)Math.toDegrees(-Math.atan2(dest.method_1020(src).field_1351, Math.hypot(dest.method_1020(src).field_1352, dest.method_1020(src).field_1350)));
        return new float[] { class_3532.method_15393(yaw), class_3532.method_15393(pitch) };
    }
    
    public void lookAtPos(final class_2338 pos) {
        final float[] angle = MathUtil.calcAngle(RotationManager.mc.field_1724.method_33571(), new class_243((double)(pos.method_10263() + 0.5f), (double)(pos.method_10264() + 0.5f), (double)(pos.method_10260() + 0.5f)));
        setPlayerRotations(angle[0], angle[1]);
    }
    
    public void lookAtVec3d(final class_243 vec3d) {
        final float[] angle = MathUtil.calcAngle(RotationManager.mc.field_1724.method_33571(), new class_243(vec3d.field_1352, vec3d.field_1351, vec3d.field_1350));
        setPlayerRotations(angle[0], angle[1]);
    }
    
    public void lookAtVec3d(final double x, final double y, final double z) {
        final class_243 vec3d = new class_243(x, y, z);
        this.lookAtVec3d(vec3d);
    }
    
    public void lookAtEntity(final class_1297 entity) {
        final float[] angle = MathUtil.calcAngle(RotationManager.mc.field_1724.method_33571(), entity.method_33571());
        setPlayerRotations(angle[0], angle[1]);
    }
    
    public static class_1297 getCrosshairTarget(final float yaw, final float pitch, final float distance, final boolean ignoreWalls) {
        class_1297 targetedEntity = null;
        final class_239 result = ignoreWalls ? null : rayTrace(distance, yaw, pitch);
        final class_243 vec3d = RotationManager.mc.field_1724.method_19538().method_1031(0.0, (double)RotationManager.mc.field_1724.method_18381(RotationManager.mc.field_1724.method_18376()), 0.0);
        double distancePow2 = Math.pow(distance, 2.0);
        if (result != null) {
            distancePow2 = result.method_17784().method_1025(vec3d);
        }
        final class_243 vec3d2 = getRotationVector(pitch, yaw);
        final class_243 vec3d3 = vec3d.method_1031(vec3d2.field_1352 * distance, vec3d2.field_1351 * distance, vec3d2.field_1350 * distance);
        final class_238 box = RotationManager.mc.field_1724.method_5829().method_18804(vec3d2.method_1021((double)distance)).method_1009(1.0, 1.0, 1.0);
        final class_3966 entityHitResult = class_1675.method_18075((class_1297)RotationManager.mc.field_1724, vec3d, vec3d3, box, entity -> !entity.method_7325() && entity.method_5863(), distancePow2);
        if (entityHitResult != null) {
            final class_1297 entity2 = entityHitResult.method_17782();
            final class_243 vec3d4 = entityHitResult.method_17784();
            final double g = vec3d.method_1025(vec3d4);
            if ((g < distancePow2 || result == null) && entity2 instanceof class_1309) {
                targetedEntity = entity2;
                return targetedEntity;
            }
        }
        return targetedEntity;
    }
    
    @NotNull
    public static class_243 getRotationVector(final float yaw, final float pitch) {
        return new class_243((double)(class_3532.method_15374(-pitch * 0.017453292f) * class_3532.method_15362(yaw * 0.017453292f)), (double)(-class_3532.method_15374(yaw * 0.017453292f)), (double)(class_3532.method_15362(-pitch * 0.017453292f) * class_3532.method_15362(yaw * 0.017453292f)));
    }
    
    public static class_239 rayTrace(final double dst, final float yaw, final float pitch) {
        final class_243 vec3d = RotationManager.mc.field_1724.method_5836(1.0f);
        final class_243 vec3d2 = getRotationVector(pitch, yaw);
        final class_243 vec3d3 = vec3d.method_1031(vec3d2.field_1352 * dst, vec3d2.field_1351 * dst, vec3d2.field_1350 * dst);
        return (class_239)RotationManager.mc.field_1687.method_17742(new class_3959(vec3d, vec3d3, class_3959.class_3960.field_17559, class_3959.class_242.field_1348, (class_1297)RotationManager.mc.field_1724));
    }
    
    public static void setRotationSilentSync(final boolean grim) {
        final float yaw = RotationManager.mc.field_1724.method_36454();
        final float pitch = RotationManager.mc.field_1724.method_36455();
        if (grim) {
            setRotation(new Rotation(Integer.MAX_VALUE, yaw, pitch, true));
            NetworkManager.sendPacket((class_2596<?>)new class_2828.class_2830(RotationManager.mc.field_1724.method_23317(), RotationManager.mc.field_1724.method_23318(), RotationManager.mc.field_1724.method_23321(), yaw, pitch, RotationManager.mc.field_1724.method_24828()));
        }
        else {
            NetworkManager.sendPacket((class_2596<?>)new class_2828.class_2831(yaw, pitch, RotationManager.mc.field_1724.method_24828()));
        }
    }
    
    public static void setRotation(Rotation rotation) {
        if (rotation.getPriority() == Integer.MAX_VALUE) {
            rotation = rotation;
        }
        final Rotation finalRotation = rotation;
        final Rotation request = RotationManager.requests.stream().filter(r -> finalRotation.getPriority() == r.getPriority()).findFirst().orElse(null);
        if (request == null) {
            RotationManager.requests.add(rotation);
        }
        else {
            request.setYaw(rotation.getYaw());
            request.setPitch(rotation.getPitch());
        }
    }
    
    public static void setRotationSilent(final float yaw, final float pitch, final boolean grim) {
        if (grim) {
            setRotation(new Rotation(Integer.MAX_VALUE, yaw, pitch, true));
            NetworkManager.sendPacket((class_2596<?>)new class_2828.class_2830(RotationManager.mc.field_1724.method_23317(), RotationManager.mc.field_1724.method_23318(), RotationManager.mc.field_1724.method_23321(), yaw, pitch, RotationManager.mc.field_1724.method_24828()));
        }
        else {
            NetworkManager.sendPacket((class_2596<?>)new class_2828.class_2831(yaw, pitch, RotationManager.mc.field_1724.method_24828()));
        }
    }
    
    public void setPlayerPitch(final float pitch) {
        RotationManager.mc.field_1724.method_36457(pitch);
    }
    
    public float getYaw() {
        return this.yaw;
    }
    
    public void setYaw(final float yaw) {
        this.yaw = yaw;
    }
    
    public float getPitch() {
        return this.pitch;
    }
    
    public void setPitch(final float pitch) {
        this.pitch = pitch;
    }
    
    static {
        requests = new ArrayList<Rotation>();
    }
}
