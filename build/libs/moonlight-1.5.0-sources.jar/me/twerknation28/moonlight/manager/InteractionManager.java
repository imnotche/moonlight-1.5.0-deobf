package me.twerknation28.moonlight.manager;

import java.util.Iterator;
import java.util.HashSet;
import java.util.Set;
import me.twerknation28.moonlight.util.Util;
import net.minecraft.class_1292;
import net.minecraft.class_1294;
import net.minecraft.class_1309;
import net.minecraft.class_1657;
import net.minecraft.class_1799;
import net.minecraft.class_1890;
import net.minecraft.class_1893;
import net.minecraft.class_1922;
import net.minecraft.class_2338;
import net.minecraft.class_2350;
import net.minecraft.class_238;
import net.minecraft.class_243;
import net.minecraft.class_265;
import net.minecraft.class_2680;
import net.minecraft.class_3486;
import net.minecraft.class_6880;
import net.minecraft.class_9304;

public class InteractionManager implements Util
{
    public static class_2350 getPlaceDirectionGrim(final class_2338 blockPos) {
        final Set<class_2350> directions = getPlaceDirectionsGrim(InteractionManager.mc.field_1724.method_19538(), blockPos);
        return directions.stream().findAny().orElse(class_2350.field_11036);
    }
    
    public static Set<class_2350> getPlaceDirectionsGrim(final class_243 eyePos, final class_2338 blockPos) {
        return getPlaceDirectionsGrim(eyePos.field_1352, eyePos.field_1351, eyePos.field_1350, blockPos);
    }
    
    public static Set<class_2350> getPlaceDirectionsGrim(final double x, final double y, final double z, final class_2338 pos) {
        final Set<class_2350> dirs = new HashSet<class_2350>(6);
        final class_238 combined = getCombinedBox(pos);
        final class_238 eyePositions = new class_238(x, y + 0.4, z, x, y + 1.62, z).method_1014(2.0E-4);
        if (eyePositions.field_1321 <= combined.field_1321) {
            dirs.add(class_2350.field_11043);
        }
        if (eyePositions.field_1324 >= combined.field_1324) {
            dirs.add(class_2350.field_11035);
        }
        if (eyePositions.field_1320 >= combined.field_1320) {
            dirs.add(class_2350.field_11034);
        }
        if (eyePositions.field_1323 <= combined.field_1323) {
            dirs.add(class_2350.field_11039);
        }
        if (eyePositions.field_1325 >= combined.field_1325) {
            dirs.add(class_2350.field_11036);
        }
        if (eyePositions.field_1322 <= combined.field_1322) {
            dirs.add(class_2350.field_11033);
        }
        return dirs;
    }
    
    private static class_238 getCombinedBox(final class_2338 pos) {
        final class_265 shape = InteractionManager.mc.field_1687.method_8320(pos).method_26220((class_1922)InteractionManager.mc.field_1687, pos).method_1096((double)pos.method_10263(), (double)pos.method_10264(), (double)pos.method_10260());
        class_238 combined = new class_238(pos);
        for (final class_238 box : shape.method_1090()) {
            final double minX = Math.max(box.field_1323, combined.field_1323);
            final double minY = Math.max(box.field_1322, combined.field_1322);
            final double minZ = Math.max(box.field_1321, combined.field_1321);
            final double maxX = Math.min(box.field_1320, combined.field_1320);
            final double maxY = Math.min(box.field_1325, combined.field_1325);
            final double maxZ = Math.min(box.field_1324, combined.field_1324);
            combined = new class_238(minX, minY, minZ, maxX, maxY, maxZ);
        }
        return combined;
    }
    
    public static float calcBlockBreakingDelta(final class_2680 state, final class_1922 world, final class_2338 pos) {
        final float f = state.method_26214(world, pos);
        if (f == -1.0f) {
            return 0.0f;
        }
        final int i = canHarvest(state) ? 30 : 100;
        return getBlockBreakingSpeed(state) / f / i;
    }
    
    private static boolean canHarvest(final class_2680 state) {
        if (state.method_29291()) {
            final int tool = InventoryManager.getBestTool(state);
            return InteractionManager.mc.field_1724.method_31548().method_5438(tool).method_7951(state);
        }
        return true;
    }
    
    private static float getBlockBreakingSpeed(final class_2680 block) {
        final int tool = InventoryManager.getBestTool(block);
        float f = InteractionManager.mc.field_1724.method_31548().method_5438(tool).method_7924(block);
        if (f > 1.0f) {
            final class_1799 stack = InteractionManager.mc.field_1724.method_31548().method_5438(tool);
            final int i = class_1890.method_8225((class_6880)InteractionManager.mc.field_1687.method_30349().method_30530(class_1893.field_9131.method_58273()).method_40264(class_1893.field_9131).get(), stack);
            if (i > 0 && !stack.method_7960()) {
                f += i * i + 1;
            }
        }
        if (class_1292.method_5576((class_1309)InteractionManager.mc.field_1724)) {
            f *= 1.0f + (class_1292.method_5575((class_1309)InteractionManager.mc.field_1724) + 1) * 0.2f;
        }
        if (InteractionManager.mc.field_1724.method_6059(class_1294.field_5901)) {
            float var10000 = 0.0f;
            switch (InteractionManager.mc.field_1724.method_6112(class_1294.field_5901).method_5578()) {
                case 0: {
                    var10000 = 0.3f;
                    break;
                }
                case 1: {
                    var10000 = 0.09f;
                    break;
                }
                case 2: {
                    var10000 = 0.0027f;
                    break;
                }
                default: {
                    var10000 = 8.1E-4f;
                    break;
                }
            }
            final float g = var10000;
            f *= g;
        }
        if (InteractionManager.mc.field_1724.method_5777(class_3486.field_15517) && !hasAquaAffinity((class_1657)InteractionManager.mc.field_1724)) {
            f /= 5.0f;
        }
        if (!InteractionManager.mc.field_1724.method_24828()) {
            f /= 5.0f;
        }
        return f;
    }
    
    public static boolean hasAquaAffinity(final class_1657 player) {
        for (final class_1799 armor : player.method_5661()) {
            final class_9304 enchants = class_1890.method_57532(armor);
            if (enchants.method_57534().contains(InteractionManager.mc.field_1687.method_30349().method_30530(class_1893.field_9105.method_58273()).method_40264(class_1893.field_9111).get())) {
                return true;
            }
        }
        return false;
    }
}
