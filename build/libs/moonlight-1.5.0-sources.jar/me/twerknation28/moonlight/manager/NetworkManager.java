package me.twerknation28.moonlight.manager;

import java.util.HashSet;
import java.util.Objects;
import me.twerknation28.moonlight.mixin.accessor.AccessorClientWorld;
import java.util.Set;
import me.twerknation28.moonlight.util.Util;
import net.minecraft.class_2596;
import net.minecraft.class_2792;
import net.minecraft.class_7202;
import net.minecraft.class_7204;

public class NetworkManager implements Util
{
    private static final Set<class_2596<?>> PACKET_CACHE;
    
    public static void sendPacket(final class_2596<?> p) {
        if (NetworkManager.mc.method_1562() != null) {
            NetworkManager.PACKET_CACHE.add(p);
            NetworkManager.mc.method_1562().method_52787((class_2596)p);
        }
    }
    
    public static void sendSequencedPacket(final class_7204 o) {
        if (NetworkManager.mc.field_1687 != null) {
            final class_7202 updater = ((AccessorClientWorld)NetworkManager.mc.field_1687).hookGetPendingUpdateManager().method_41937();
            try {
                final int i = updater.method_41942();
                final class_2596<class_2792> packet = (class_2596<class_2792>)o.predict(i);
                Objects.requireNonNull(NetworkManager.mc.method_1562()).method_52787((class_2596)packet);
            }
            catch (final Throwable e) {
                e.printStackTrace();
                if (updater != null) {
                    try {
                        updater.close();
                    }
                    catch (final Throwable e2) {
                        e2.printStackTrace();
                        e.addSuppressed(e2);
                    }
                }
                throw e;
            }
            if (updater != null) {
                updater.close();
            }
        }
    }
    
    public static boolean isCached(final class_2596<?> p) {
        return NetworkManager.PACKET_CACHE.contains(p);
    }
    
    static {
        PACKET_CACHE = new HashSet<class_2596<?>>();
    }
}
