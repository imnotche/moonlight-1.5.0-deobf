package me.twerknation28.moonlight.manager;

import java.util.HashSet;
import java.util.Iterator;
import java.util.ArrayList;
import it.unimi.dsi.fastutil.ints.Int2ObjectMap;
import it.unimi.dsi.fastutil.ints.Int2ObjectOpenHashMap;
import com.google.common.collect.Lists;
import me.twerknation28.moonlight.mixin.accessor.AccessorInteractionManager;
import me.twerknation28.moonlight.event.EventListener;
import me.twerknation28.moonlight.event.impl.PacketEvent;
import java.util.Set;
import me.twerknation28.moonlight.util.Util;
import net.minecraft.class_1657;
import net.minecraft.class_1661;
import net.minecraft.class_1703;
import net.minecraft.class_1713;
import net.minecraft.class_1735;
import net.minecraft.class_1792;
import net.minecraft.class_1799;
import net.minecraft.class_1831;
import net.minecraft.class_1890;
import net.minecraft.class_1893;
import net.minecraft.class_2371;
import net.minecraft.class_2596;
import net.minecraft.class_2680;
import net.minecraft.class_2735;
import net.minecraft.class_2813;
import net.minecraft.class_2868;
import net.minecraft.class_6880;

public class InventoryManager implements Util
{
    public static int slot;
    public static int previousSlot;
    private static final Set<class_2596<?>> PACKET_CACHE;
    
    @EventListener
    public static void onPacketSend(final PacketEvent.Send event) {
        final class_2596<?> packet2 = event.getPacket();
        if (packet2 instanceof final class_2868 packet) {
            InventoryManager.slot = packet.method_12442();
        }
    }
    
    @EventListener
    public static void onPacketReceive(final PacketEvent.Receive event) {
        final class_2596<?> packet2 = event.getPacket();
        if (packet2 instanceof final class_2735 packet) {
            InventoryManager.slot = packet.method_11803();
        }
    }
    
    public static void setSlot(final int barSlot) {
        if (InventoryManager.mc.field_1724.method_31548().field_7545 != barSlot && class_1661.method_7380(barSlot)) {
            setSlotForced(barSlot);
        }
    }
    
    public static void syncToClient() {
        if (isDesynced()) {
            setSlotForced(InventoryManager.mc.field_1724.method_31548().field_7545);
        }
    }
    
    public static void syncLoud() {
        if (isDesynced()) {
            setSlotLoud(InventoryManager.previousSlot);
        }
    }
    
    public static boolean isDesynced() {
        return InventoryManager.mc.field_1724.method_31548().field_7545 != InventoryManager.slot;
    }
    
    public static void setSlotForced(final int barSlot) {
        final class_2596<?> p = (class_2596<?>)new class_2868(barSlot);
        if (InventoryManager.mc.method_1562() != null) {
            InventoryManager.PACKET_CACHE.add(p);
            NetworkManager.sendPacket(p);
        }
    }
    
    public static void setSlotLoud(final int barSlot) {
        if (InventoryManager.mc.field_1724.method_31548().field_7545 == barSlot && InventoryManager.slot == barSlot) {
            return;
        }
        if (InventoryManager.previousSlot != barSlot) {
            InventoryManager.previousSlot = InventoryManager.mc.field_1724.method_31548().field_7545;
        }
        InventoryManager.mc.field_1724.method_31548().field_7545 = barSlot;
        ((AccessorInteractionManager)InventoryManager.mc.field_1761).syncSlot();
    }
    
    public static void swapBack() {
        if ((InventoryManager.mc.field_1724.method_31548().field_7545 == InventoryManager.previousSlot && InventoryManager.slot == InventoryManager.previousSlot) || InventoryManager.previousSlot == -1) {
            return;
        }
        InventoryManager.mc.field_1724.method_31548().field_7545 = InventoryManager.previousSlot;
        ((AccessorInteractionManager)InventoryManager.mc.field_1761).syncSlot();
    }
    
    private static void click(final int slot, final int button, final class_1713 type) {
        final class_1703 screenHandler = InventoryManager.mc.field_1724.field_7512;
        final class_2371<class_1735> defaultedList = (class_2371<class_1735>)screenHandler.field_7761;
        final int i = defaultedList.size();
        final ArrayList<class_1799> list = Lists.newArrayListWithCapacity(i);
        for (final class_1735 slot2 : defaultedList) {
            list.add(slot2.method_7677().method_7972());
        }
        screenHandler.method_7593(slot, button, type, (class_1657)InventoryManager.mc.field_1724);
        final Int2ObjectOpenHashMap<class_1799> int2ObjectMap = (Int2ObjectOpenHashMap<class_1799>)new Int2ObjectOpenHashMap();
        for (int j = 0; j < i; ++j) {
            final class_1799 itemStack = list.get(j);
            final class_1799 itemStack2;
            if (!class_1799.method_7973(itemStack, itemStack2 = ((class_1735)defaultedList.get(j)).method_7677())) {
                int2ObjectMap.put(j, (class_1799) itemStack2.method_7972());
            }
        }
        InventoryManager.mc.field_1724.field_3944.method_52787((class_2596)new class_2813(screenHandler.field_7763, screenHandler.method_37421(), slot, button, type, screenHandler.method_34255().method_7972(), (Int2ObjectMap)int2ObjectMap));
    }
    
    public static void pickupSlot(final int slot) {
        click(slot, 0, class_1713.field_7790);
    }
    
    public static int getBestTool(final class_2680 state) {
        final int slot = getBestToolNoFallback(state);
        return (slot != -1) ? slot : InventoryManager.mc.field_1724.method_31548().field_7545;
    }
    
    public static int getBestToolNoFallback(final class_2680 state) {
        int slot = -1;
        float bestTool = 0.0f;
        for (int i = 0; i < 9; ++i) {
            final class_1799 stack = InventoryManager.mc.field_1724.method_31548().method_5438(i);
            if (!stack.method_7960() && stack.method_7909() instanceof class_1831) {
                float speed = stack.method_7924(state);
                final int efficiency = class_1890.method_8225((class_6880)InventoryManager.mc.field_1687.method_30349().method_30530(class_1893.field_9131.method_58273()).method_40264(class_1893.field_9131).get(), stack);
                if (efficiency > 0) {
                    speed += efficiency * efficiency + 1.0f;
                }
                if (speed > bestTool) {
                    bestTool = speed;
                    slot = i;
                }
            }
        }
        return slot;
    }
    
    public static boolean isHolding(final class_1792 item) {
        class_1799 itemStack = InventoryManager.mc.field_1724.method_6047();
        if (!itemStack.method_7960() && itemStack.method_7909() == item) {
            return true;
        }
        itemStack = InventoryManager.mc.field_1724.method_6079();
        return !itemStack.method_7960() && itemStack.method_7909() == item;
    }
    
    static {
        InventoryManager.previousSlot = -1;
        PACKET_CACHE = new HashSet<class_2596<?>>();
    }
}
