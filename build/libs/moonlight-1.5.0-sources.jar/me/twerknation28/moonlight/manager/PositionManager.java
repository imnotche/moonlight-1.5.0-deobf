package me.twerknation28.moonlight.manager;

import java.util.ArrayList;
import java.util.List;
import me.twerknation28.moonlight.features.Feature;
import net.minecraft.class_2338;
import net.minecraft.class_238;
import net.minecraft.class_2596;
import net.minecraft.class_2828;

public class PositionManager extends Feature
{
    private double x;
    private double y;
    private double z;
    private boolean onground;
    
    public void updatePosition() {
        this.x = PositionManager.mc.field_1724.method_23317();
        this.y = PositionManager.mc.field_1724.method_23318();
        this.z = PositionManager.mc.field_1724.method_23321();
        this.onground = PositionManager.mc.field_1724.method_24828();
    }
    
    public void restorePosition() {
        PositionManager.mc.field_1724.method_5814(this.x, this.y, this.z);
        PositionManager.mc.field_1724.method_24830(this.onground);
    }
    
    public void setPlayerPosition(final double x, final double y, final double z) {
        PositionManager.mc.field_1724.method_5814(x, y, z);
    }
    
    public void setPlayerPosition(final double x, final double y, final double z, final boolean onground) {
        PositionManager.mc.field_1724.method_5814(x, y, z);
        PositionManager.mc.field_1724.method_24830(onground);
    }
    
    public static class_2338 getPlayerPos() {
        assert PositionManager.mc.field_1724 != null;
        return new class_2338(PositionManager.mc.field_1724.method_31477(), PositionManager.mc.field_1724.method_31478(), PositionManager.mc.field_1724.method_31479());
    }
    
    public void setPositionPacket(final double x, final double y, final double z, final boolean onGround, final boolean setPos, final boolean noLagBack) {
        PositionManager.mc.field_1724.field_3944.method_52787((class_2596)new class_2828.class_2829(x, y, z, onGround));
        if (setPos) {
            PositionManager.mc.field_1724.method_5814(x, y, z);
            if (noLagBack) {
                this.updatePosition();
            }
        }
    }
    
    public static List<class_2338> getAllInBox(final class_238 box, final class_2338 pos) {
        final List<class_2338> intersections = new ArrayList<class_2338>();
        for (int x = (int)Math.floor(box.field_1323); x < Math.ceil(box.field_1320); ++x) {
            for (int z = (int)Math.floor(box.field_1321); z < Math.ceil(box.field_1324); ++z) {
                intersections.add(new class_2338(x, pos.method_10264(), z));
            }
        }
        return intersections;
    }
    
    public static List<class_2338> getAllInBox(final class_238 box) {
        final List<class_2338> intersections = new ArrayList<class_2338>();
        for (int x = (int)Math.floor(box.field_1323); x < Math.ceil(box.field_1320); ++x) {
            for (int y = (int)Math.floor(box.field_1322); y < Math.ceil(box.field_1325); ++y) {
                for (int z = (int)Math.floor(box.field_1321); z < Math.ceil(box.field_1324); ++z) {
                    intersections.add(new class_2338(x, y, z));
                }
            }
        }
        return intersections;
    }
    
    public double getX() {
        return this.x;
    }
    
    public void setX(final double x) {
        this.x = x;
    }
    
    public double getY() {
        return this.y;
    }
    
    public void setY(final double y) {
        this.y = y;
    }
    
    public double getZ() {
        return this.z;
    }
    
    public void setZ(final double z) {
        this.z = z;
    }
}
