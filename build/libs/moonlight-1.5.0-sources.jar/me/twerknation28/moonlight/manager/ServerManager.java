package me.twerknation28.moonlight.manager;

import java.util.Arrays;
import java.util.Iterator;
import java.util.Collection;
import java.util.ArrayList;
import net.fabricmc.fabric.api.networking.v1.PlayerLookup;
import net.minecraft.class_1297;
import net.minecraft.class_1657;
import net.minecraft.class_1937;
import net.minecraft.class_2596;
import net.minecraft.class_2663;
import net.minecraft.class_3218;
import net.minecraft.class_3222;
import java.util.List;
import me.twerknation28.moonlight.event.impl.TotemPopEvent;
import me.twerknation28.moonlight.event.impl.PacketEvent;
import java.util.HashMap;
import me.twerknation28.moonlight.util.models.Timer;
import java.text.DecimalFormat;
import me.twerknation28.moonlight.features.Feature;

public class ServerManager extends Feature
{
    private final float[] tpsCounts;
    private final DecimalFormat format;
    private final Timer timer;
    private float TPS;
    private long lastUpdate;
    private String serverBrand;
    public static HashMap<String, Integer> popList;
    
    public ServerManager() {
        this.tpsCounts = new float[10];
        this.format = new DecimalFormat("##.00#");
        this.timer = new Timer();
        this.TPS = 20.0f;
        this.lastUpdate = -1L;
        this.serverBrand = "";
    }
    
    public void onPacketReceived() {
        this.timer.reset();
    }
    
    public void onPacketReceive(final PacketEvent.Receive event) {
        final class_2596<?> packet2 = event.getPacket();
        if (packet2 instanceof final class_2663 pac) {
            if (pac.method_11470() == 35) {
                final class_1297 ent = pac.method_11469((class_1937)ServerManager.mc.field_1687);
                if (!(ent instanceof class_1657)) {
                    return;
                }
                if (ServerManager.popList == null) {
                    ServerManager.popList = new HashMap<String, Integer>();
                }
                if (ServerManager.popList.get(ent.method_5477().getString()) == null) {
                    ServerManager.popList.put(ent.method_5477().getString(), 1);
                }
                else if (ServerManager.popList.get(ent.method_5477().getString()) != null) {
                    ServerManager.popList.put(ent.method_5477().getString(), ServerManager.popList.get(ent.method_5477().getString()) + 1);
                }
                final class_2663 packet = (class_2663)event.getPacket();
                final class_1297 entity = packet.method_11469((class_1937)ServerManager.mc.field_1687);
                if (entity instanceof class_1657 && packet.method_11470() == 35) {
                    final class_1657 player = (class_1657)entity;
                    ServerManager.EVENT_BUS.post(new TotemPopEvent(player, ServerManager.popList.get(player.method_5477().getString())));
                }
            }
        }
    }
    
    public List<class_3222> getPlayersInRenderDistance(final class_3222 sourcePlayer) {
        final class_3218 world = (class_3218)sourcePlayer.method_37908();
        return new ArrayList<class_3222>(PlayerLookup.tracking((class_1297)sourcePlayer));
    }
    
    public boolean isServerNotResponding() {
        return this.timer.passedMs(2000L);
    }
    
    public long serverRespondingTime() {
        return this.timer.getPassedTimeMs();
    }
    
    public void update() {
        for (final class_1657 player : ServerManager.mc.field_1687.method_18456()) {
            if (player.method_6032() <= 0.0f && ServerManager.popList.containsKey(player.method_5477().getString())) {
                ServerManager.popList.remove(player.method_5477().getString(), ServerManager.popList.get(player.method_5477().getString()));
            }
        }
        final long currentTime = System.currentTimeMillis();
        if (this.lastUpdate == -1L) {
            this.lastUpdate = currentTime;
            return;
        }
        final long timeDiff = currentTime - this.lastUpdate;
        float tickTime = timeDiff / 20.0f;
        if (tickTime == 0.0f) {
            tickTime = 50.0f;
        }
        float tps;
        if ((tps = 1000.0f / tickTime) > 20.0f) {
            tps = 20.0f;
        }
        System.arraycopy(this.tpsCounts, 0, this.tpsCounts, 1, this.tpsCounts.length - 1);
        this.tpsCounts[0] = tps;
        double total = 0.0;
        for (final float f : this.tpsCounts) {
            total += f;
        }
        if ((total /= this.tpsCounts.length) > 20.0) {
            total = 20.0;
        }
        this.TPS = Float.parseFloat(this.format.format(total).replace(",", "."));
        this.lastUpdate = currentTime;
    }
    
    @Override
    public void reset() {
        Arrays.fill(this.tpsCounts, 20.0f);
        this.TPS = 20.0f;
    }
    
    public float getTpsFactor() {
        return 20.0f / this.TPS;
    }
    
    public float getTPS() {
        return this.TPS;
    }
    
    public String getServerBrand() {
        return this.serverBrand;
    }
    
    public void setServerBrand(final String brand) {
        this.serverBrand = brand;
    }
    
    public static int getPing() {
        if (fullNullCheck()) {
            return 0;
        }
        try {
            return ServerManager.mc.method_1562().method_2874(ServerManager.mc.field_1724.method_7334().getName()).method_2959();
        }
        catch (final Throwable e) {
            return 0;
        }
    }
    
    static {
        ServerManager.popList = new HashMap<String, Integer>();
    }
}
