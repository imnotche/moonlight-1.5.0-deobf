package me.twerknation28.moonlight.manager;

import java.util.concurrent.CopyOnWriteArrayList;
import java.util.Collection;
import java.util.LinkedList;
import org.jetbrains.annotations.Nullable;
import java.util.Iterator;
import com.google.common.eventbus.Subscribe;
import me.twerknation28.moonlight.event.impl.UpdateEvent;
import java.util.ArrayList;
import java.util.List;
import me.twerknation28.moonlight.features.Feature;
import net.minecraft.class_1297;
import net.minecraft.class_1303;
import net.minecraft.class_1511;
import net.minecraft.class_1542;
import net.minecraft.class_2246;
import net.minecraft.class_2248;
import net.minecraft.class_2338;
import net.minecraft.class_2350;
import net.minecraft.class_238;

public class HoleManager extends Feature
{
    private final int range = 8;
    private final List<Hole> holes;
    private final class_2338.class_2339 pos;
    
    public HoleManager() {
        this.holes = new ArrayList<Hole>();
        this.pos = new class_2338.class_2339();
        HoleManager.EVENT_BUS.register(this);
    }
    
    @Subscribe
    private void onTick(final UpdateEvent event) {
        this.holes.clear();
        for (int x = -8; x < 8; ++x) {
            for (int y = -8; y < 8; ++y) {
                for (int z = -8; z < 8; ++z) {
                    this.pos.method_10102(HoleManager.mc.field_1724.method_23317() + x, HoleManager.mc.field_1724.method_23318() + y, HoleManager.mc.field_1724.method_23321() + z);
                    final Hole hole = this.getHole((class_2338)this.pos);
                    if (hole != null) {
                        this.holes.add(hole);
                    }
                }
            }
        }
    }
    
    @Nullable
    public Hole getHole(final class_2338 pos) {
        if (HoleManager.mc.field_1687.method_8320(pos).method_26204() != class_2246.field_10124) {
            return null;
        }
        HoleType type = HoleType.BEDROCK;
        for (final class_2350 direction : class_2350.class_2353.field_11062) {
            final class_2248 block = HoleManager.mc.field_1687.method_8320(pos.method_10093(direction)).method_26204();
            if (block == class_2246.field_10540) {
                type = HoleType.UNSAFE;
            }
            else {
                if (block != class_2246.field_9987) {
                    return null;
                }
                continue;
            }
        }
        return new Hole(pos, type);
    }
    
    public static List<class_2338> getSurroundEntities(final class_1297 entity) {
        final List<class_2338> entities = new LinkedList<class_2338>();
        entities.add(entity.method_24515());
        for (final class_2350 dir : class_2350.values()) {
            if (dir.method_10166().method_10179()) {
                for (final class_2338 pos : PositionManager.getAllInBox(entity.method_5829(), entity.method_24515())) {
                    if (!entities.contains(pos)) {
                        entities.add(pos);
                    }
                }
            }
        }
        return entities;
    }
    
    public List<class_2338> getSurroundEntities(final class_2338 pos) {
        final List<class_2338> entities = new LinkedList<class_2338>();
        entities.add(pos);
        for (final class_2350 dir : class_2350.values()) {
            if (dir.method_10166().method_10179()) {
                final class_2338 pos2 = pos.method_10081(dir.method_10163());
                final List<class_1297> box = HoleManager.mc.field_1687.method_8335((class_1297)null, new class_238(pos2)).stream().filter(e -> !this.isEntityBlockingSurround(e)).toList();
                if (!box.isEmpty()) {
                    for (final class_1297 entity : box) {
                        entities.addAll(PositionManager.getAllInBox(entity.method_5829(), pos));
                    }
                }
            }
        }
        return entities;
    }
    
    public boolean isEntityBlockingSurround(final class_1297 entity) {
        return entity instanceof class_1542 || entity instanceof class_1303 || entity instanceof class_1511;
    }
    
    public static List<class_2338> getEntitySurroundNoSupport(final class_1297 entity) {
        final List<class_2338> entities = getSurroundEntities(entity);
        final List<class_2338> blocks = new CopyOnWriteArrayList<class_2338>();
        for (final class_2338 epos : entities) {
            for (final class_2350 dir2 : class_2350.values()) {
                if (dir2.method_10166().method_10179()) {
                    final class_2338 pos2 = epos.method_10081(dir2.method_10163());
                    if (!entities.contains(pos2) && !blocks.contains(pos2)) {
                        final double dist = HoleManager.mc.field_1724.method_5707(pos2.method_46558());
                        if (dist <= 16.0) {
                            blocks.add(pos2);
                        }
                    }
                }
            }
        }
        return blocks;
    }
    
    record Hole(class_2338 pos, HoleType holeType) {}
    
    private enum HoleType
    {
        BEDROCK, 
        UNSAFE;
    }
}
