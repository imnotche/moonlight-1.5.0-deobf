package me.twerknation28.moonlight.mixin;

import org.spongepowered.asm.mixin.injection.At;
import org.spongepowered.asm.mixin.injection.Inject;
import me.twerknation28.moonlight.util.Util;
import net.minecraft.class_2535;
import net.minecraft.class_2596;
import net.minecraft.class_2598;
import net.minecraft.class_7648;
import me.twerknation28.moonlight.event.impl.PacketEvent;
import org.spongepowered.asm.mixin.injection.callback.CallbackInfo;
import io.netty.channel.ChannelHandlerContext;
import org.spongepowered.asm.mixin.Final;
import org.spongepowered.asm.mixin.Shadow;
import io.netty.channel.Channel;
import org.spongepowered.asm.mixin.Mixin;

@Mixin({ class_2535.class })
public class MixinClientConnection
{
    @Shadow
    private Channel channel;
    @Shadow
    @Final
    private class_2598 side;
    
    @Inject(method = { "channelRead0" }, at = { @At("HEAD") }, cancellable = true)
    public void channelRead0(final ChannelHandlerContext chc, final class_2596<?> packet, final CallbackInfo ci) {
        if (this.channel.isOpen() && packet != null) {
            try {
                final PacketEvent.Receive event = new PacketEvent.Receive(packet);
                Util.EVENT_BUS.post(event);
                if (event.isCancelled()) {
                    ci.cancel();
                }
            }
            catch (final Exception ex) {}
        }
    }
    
    @Inject(method = { "sendImmediately" }, at = { @At("HEAD") }, cancellable = true)
    private void sendImmediately(final class_2596<?> packet, final class_7648 callbacks, final boolean flush, final CallbackInfo ci) {
        if (this.side != class_2598.field_11942) {
            return;
        }
        try {
            final PacketEvent.Send event = new PacketEvent.Send(packet);
            Util.EVENT_BUS.post(event);
            if (event.isCancelled()) {
                ci.cancel();
            }
        }
        catch (final Exception ex) {}
    }
}
