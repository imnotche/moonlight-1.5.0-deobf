package me.twerknation28.moonlight.mixin;

import org.spongepowered.asm.mixin.injection.At;
import org.spongepowered.asm.mixin.injection.Inject;
import me.twerknation28.moonlight.features.modules.render.NoRender;
import net.minecraft.class_332;
import net.minecraft.class_374;
import org.spongepowered.asm.mixin.injection.callback.CallbackInfo;
import org.spongepowered.asm.mixin.Mixin;

@Mixin({ class_374.class })
public abstract class MixinToastManager
{
    @Inject(method = { "draw" }, at = { @At("HEAD") }, cancellable = true)
    public void drawHook(final class_332 context, final CallbackInfo ci) {
        if (NoRender.getInstance().toasts.getValue() && NoRender.getInstance().isEnabled()) {
            ci.cancel();
        }
    }
}
