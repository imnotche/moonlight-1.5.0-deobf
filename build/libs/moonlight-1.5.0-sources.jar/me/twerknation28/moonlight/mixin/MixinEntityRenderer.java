package me.twerknation28.moonlight.mixin;

import org.spongepowered.asm.mixin.injection.At;
import org.spongepowered.asm.mixin.injection.Inject;
import me.twerknation28.moonlight.util.Util;
import net.minecraft.class_1297;
import net.minecraft.class_2561;
import net.minecraft.class_4587;
import net.minecraft.class_4597;
import net.minecraft.class_897;
import me.twerknation28.moonlight.event.impl.RenderLabelEvent;
import org.spongepowered.asm.mixin.injection.callback.CallbackInfo;
import org.spongepowered.asm.mixin.Mixin;

@Mixin({ class_897.class })
public class MixinEntityRenderer
{
    @Inject(method = { "renderLabelIfPresent" }, at = { @At("HEAD") }, cancellable = true)
    public void renderLabelIfPresent(final class_1297 entity, final class_2561 text, final class_4587 matrices, final class_4597 vertexConsumers, final int light, final float tickDelta, final CallbackInfo ci) {
        final RenderLabelEvent renderLabelEvent = new RenderLabelEvent(entity);
        Util.EVENT_BUS.post(renderLabelEvent);
        if (renderLabelEvent.isCancelled()) {
            ci.cancel();
        }
    }
}
