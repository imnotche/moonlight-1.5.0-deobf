package me.twerknation28.moonlight.mixin;

import org.spongepowered.asm.mixin.injection.At;
import org.spongepowered.asm.mixin.injection.Inject;
import me.twerknation28.moonlight.Moonlight;
import net.minecraft.class_9779;
import org.spongepowered.asm.mixin.injection.callback.CallbackInfoReturnable;
import org.spongepowered.asm.mixin.Shadow;
import org.spongepowered.asm.mixin.Mixin;

@Mixin({ class_9779.class_9781.class })
public class MixinRenderTickCounter
{
    @Shadow
    private float lastFrameDuration;
    
    @Inject(method = { "beginRenderTick(J)I" }, at = { @At(value = "FIELD", target = "Lnet/minecraft/client/render/RenderTickCounter$Dynamic;prevTimeMillis:J") })
    public void beginRenderTick(final long timeMillis, final CallbackInfoReturnable<Integer> cir) {
        this.lastFrameDuration *= Moonlight.TIMER;
    }
}
