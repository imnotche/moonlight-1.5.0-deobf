package me.twerknation28.moonlight.mixin;

import me.twerknation28.moonlight.Moonlight;
import org.spongepowered.asm.mixin.injection.At;
import org.spongepowered.asm.mixin.injection.Inject;
import me.twerknation28.moonlight.util.ColorUtil;
import net.minecraft.class_2561;
import net.minecraft.class_437;
import net.minecraft.class_442;
import net.minecraft.class_7842;
import me.twerknation28.moonlight.features.modules.client.NewGui;
import java.util.Objects;
import org.spongepowered.asm.mixin.injection.callback.CallbackInfo;
import org.spongepowered.asm.mixin.Unique;
import org.spongepowered.asm.mixin.Mixin;

@Mixin({ class_442.class })
public class MixinTitleScreen extends class_437
{
    @Unique
    private String message;
    
    public MixinTitleScreen() {
        super(class_2561.method_30163("moonlight"));
        this.message = "waohack elite oh yeah";
    }
    
    @Inject(method = { "init" }, at = { @At("RETURN") })
    public void initHook(final CallbackInfo ci) {
        final String bussin = Moonlight.NAME + Moonlight.NAME;
        final class_7842 textWidget = new class_7842(class_2561.method_30163(bussin + ": " + this.message), this.field_22793);
        final int var5 = this.field_22787.method_22683().method_4502();
        Objects.requireNonNull(this.field_22793);
        textWidget.method_48229(2, var5 - 18 - 2);
        textWidget.method_46438(ColorUtil.toARGB(NewGui.getInstance().red.getValue(), NewGui.getInstance().green.getValue(), NewGui.getInstance().blue.getValue(), 255));
        this.method_37063(textWidget);
    }
}
