package me.twerknation28.moonlight.mixin;

import org.spongepowered.asm.mixin.injection.At;
import org.spongepowered.asm.mixin.injection.Inject;
import me.twerknation28.moonlight.util.Util;
import net.minecraft.class_310;
import net.minecraft.class_329;
import net.minecraft.class_332;
import net.minecraft.class_9779;
import me.twerknation28.moonlight.event.impl.Render2DEvent;
import org.lwjgl.opengl.GL11;
import com.mojang.blaze3d.systems.RenderSystem;
import org.spongepowered.asm.mixin.injection.callback.CallbackInfo;
import org.spongepowered.asm.mixin.Mixin;

@Mixin({ class_329.class })
public class MixinInGameHud
{
    @Inject(method = { "render" }, at = { @At("RETURN") })
    public void render(final class_332 context, final class_9779 tickCounter, final CallbackInfo ci) {
        if (class_310.method_1551().field_1705.method_53531().method_53536()) {
            return;
        }
        RenderSystem.setShaderColor(1.0f, 1.0f, 1.0f, 1.0f);
        RenderSystem.disableDepthTest();
        RenderSystem.enableBlend();
        RenderSystem.blendFunc(770, 771);
        RenderSystem.disableCull();
        GL11.glEnable(2848);
        final Render2DEvent event = new Render2DEvent(context, tickCounter.method_60637(true));
        Util.EVENT_BUS.post(event);
        RenderSystem.enableDepthTest();
        GL11.glDisable(2848);
    }
}
