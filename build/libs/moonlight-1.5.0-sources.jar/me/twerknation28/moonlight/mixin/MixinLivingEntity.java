package me.twerknation28.moonlight.mixin;

import org.spongepowered.asm.mixin.injection.At;
import org.spongepowered.asm.mixin.injection.Inject;
import me.twerknation28.moonlight.event.impl.DeathEvent;
import me.twerknation28.moonlight.util.Util;
import net.minecraft.class_1309;
import net.minecraft.class_2940;
import org.spongepowered.asm.mixin.injection.callback.CallbackInfo;
import org.spongepowered.asm.mixin.Final;
import org.spongepowered.asm.mixin.Shadow;
import org.spongepowered.asm.mixin.Mixin;

@Mixin({ class_1309.class })
public class MixinLivingEntity extends MixinEntity
{
    @Shadow
    @Final
    private static class_2940<Float> HEALTH;
    
    @Inject(method = { "onTrackedDataSet" }, at = { @At("RETURN") })
    public void onTrackedDataSet(final class_2940<?> key, final CallbackInfo info) {
        if (key.equals((Object)MixinLivingEntity.HEALTH) && (float)this.dataTracker.method_12789((class_2940)MixinLivingEntity.HEALTH) <= 0.0 && Util.mc.field_1687 != null && Util.mc.field_1687.method_8608()) {
            final DeathEvent deathEvent = new DeathEvent(class_1309.class.cast(this));
            Util.EVENT_BUS.post(deathEvent);
        }
    }
}
