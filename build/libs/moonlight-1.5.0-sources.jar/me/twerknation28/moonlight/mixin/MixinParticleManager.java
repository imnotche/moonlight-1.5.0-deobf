package me.twerknation28.moonlight.mixin;

import org.spongepowered.asm.mixin.injection.At;
import org.spongepowered.asm.mixin.injection.Inject;
import me.twerknation28.moonlight.features.modules.render.NoRender;
import net.minecraft.class_691;
import net.minecraft.class_702;
import net.minecraft.class_703;
import net.minecraft.class_711;
import net.minecraft.class_717;
import net.minecraft.class_727;
import org.spongepowered.asm.mixin.injection.callback.CallbackInfo;
import org.spongepowered.asm.mixin.Mixin;

@Mixin({ class_702.class })
public class MixinParticleManager
{
    @Inject(at = { @At("HEAD") }, method = { "addParticle(Lnet/minecraft/client/particle/Particle;)V" }, cancellable = true)
    public void addParticleHook(final class_703 particle, final CallbackInfo e) {
        if (NoRender.getInstance().isOn() && NoRender.getInstance().uglyParticles.getValue() && (particle instanceof class_717 || particle instanceof class_727 || particle instanceof class_691 || particle instanceof class_711)) {
            e.cancel();
        }
    }
}
