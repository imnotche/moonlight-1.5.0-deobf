package me.twerknation28.moonlight.mixin;

import org.spongepowered.asm.mixin.injection.At;
import org.spongepowered.asm.mixin.injection.Inject;
import me.twerknation28.moonlight.event.impl.PlayerMoveEvent;
import me.twerknation28.moonlight.util.Util;
import net.minecraft.class_1297;
import net.minecraft.class_1313;
import net.minecraft.class_243;
import net.minecraft.class_2945;
import org.spongepowered.asm.mixin.injection.callback.CallbackInfo;
import org.spongepowered.asm.mixin.Shadow;
import org.spongepowered.asm.mixin.Final;
import org.spongepowered.asm.mixin.Mixin;

@Mixin({ class_1297.class })
public class MixinEntity
{
    @Final
    @Shadow
    protected class_2945 dataTracker;
    
    @Inject(method = { "move" }, at = { @At("HEAD") })
    private void onMove(final class_1313 type, final class_243 movement, final CallbackInfo info) {
        if ((Object) this == Util.mc.field_1724) {
            final PlayerMoveEvent event = new PlayerMoveEvent();
            Util.EVENT_BUS.post(event);
        }
    }
}
