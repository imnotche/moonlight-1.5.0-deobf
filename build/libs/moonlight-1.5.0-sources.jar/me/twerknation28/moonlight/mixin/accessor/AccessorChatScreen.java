package me.twerknation28.moonlight.mixin.accessor;

import org.spongepowered.asm.mixin.gen.Accessor;
import net.minecraft.class_342;
import net.minecraft.class_408;
import org.spongepowered.asm.mixin.Mixin;

@Mixin({ class_408.class })
public interface AccessorChatScreen
{
    @Accessor("chatField")
    class_342 getChatField();
}
