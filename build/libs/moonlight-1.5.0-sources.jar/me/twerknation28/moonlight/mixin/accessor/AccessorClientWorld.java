package me.twerknation28.moonlight.mixin.accessor;

import org.spongepowered.asm.mixin.gen.Invoker;
import net.minecraft.class_3414;
import net.minecraft.class_3419;
import net.minecraft.class_638;
import net.minecraft.class_7202;
import org.spongepowered.asm.mixin.Mixin;

@Mixin({ class_638.class })
public interface AccessorClientWorld
{
    @Invoker("playSound")
    void hookPlaySound(final double p0, final double p1, final double p2, final class_3414 p3, final class_3419 p4, final float p5, final float p6, final boolean p7, final long p8);
    
    @Invoker("getPendingUpdateManager")
    class_7202 hookGetPendingUpdateManager();
}
