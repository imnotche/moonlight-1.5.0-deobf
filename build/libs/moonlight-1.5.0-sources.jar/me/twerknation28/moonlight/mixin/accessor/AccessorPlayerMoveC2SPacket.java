package me.twerknation28.moonlight.mixin.accessor;

import org.spongepowered.asm.mixin.gen.Accessor;
import org.spongepowered.asm.mixin.Mutable;
import net.minecraft.class_2828;
import org.spongepowered.asm.mixin.Mixin;

@Mixin({ class_2828.class })
public interface AccessorPlayerMoveC2SPacket
{
    @Mutable
    @Accessor("y")
    void setY(final double p0);
    
    @Mutable
    @Accessor("onGround")
    void setOnGround(final boolean p0);
}
