package me.twerknation28.moonlight.mixin.accessor;

import org.spongepowered.asm.mixin.gen.Accessor;
import net.minecraft.class_1309;
import org.spongepowered.asm.mixin.Mixin;

@Mixin({ class_1309.class })
public interface AccessorLivingEntity
{
    @Accessor("lastAttackedTicks")
    int getLastAttackedTicks();
    
    @Accessor("jumpingCooldown")
    int getLastJumpCooldown();
    
    @Accessor("jumpingCooldown")
    void setLastJumpCooldown(final int p0);
}
