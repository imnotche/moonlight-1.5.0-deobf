package me.twerknation28.moonlight.mixin.accessor;

import org.spongepowered.asm.mixin.gen.Accessor;
import java.util.List;
import net.minecraft.class_303;
import net.minecraft.class_338;
import org.spongepowered.asm.mixin.Mixin;

@Mixin({ class_338.class })
public interface AccessorChatHud
{
    @Accessor("visibleMessages")
    List<class_303.class_7590> getVisibleMessages();
    
    @Accessor("messages")
    List<class_303> getMessages();
}
