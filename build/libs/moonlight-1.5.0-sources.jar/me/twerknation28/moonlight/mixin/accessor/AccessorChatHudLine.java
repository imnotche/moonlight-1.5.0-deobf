package me.twerknation28.moonlight.mixin.accessor;

import org.spongepowered.asm.mixin.gen.Accessor;
import org.spongepowered.asm.mixin.Mutable;
import net.minecraft.class_2561;
import net.minecraft.class_303;
import org.spongepowered.asm.mixin.Mixin;

@Mixin({ class_303.class })
public interface AccessorChatHudLine
{
    @Mutable
    @Accessor("content")
    void setContent(final class_2561 p0);
}
