package me.twerknation28.moonlight.mixin;

import org.spongepowered.asm.mixin.injection.At;
import org.spongepowered.asm.mixin.injection.Inject;
import me.twerknation28.moonlight.features.modules.render.Fullbright;
import net.minecraft.class_2874;
import net.minecraft.class_3532;
import net.minecraft.class_765;
import org.spongepowered.asm.mixin.injection.callback.CallbackInfoReturnable;
import org.spongepowered.asm.mixin.Mixin;

@Mixin({ class_765.class })
public class MixinLightmapTextureManager
{
    @Inject(method = { "getBrightness" }, at = { @At("HEAD") }, cancellable = true)
    private static void getBrightnessHook(final class_2874 type, final int lightLevel, final CallbackInfoReturnable<Float> cir) {
        if (Fullbright.getInstance().isOn()) {
            final float f = lightLevel / 15.0f;
            final float g = f / (4.0f - 3.0f * f);
            cir.setReturnValue(Math.max(class_3532.method_16439(type.comp_656(), g, 1.0f), 0.5f));
        }
    }
}
