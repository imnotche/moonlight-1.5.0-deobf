package me.twerknation28.moonlight.mixin;

import org.spongepowered.asm.mixin.injection.At;
import org.spongepowered.asm.mixin.injection.Inject;
import me.twerknation28.moonlight.features.modules.render.NoRender;
import net.minecraft.class_310;
import net.minecraft.class_4587;
import net.minecraft.class_4603;
import org.spongepowered.asm.mixin.injection.callback.CallbackInfo;
import org.spongepowered.asm.mixin.Mixin;

@Mixin({ class_4603.class })
public class MixinInGameOverlayRenderer
{
    @Inject(method = { "renderFireOverlay" }, at = { @At("HEAD") }, cancellable = true)
    private static void onRenderFireOverlay(final class_310 minecraftClient, final class_4587 matrixStack, final CallbackInfo info) {
        if (NoRender.getInstance().isOn() && NoRender.getInstance().fireOverlay.getValue()) {
            info.cancel();
        }
    }
}
