package me.twerknation28.moonlight.mixin;

import org.spongepowered.asm.mixin.injection.At;
import org.spongepowered.asm.mixin.injection.Inject;
import me.twerknation28.moonlight.util.Util;
import net.minecraft.class_4184;
import net.minecraft.class_757;
import net.minecraft.class_761;
import net.minecraft.class_765;
import net.minecraft.class_9779;
import me.twerknation28.moonlight.event.impl.WorldRenderEvent;
import org.spongepowered.asm.mixin.injection.callback.CallbackInfo;
import org.joml.Matrix4f;
import org.spongepowered.asm.mixin.Mixin;

@Mixin({ class_761.class })
public class WorldRendererMixin
{
    @Inject(method = { "render" }, at = { @At("HEAD") })
    public void render(final class_9779 tickCounter, final boolean renderBlockOutline, final class_4184 camera, final class_757 gameRenderer, final class_765 lightmapTextureManager, final Matrix4f matrix4f, final Matrix4f matrix4f2, final CallbackInfo ci) {
        final WorldRenderEvent worldRenderEvent = new WorldRenderEvent();
        Util.EVENT_BUS.post(worldRenderEvent);
    }
}
