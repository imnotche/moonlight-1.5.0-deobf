package me.twerknation28.moonlight.mixin;

import com.google.common.collect.Lists;
import java.util.List;
import java.util.ListIterator;
import me.twerknation28.moonlight.features.api.AngelChat;
import net.minecraft.class_2561;
import net.minecraft.class_303;
import net.minecraft.class_338;
import net.minecraft.class_7469;
import net.minecraft.class_7591;
import org.jetbrains.annotations.Nullable;
import org.spongepowered.asm.mixin.Final;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.Shadow;
import org.spongepowered.asm.mixin.gen.Invoker;

@Mixin(value={class_338.class})
public abstract class MixinChatHud
        implements AngelChat {
    @Final
    @Shadow
    private List<class_303> messages = Lists.newArrayList();

    @Shadow
    public abstract int getWidth();

    @Shadow
    protected abstract void refresh();

    @Override
    @Invoker
    public abstract void invokeAddMessage(class_2561 var1, @Nullable class_7469 var2, @Nullable class_7591 var3);

    @Override
    public void angel$remove(@Nullable class_7591 indicator, boolean all) {
        if (indicator != null) {
            ListIterator<class_303> listIterator = this.messages.listIterator();
            boolean changed = false;
            while (listIterator.hasNext()) {
                class_303 message = listIterator.next();
                if (!indicator.equals((Object)message.comp_894())) continue;
                listIterator.remove();
                changed = true;
                if (all) continue;
                break;
            }
            if (changed) {
                this.refresh();
            }
        }
    }
}
