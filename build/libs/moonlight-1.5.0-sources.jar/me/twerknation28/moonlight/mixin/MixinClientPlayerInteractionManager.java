package me.twerknation28.moonlight.mixin;

import org.spongepowered.asm.mixin.injection.At;
import org.spongepowered.asm.mixin.injection.Inject;
import me.twerknation28.moonlight.event.impl.AttackBlockEvent;
import me.twerknation28.moonlight.util.Util;
import net.minecraft.class_2338;
import net.minecraft.class_2350;
import net.minecraft.class_2680;
import net.minecraft.class_636;
import org.spongepowered.asm.mixin.injection.callback.CallbackInfoReturnable;
import org.spongepowered.asm.mixin.Mixin;

@Mixin({ class_636.class })
public class MixinClientPlayerInteractionManager
{
    @Inject(method = { "attackBlock" }, at = { @At("HEAD") }, cancellable = true)
    private void hookAttackBlock(final class_2338 pos, final class_2350 direction, final CallbackInfoReturnable<Boolean> cir) {
        final class_2680 state = Util.mc.field_1687.method_8320(pos);
        final AttackBlockEvent attackBlockEvent = new AttackBlockEvent(pos, state, direction);
        Util.EVENT_BUS.post(attackBlockEvent);
        if (attackBlockEvent.isCanceled()) {
            cir.cancel();
        }
    }
}
