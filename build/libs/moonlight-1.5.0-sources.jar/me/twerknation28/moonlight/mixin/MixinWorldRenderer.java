package me.twerknation28.moonlight.mixin;

import me.twerknation28.moonlight.features.modules.render.NoRender;
import org.spongepowered.asm.mixin.injection.At;
import org.spongepowered.asm.mixin.injection.Inject;
import me.twerknation28.moonlight.event.impl.Render3DEvent;
import com.mojang.blaze3d.systems.RenderSystem;
import me.twerknation28.moonlight.util.Util;
import net.minecraft.class_310;
import net.minecraft.class_4184;
import net.minecraft.class_4587;
import net.minecraft.class_757;
import net.minecraft.class_761;
import net.minecraft.class_765;
import net.minecraft.class_7833;
import net.minecraft.class_9779;
import com.llamalad7.mixinextras.sugar.Local;
import org.spongepowered.asm.mixin.injection.callback.CallbackInfo;
import org.joml.Matrix4f;
import org.spongepowered.asm.mixin.Mixin;

@Mixin({ class_761.class })
public class MixinWorldRenderer
{
    @Inject(method = { "render" }, at = { @At("RETURN") })
    private void render(final class_9779 tickCounter, final boolean renderBlockOutline, final class_4184 camera, final class_757 gameRenderer, final class_765 lightmapTextureManager, final Matrix4f matrix4f, final Matrix4f matrix4f2, final CallbackInfo ci, @Local final class_4587 stack) {
        stack.method_22907(class_7833.field_40714.rotationDegrees(Util.mc.field_1773.method_19418().method_19329()));
        stack.method_22907(class_7833.field_40716.rotationDegrees(Util.mc.field_1773.method_19418().method_19330() + 180.0f));
        class_310.method_1551().method_16011().method_15396("moonlight-render-3d");
        RenderSystem.clear(256, class_310.field_1703);
        final Render3DEvent event = new Render3DEvent(stack, tickCounter.method_60637(true));
        Util.EVENT_BUS.post(event);
        class_310.method_1551().method_16011().method_15407();
    }
    
    @Inject(method = { "drawEntityOutlinesFramebuffer" }, at = { @At("HEAD") }, cancellable = true)
    public void drawEntityOutlinesFramebufferHook(final CallbackInfo ci) {
        if (NoRender.getInstance().glow.getValue() && NoRender.getInstance().isEnabled()) {
            ci.cancel();
        }
    }
}
