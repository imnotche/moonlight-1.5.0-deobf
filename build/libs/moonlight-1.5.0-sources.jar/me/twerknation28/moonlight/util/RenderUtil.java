package me.twerknation28.moonlight.util;

import java.awt.Color;
import java.util.function.Supplier;
import net.minecraft.class_2338;
import net.minecraft.class_238;
import net.minecraft.class_243;
import net.minecraft.class_286;
import net.minecraft.class_287;
import net.minecraft.class_289;
import net.minecraft.class_290;
import net.minecraft.class_293;
import net.minecraft.class_4184;
import net.minecraft.class_4587;
import net.minecraft.class_4588;
import net.minecraft.class_757;
import net.minecraft.class_761;
import net.minecraft.class_7833;
import com.mojang.blaze3d.systems.RenderSystem;

public class RenderUtil implements Util
{
    public static void rect(final class_4587 stack, final float x1, final float y1, final float x2, final float y2, final int color) {
        rectFilled(stack, x1, y1, x2, y2, color);
    }
    
    public static void rect(final class_4587 stack, final float x1, final float y1, final float x2, final float y2, final int color, final float width) {
        drawHorizontalLine(stack, x1, x2, y1, color, width);
        drawVerticalLine(stack, x2, y1, y2, color, width);
        drawHorizontalLine(stack, x1, x2, y2, color, width);
        drawVerticalLine(stack, x1, y1, y2, color, width);
    }
    
    protected static void drawHorizontalLine(final class_4587 matrices, float x1, float x2, final float y, final int color) {
        if (x2 < x1) {
            final float i = x1;
            x1 = x2;
            x2 = i;
        }
        rectFilled(matrices, x1, y, x2 + 1.0f, y + 1.0f, color);
    }
    
    protected static void drawVerticalLine(final class_4587 matrices, final float x, float y1, float y2, final int color) {
        if (y2 < y1) {
            final float i = y1;
            y1 = y2;
            y2 = i;
        }
        rectFilled(matrices, x, y1 + 1.0f, x + 1.0f, y2, color);
    }
    
    protected static void drawHorizontalLine(final class_4587 matrices, float x1, float x2, final float y, final int color, final float width) {
        if (x2 < x1) {
            final float i = x1;
            x1 = x2;
            x2 = i;
        }
        rectFilled(matrices, x1, y, x2 + width, y + width, color);
    }
    
    protected static void drawVerticalLine(final class_4587 matrices, final float x, float y1, float y2, final int color, final float width) {
        if (y2 < y1) {
            final float i = y1;
            y1 = y2;
            y2 = i;
        }
        rectFilled(matrices, x, y1 + width, x + width, y2, color);
    }
    
    public static void rectFilled(final class_4587 matrix, float x1, float y1, float x2, float y2, final int color) {
        if (x1 < x2) {
            final float i = x1;
            x1 = x2;
            x2 = i;
        }
        if (y1 < y2) {
            final float i = y1;
            y1 = y2;
            y2 = i;
        }
        final float f = (color >> 24 & 0xFF) / 255.0f;
        final float g = (color >> 16 & 0xFF) / 255.0f;
        final float h = (color >> 8 & 0xFF) / 255.0f;
        final float j = (color & 0xFF) / 255.0f;
        RenderSystem.enableBlend();
        RenderSystem.defaultBlendFunc();
        RenderSystem.setShader(class_757::method_34540);
        final class_287 bufferBuilder = class_289.method_1348().method_60827(class_293.class_5596.field_27382, class_290.field_1576);
        bufferBuilder.method_22918(matrix.method_23760().method_23761(), x1, y2, 0.0f).method_22915(g, h, j, f);
        bufferBuilder.method_22918(matrix.method_23760().method_23761(), x2, y2, 0.0f).method_22915(g, h, j, f);
        bufferBuilder.method_22918(matrix.method_23760().method_23761(), x2, y1, 0.0f).method_22915(g, h, j, f);
        bufferBuilder.method_22918(matrix.method_23760().method_23761(), x1, y1, 0.0f).method_22915(g, h, j, f);
        class_286.method_43433(bufferBuilder.method_60800());
        RenderSystem.disableBlend();
    }
    
    public static void drawBoxFilled(final class_4587 stack, final class_238 box, final Color c) {
        final float minX = (float)(box.field_1323 - RenderUtil.mc.method_1561().field_4686.method_19326().method_10216());
        final float minY = (float)(box.field_1322 - RenderUtil.mc.method_1561().field_4686.method_19326().method_10214());
        final float minZ = (float)(box.field_1321 - RenderUtil.mc.method_1561().field_4686.method_19326().method_10215());
        final float maxX = (float)(box.field_1320 - RenderUtil.mc.method_1561().field_4686.method_19326().method_10216());
        final float maxY = (float)(box.field_1325 - RenderUtil.mc.method_1561().field_4686.method_19326().method_10214());
        final float maxZ = (float)(box.field_1324 - RenderUtil.mc.method_1561().field_4686.method_19326().method_10215());
        final class_289 tessellator = class_289.method_1348();
        setup3D();
        RenderSystem.setShader(class_757::method_34540);
        final class_287 bufferBuilder = class_289.method_1348().method_60827(class_293.class_5596.field_27382, class_290.field_1576);
        bufferBuilder.method_22918(stack.method_23760().method_23761(), minX, minY, minZ).method_39415(c.getRGB());
        bufferBuilder.method_22918(stack.method_23760().method_23761(), maxX, minY, minZ).method_39415(c.getRGB());
        bufferBuilder.method_22918(stack.method_23760().method_23761(), maxX, minY, maxZ).method_39415(c.getRGB());
        bufferBuilder.method_22918(stack.method_23760().method_23761(), minX, minY, maxZ).method_39415(c.getRGB());
        bufferBuilder.method_22918(stack.method_23760().method_23761(), minX, maxY, minZ).method_39415(c.getRGB());
        bufferBuilder.method_22918(stack.method_23760().method_23761(), minX, maxY, maxZ).method_39415(c.getRGB());
        bufferBuilder.method_22918(stack.method_23760().method_23761(), maxX, maxY, maxZ).method_39415(c.getRGB());
        bufferBuilder.method_22918(stack.method_23760().method_23761(), maxX, maxY, minZ).method_39415(c.getRGB());
        bufferBuilder.method_22918(stack.method_23760().method_23761(), minX, minY, minZ).method_39415(c.getRGB());
        bufferBuilder.method_22918(stack.method_23760().method_23761(), minX, maxY, minZ).method_39415(c.getRGB());
        bufferBuilder.method_22918(stack.method_23760().method_23761(), maxX, maxY, minZ).method_39415(c.getRGB());
        bufferBuilder.method_22918(stack.method_23760().method_23761(), maxX, minY, minZ).method_39415(c.getRGB());
        bufferBuilder.method_22918(stack.method_23760().method_23761(), maxX, minY, minZ).method_39415(c.getRGB());
        bufferBuilder.method_22918(stack.method_23760().method_23761(), maxX, maxY, minZ).method_39415(c.getRGB());
        bufferBuilder.method_22918(stack.method_23760().method_23761(), maxX, maxY, maxZ).method_39415(c.getRGB());
        bufferBuilder.method_22918(stack.method_23760().method_23761(), maxX, minY, maxZ).method_39415(c.getRGB());
        bufferBuilder.method_22918(stack.method_23760().method_23761(), minX, minY, maxZ).method_39415(c.getRGB());
        bufferBuilder.method_22918(stack.method_23760().method_23761(), maxX, minY, maxZ).method_39415(c.getRGB());
        bufferBuilder.method_22918(stack.method_23760().method_23761(), maxX, maxY, maxZ).method_39415(c.getRGB());
        bufferBuilder.method_22918(stack.method_23760().method_23761(), minX, maxY, maxZ).method_39415(c.getRGB());
        bufferBuilder.method_22918(stack.method_23760().method_23761(), minX, minY, minZ).method_39415(c.getRGB());
        bufferBuilder.method_22918(stack.method_23760().method_23761(), minX, minY, maxZ).method_39415(c.getRGB());
        bufferBuilder.method_22918(stack.method_23760().method_23761(), minX, maxY, maxZ).method_39415(c.getRGB());
        bufferBuilder.method_22918(stack.method_23760().method_23761(), minX, maxY, minZ).method_39415(c.getRGB());
        class_286.method_43433(bufferBuilder.method_60800());
        clean3D();
    }
    
    public static void drawBoxFilled(final class_4587 stack, final class_243 vec, final Color c) {
        drawBoxFilled(stack, class_238.method_29968(vec), c);
    }
    
    public static void drawBoxFilled(final class_4587 stack, final class_2338 bp, final Color c) {
        drawBoxFilled(stack, new class_238(bp), c);
    }
    
    public static void drawBox(final class_4587 stack, final class_238 box, final Color c, final double lineWidth) {
        final float minX = (float)(box.field_1323 - RenderUtil.mc.method_1561().field_4686.method_19326().method_10216());
        final float minY = (float)(box.field_1322 - RenderUtil.mc.method_1561().field_4686.method_19326().method_10214());
        final float minZ = (float)(box.field_1321 - RenderUtil.mc.method_1561().field_4686.method_19326().method_10215());
        final float maxX = (float)(box.field_1320 - RenderUtil.mc.method_1561().field_4686.method_19326().method_10216());
        final float maxY = (float)(box.field_1325 - RenderUtil.mc.method_1561().field_4686.method_19326().method_10214());
        final float maxZ = (float)(box.field_1324 - RenderUtil.mc.method_1561().field_4686.method_19326().method_10215());
        setup3D();
        RenderSystem.lineWidth((float)lineWidth);
        RenderSystem.setShader(class_757::method_34540);
        RenderSystem.defaultBlendFunc();
        final class_287 bufferBuilder = class_289.method_1348().method_60827(class_293.class_5596.field_27377, class_290.field_29337);
        class_761.method_22980(stack, (class_4588)bufferBuilder, (double)minX, (double)minY, (double)minZ, (double)maxX, (double)maxY, (double)maxZ, c.getRed() / 255.0f, c.getGreen() / 255.0f, c.getBlue() / 255.0f, c.getAlpha() / 255.0f);
        class_286.method_43433(bufferBuilder.method_60800());
        clean3D();
    }
    
    public static void drawBox(final class_4587 stack, final class_243 vec, final Color c, final double lineWidth) {
        drawBox(stack, class_238.method_29968(vec), c, lineWidth);
    }
    
    public static void drawBox(final class_4587 stack, final class_2338 bp, final Color c, final double lineWidth) {
        drawBox(stack, new class_238(bp), c, lineWidth);
    }
    
    public static class_4587 matrixFrom(final class_243 pos) {
        final class_4587 matrices = new class_4587();
        final class_4184 camera = RenderUtil.mc.field_1773.method_19418();
        matrices.method_22907(class_7833.field_40714.rotationDegrees(camera.method_19329()));
        matrices.method_22907(class_7833.field_40716.rotationDegrees(camera.method_19330() + 180.0f));
        matrices.method_22904(pos.method_10216() - camera.method_19326().field_1352, pos.method_10214() - camera.method_19326().field_1351, pos.method_10215() - camera.method_19326().field_1350);
        return matrices;
    }
    
    public static void setup() {
        RenderSystem.enableBlend();
        RenderSystem.defaultBlendFunc();
    }
    
    public static void setup3D() {
        setup();
        RenderSystem.disableDepthTest();
        RenderSystem.depthMask(false);
        RenderSystem.disableCull();
    }
    
    public static void clean() {
        RenderSystem.disableBlend();
    }
    
    public static void clean3D() {
        clean();
        RenderSystem.enableDepthTest();
        RenderSystem.depthMask(true);
        RenderSystem.enableCull();
    }
    
    public static double roundSliderForConfig(final double val) {
        return Double.parseDouble(MathUtil.getRounded(val));
    }
    
    public static float roundSliderStep(final float input, final float step) {
        return Math.round(input / step) * step;
    }
    
    public static float reCheckSliderRange(final float value, final float min, final float max) {
        return Math.min(Math.max(value, min), max);
    }
}
