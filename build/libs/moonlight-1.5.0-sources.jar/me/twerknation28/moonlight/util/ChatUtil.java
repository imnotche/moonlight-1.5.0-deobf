package me.twerknation28.moonlight.util;

import me.twerknation28.moonlight.features.api.AngelChat;
import net.minecraft.class_2561;
import net.minecraft.class_7591;

public class ChatUtil
{
    public static final class_7591 ANGEL;
    
    public static void send(final class_2561 message) {
        ((AngelChat)Util.mc.field_1705.method_1743()).angel$remove(ChatUtil.ANGEL, false);
        ((AngelChat)Util.mc.field_1705.method_1743()).invokeAddMessage(message, null, ChatUtil.ANGEL);
    }
    
    static {
        ANGEL = new class_7591(11141290, (class_7591.class_7592)null, class_2561.method_30163("mmoon light"), "Angel");
    }
}
