package me.twerknation28.moonlight.util;

import com.google.common.eventbus.EventBus;
import net.minecraft.class_310;

public interface Util
{
    public static final class_310 mc = class_310.method_1551();
    public static final EventBus EVENT_BUS = new EventBus();
}
