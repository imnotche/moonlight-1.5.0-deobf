package me.twerknation28.moonlight.util;

import java.util.ArrayList;
import net.minecraft.class_1297;
import net.minecraft.class_1299;
import net.minecraft.class_1429;
import net.minecraft.class_1588;
import net.minecraft.class_1690;
import net.minecraft.class_1695;

public class WorldUtil implements Util
{
    public static boolean canTarget(final class_1297 entity, final ArrayList<class_1299> toTarget) {
        return (toTarget.contains(class_1299.field_6051) && entity instanceof class_1588) || (toTarget.contains(class_1299.field_6093) && entity instanceof class_1429) || ((entity instanceof class_1690 || entity instanceof class_1695) && toTarget.contains(class_1299.field_6121)) || toTarget.contains(entity.method_5864());
    }
}
