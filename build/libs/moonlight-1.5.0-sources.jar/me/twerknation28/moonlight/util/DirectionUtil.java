package me.twerknation28.moonlight.util;

import java.util.Iterator;
import java.util.Arrays;
import java.util.List;
import net.minecraft.class_2338;
import net.minecraft.class_2350;

public class DirectionUtil
{
    public static Boolean isCardinal(final EightWayDirections dir) {
        return dir.equals(EightWayDirections.EAST) || dir.equals(EightWayDirections.WEST) || dir.equals(EightWayDirections.SOUTH) || dir.equals(EightWayDirections.NORTH);
    }
    
    public enum EightWayDirections
    {
        NORTH(new class_2350[] { class_2350.field_11043 }), 
        SOUTH(new class_2350[] { class_2350.field_11035 }), 
        EAST(new class_2350[] { class_2350.field_11034 }), 
        WEST(new class_2350[] { class_2350.field_11039 }), 
        NORTHEAST(new class_2350[] { class_2350.field_11043, class_2350.field_11034 }), 
        NORTHWEST(new class_2350[] { class_2350.field_11043, class_2350.field_11039 }), 
        SOUTHEAST(new class_2350[] { class_2350.field_11035, class_2350.field_11034 }), 
        SOUTHWEST(new class_2350[] { class_2350.field_11035, class_2350.field_11039 });
        
        private final List<class_2350> directions;
        
        private EightWayDirections(final class_2350[] directions) {
            this.directions = Arrays.asList(directions);
        }
        
        public class_2338 offset(final class_2338 pos) {
            class_2338 result = pos;
            for (final class_2350 direction : this.directions) {
                result = result.method_10093(direction);
            }
            return result;
        }
    }
    
    public enum FourWayDirections
    {
        NORTH(new class_2350[] { class_2350.field_11043 }), 
        SOUTH(new class_2350[] { class_2350.field_11035 }), 
        EAST(new class_2350[] { class_2350.field_11034 }), 
        WEST(new class_2350[] { class_2350.field_11039 });
        
        private final List<class_2350> directions;
        
        private FourWayDirections(final class_2350[] directions) {
            this.directions = Arrays.asList(directions);
        }
        
        public class_2338 offset(final class_2338 pos) {
            class_2338 result = pos;
            for (final class_2350 direction : this.directions) {
                result = result.method_10093(direction);
            }
            return result;
        }
    }
}
