package me.twerknation28.moonlight.util;

import org.apache.commons.lang3.StringUtils;
import me.twerknation28.moonlight.features.modules.misc.NameProtect;
import net.minecraft.class_332;

public class FontUtil implements Util
{
    public static float drawStringWithShadow(String text, final int x, final int y, final int color, final class_332 context) {
        if (NameProtect.INSTANCE.isEnabled()) {
            text = StringUtils.replace(text, String.valueOf(FontUtil.mc.field_1724.method_5477()), (String)NameProtect.INSTANCE.newName.getValue());
        }
        return (float)context.method_25303(FontUtil.mc.field_1772, text, x, y, color);
    }
}
