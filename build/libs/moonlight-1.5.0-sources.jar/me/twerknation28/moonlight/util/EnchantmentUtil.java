package me.twerknation28.moonlight.util;

import java.util.Iterator;
import net.minecraft.class_1304;
import net.minecraft.class_1309;
import net.minecraft.class_1799;
import net.minecraft.class_1887;
import net.minecraft.class_5321;
import net.minecraft.class_6880;
import it.unimi.dsi.fastutil.objects.Object2IntMap;

public final class EnchantmentUtil implements Util
{
    private EnchantmentUtil() {
        throw new IllegalArgumentException("\u043f\u043e\u0448\u0435\u043b \u043d\u0430\u0445\u0443\u0439");
    }
    
    public static int getLevel(final class_5321<class_1887> key, final class_1799 stack) {
        if (stack.method_7960()) {
            return 0;
        }
        for (final Object2IntMap.Entry<class_6880<class_1887>> enchantment : stack.method_58657().method_57539()) {
            if (((class_6880)enchantment.getKey()).method_40225((class_5321)key)) {
                return enchantment.getIntValue();
            }
        }
        return 0;
    }
    
    public static int getLevel(final class_5321<class_1887> key, final class_1304 slot, final class_1309 entity) {
        return getLevel(key, entity.method_6118(slot));
    }
    
    public static int getLevel(final class_5321<class_1887> key, final class_1304 slot) {
        return getLevel(key, slot, (class_1309)EnchantmentUtil.mc.field_1724);
    }
    
    public static boolean has(final class_5321<class_1887> key, final class_1799 stack) {
        return getLevel(key, stack) > 0;
    }
    
    public static boolean has(final class_5321<class_1887> key, final class_1304 slot, final class_1309 entity) {
        return getLevel(key, slot, entity) > 0;
    }
    
    public static boolean has(final class_5321<class_1887> key, final class_1304 slot) {
        return getLevel(key, slot) > 0;
    }
}
