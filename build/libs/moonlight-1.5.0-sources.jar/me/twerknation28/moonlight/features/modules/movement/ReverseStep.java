package me.twerknation28.moonlight.features.modules.movement;

import me.twerknation28.moonlight.features.api.Category;
import me.twerknation28.moonlight.features.modules.Module;

public class ReverseStep extends Module
{
    public ReverseStep() {
        super("ReverseStep", "step but reversed..", Category.PLAYER, true, false, false);
    }
    
    @Override
    public void onUpdate() {
        if (nullCheck()) {
            return;
        }
        if (ReverseStep.mc.field_1724.method_5771() || ReverseStep.mc.field_1724.method_5799() || !ReverseStep.mc.field_1724.method_24828()) {
            return;
        }
        ReverseStep.mc.field_1724.method_5762(0.0, -1.0, 0.0);
    }
}
