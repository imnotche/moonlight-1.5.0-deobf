package me.twerknation28.moonlight.features.modules.movement;

import me.twerknation28.moonlight.manager.NetworkManager;
import me.twerknation28.moonlight.manager.InventoryManager;
import me.twerknation28.moonlight.manager.RotationManager;
import net.minecraft.class_1268;
import net.minecraft.class_1657;
import net.minecraft.class_1776;
import net.minecraft.class_1799;
import net.minecraft.class_1802;
import net.minecraft.class_243;
import net.minecraft.class_2596;
import net.minecraft.class_2828;
import me.twerknation28.moonlight.features.commands.Command;
import me.twerknation28.moonlight.features.modules.client.Notifications;
import me.twerknation28.moonlight.features.api.Category;
import me.twerknation28.moonlight.features.settings.Setting;
import me.twerknation28.moonlight.features.modules.Module;

public class PearlPhase extends Module
{
    public final Setting<Float> throwPitch;
    public final Setting<Integer> jumpDelay;
    private static int delayTimer;
    private static float realPitch;
    
    public PearlPhase() {
        super("Phase", "Phases you into blocks", Category.PLAYER, true, false, true);
        this.throwPitch = this.register(new Setting<Float>("Pitch", 85.0f, 0.0f, 90.0f, 1.0f));
        this.jumpDelay = this.register(new Setting<Integer>("Jump Delay", 2, 0, 6, 1));
    }
    
    @Override
    public void onEnable() {
        if (nullCheck()) {
            return;
        }
        if (Notifications.getInstance().isEnabled()) {
            Command.enableMessage(this.getName());
        }
        if (PearlPhase.mc.field_1724.method_20232()) {
            Command.sendMessage("Escaping crawl...");
            PearlPhase.delayTimer = 0;
            PearlPhase.realPitch = -90.0f;
            PearlPhase.mc.field_1724.method_6043();
        }
        else {
            PearlPhase.delayTimer = this.jumpDelay.getValue();
            PearlPhase.realPitch = this.throwPitch.getValue();
        }
    }
    
    @Override
    public void onUpdate() {
        if (PearlPhase.delayTimer >= this.jumpDelay.getValue()) {
            int pearlSlot = -1;
            for (int i = 0; i < 9; ++i) {
                final class_1799 stack = PearlPhase.mc.field_1724.method_31548().method_5438(i);
                if (stack.method_7909() instanceof class_1776) {
                    pearlSlot = i;
                    break;
                }
            }
            if (pearlSlot == -1 || PearlPhase.mc.field_1724.method_7357().method_7904(class_1802.field_8634)) {
                this.disable();
                return;
            }
            final int prevItem = PearlPhase.mc.field_1724.method_31548().field_7545;
            final float prevYaw = PearlPhase.mc.field_1724.method_36454();
            final float prevPitch = PearlPhase.mc.field_1724.method_36455();
            final float[] rotations = RotationManager.getRotationsTo(PearlPhase.mc.field_1724.method_33571(), new class_243(Math.floor(PearlPhase.mc.field_1724.method_23317()) + 0.5, 0.0, Math.floor(PearlPhase.mc.field_1724.method_23321()) + 0.5));
            RotationManager.setPlayerRotations(rotations[0] + 180.0f, PearlPhase.realPitch);
            InventoryManager.setSlot(pearlSlot);
            final class_2596<?> p = (class_2596<?>)new class_2828.class_2830(PearlPhase.mc.field_1724.method_23317(), PearlPhase.mc.field_1724.method_23318(), PearlPhase.mc.field_1724.method_23321(), rotations[0] + 180.0f, PearlPhase.realPitch, PearlPhase.mc.field_1724.method_24828());
            NetworkManager.sendPacket(p);
            PearlPhase.mc.field_1761.method_2919((class_1657)PearlPhase.mc.field_1724, class_1268.field_5808);
            PearlPhase.mc.field_1724.method_6104(class_1268.field_5808);
            InventoryManager.syncToClient();
            RotationManager.setPlayerRotations(prevYaw, prevPitch);
            this.toggle();
        }
        else {
            ++PearlPhase.delayTimer;
        }
    }
    
    static {
        PearlPhase.delayTimer = 0;
    }
}
