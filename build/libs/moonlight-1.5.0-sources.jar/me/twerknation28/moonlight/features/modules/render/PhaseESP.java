package me.twerknation28.moonlight.features.modules.render;

import me.twerknation28.moonlight.util.RenderUtil;
import net.minecraft.class_1922;
import net.minecraft.class_2338;
import net.minecraft.class_238;
import net.minecraft.class_243;
import net.minecraft.class_259;
import net.minecraft.class_2680;
import java.awt.Color;
import me.twerknation28.moonlight.features.modules.client.NewGui;
import me.twerknation28.moonlight.event.EventListener;
import me.twerknation28.moonlight.util.DirectionUtil;
import me.twerknation28.moonlight.event.impl.Render3DEvent;
import me.twerknation28.moonlight.features.api.Category;
import me.twerknation28.moonlight.features.settings.Setting;
import me.twerknation28.moonlight.features.modules.Module;

public class PhaseESP extends Module
{
    public final Setting<Integer> boxAlpha;
    public final Setting<Integer> lineAlpha;
    public final Setting<Double> lineWidth;
    public Setting<Boolean> phaseRender;
    public final Setting<Boolean> newColor;
    public final Setting<Boolean> whileCrawl;
    public final Setting<Double> fadeDistance;
    public final Setting<Boolean> diagonal;
    public Setting<Boolean> proneRender;
    public Setting<Boolean> whileAirborne;
    public Setting<boxMode> renderMode;
    
    public PhaseESP() {
        super("ESP", "Awareness Module 7000", Category.RENDER, true, false, false);
        this.boxAlpha = this.register(new Setting<Integer>("BoxAlpha", 15, 0, 255, 1));
        this.lineAlpha = this.register(new Setting<Integer>("LineAlpha", 50, 0, 255, 1));
        this.lineWidth = this.register(new Setting<Double>("LineWidth", 2.0, 0.1, 4.0, 0.1));
        this.phaseRender = this.register(new Setting<Boolean>("PhaseESP", true));
        this.newColor = this.register(new Setting<Boolean>("NewColour", false, v -> this.phaseRender.getValue()));
        this.whileCrawl = this.register(new Setting<Boolean>("WhileCrawling", false, v -> this.phaseRender.getValue()));
        this.fadeDistance = this.register(new Setting<Double>("FadeDist", 0.5, 0.0, 1.0, 0.1, v -> this.phaseRender.getValue()));
        this.diagonal = this.register(new Setting<Boolean>("Diagonal", true, v -> this.phaseRender.getValue()));
        this.proneRender = this.register(new Setting<Boolean>("ProneESP", false));
        this.whileAirborne = this.register(new Setting<Boolean>("WhileAirborne", false, v -> this.proneRender.getValue()));
        this.renderMode = this.register(new Setting<boxMode>("RenderMode", boxMode.TOP, v -> this.proneRender.getValue()));
    }
    
    @EventListener
    @Override
    public void onRender3D(final Render3DEvent event) {
        if (PhaseESP.mc.field_1724 != null && PhaseESP.mc.field_1687 != null && PhaseESP.mc.field_1724.method_24828()) {
            final class_2338 playerPos = PhaseESP.mc.field_1724.method_24515();
            for (final DirectionUtil.EightWayDirections direction : DirectionUtil.EightWayDirections.values()) {
                if ((this.diagonal.getValue() || DirectionUtil.isCardinal(direction)) && this.phaseRender.getValue() && (this.whileCrawl.getValue() || !PhaseESP.mc.field_1724.method_20232())) {
                    final class_2338 blockPos = direction.offset(playerPos);
                    this.phaseESPRender(blockPos, event, direction);
                }
                if (DirectionUtil.isCardinal(direction) && this.proneRender.getValue() && (PhaseESP.mc.field_1724.method_24828() || this.whileAirborne.getValue()) && PhaseESP.mc.field_1724.method_20232()) {
                    final class_2338 blockPos = direction.offset(playerPos);
                    this.proneESPRender(blockPos, event, direction);
                }
            }
        }
    }
    
    private void phaseESPRender(final class_2338 blockPos, final Render3DEvent event, final DirectionUtil.EightWayDirections direction) {
        if (!PhaseESP.mc.field_1687.method_8320(blockPos).method_45474()) {
            final class_2680 state = PhaseESP.mc.field_1687.method_8320(blockPos.method_10074());
            Color color = null;
            if (this.newColor.getValue()) {
                if (!state.method_45474()) {
                    return;
                }
                color = new Color(NewGui.getInstance().red.getValue(), NewGui.getInstance().green.getValue(), NewGui.getInstance().blue.getValue(), this.boxAlpha.getValue());
            }
            else if (state.method_45474()) {
                color = new Color(255, 0, 0, this.boxAlpha.getValue());
            }
            else if (state.method_26214((class_1922)PhaseESP.mc.field_1687, blockPos.method_10074()) < 0.0f) {
                color = new Color(0, 255, 0, this.boxAlpha.getValue());
            }
            else {
                color = new Color(255, 255, 0, this.boxAlpha.getValue());
            }
            final class_2338 playerPos = PhaseESP.mc.field_1724.method_24515();
            final class_243 pos = PhaseESP.mc.field_1724.method_19538();
            final double dx = pos.method_10216() - playerPos.method_10263();
            final double dz = pos.method_10215() - playerPos.method_10260();
            final double far = this.fadeDistance.getValue();
            final double near = 1.0 - this.fadeDistance.getValue();
            if (direction == DirectionUtil.EightWayDirections.EAST && dx >= far) {
                this.PhaseBoxRender(blockPos, event, color);
            }
            else if (direction == DirectionUtil.EightWayDirections.WEST && dx <= near) {
                this.PhaseBoxRender(blockPos, event, color);
            }
            else if (direction == DirectionUtil.EightWayDirections.SOUTH && dz >= far) {
                this.PhaseBoxRender(blockPos, event, color);
            }
            else if (direction == DirectionUtil.EightWayDirections.NORTH && dz <= near) {
                this.PhaseBoxRender(blockPos, event, color);
            }
            else if (direction == DirectionUtil.EightWayDirections.NORTHEAST && dz <= near && dx >= far) {
                this.PhaseBoxRender(blockPos, event, color);
            }
            else if (direction == DirectionUtil.EightWayDirections.NORTHWEST && dz <= near && dx <= near) {
                this.PhaseBoxRender(blockPos, event, color);
            }
            else if (direction == DirectionUtil.EightWayDirections.SOUTHEAST && dz >= far && dx >= far) {
                this.PhaseBoxRender(blockPos, event, color);
            }
            else if (direction == DirectionUtil.EightWayDirections.SOUTHWEST && dz >= far && dx <= near) {
                this.PhaseBoxRender(blockPos, event, color);
            }
        }
    }
    
    private void proneESPRender(final class_2338 blockPos, final Render3DEvent event, final DirectionUtil.EightWayDirections direction) {
        if (!PhaseESP.mc.field_1687.method_8320(blockPos).method_45474()) {
            final class_2680 state = PhaseESP.mc.field_1687.method_8320(blockPos.method_10084());
            Color color = null;
            if (!state.method_45474()) {
                return;
            }
            color = new Color(NewGui.getInstance().red.getValue(), NewGui.getInstance().green.getValue(), NewGui.getInstance().blue.getValue(), this.boxAlpha.getValue());
            final class_2338 playerPos = PhaseESP.mc.field_1724.method_24515();
            final class_243 pos = PhaseESP.mc.field_1724.method_19538();
            final double dx = pos.method_10216() - playerPos.method_10263();
            final double dz = pos.method_10215() - playerPos.method_10260();
            final double far = this.fadeDistance.getValue();
            final double near = 1.0 - this.fadeDistance.getValue();
            if (direction == DirectionUtil.EightWayDirections.EAST && dx >= far) {
                this.ProneBoxRender(blockPos, event, color);
            }
            else if (direction == DirectionUtil.EightWayDirections.WEST && dx <= near) {
                this.ProneBoxRender(blockPos, event, color);
            }
            else if (direction == DirectionUtil.EightWayDirections.SOUTH && dz >= far) {
                this.ProneBoxRender(blockPos, event, color);
            }
            else if (direction == DirectionUtil.EightWayDirections.NORTH && dz <= near) {
                this.ProneBoxRender(blockPos, event, color);
            }
            else if (direction == DirectionUtil.EightWayDirections.NORTHEAST && dz <= near && dx >= far) {
                this.ProneBoxRender(blockPos, event, color);
            }
            else if (direction == DirectionUtil.EightWayDirections.NORTHWEST && dz <= near && dx <= near) {
                this.ProneBoxRender(blockPos, event, color);
            }
            else if (direction == DirectionUtil.EightWayDirections.SOUTHEAST && dz >= far && dx >= far) {
                this.ProneBoxRender(blockPos, event, color);
            }
            else if (direction == DirectionUtil.EightWayDirections.SOUTHWEST && dz >= far && dx <= near) {
                this.ProneBoxRender(blockPos, event, color);
            }
        }
    }
    
    private void PhaseBoxRender(final class_2338 blockPos, final Render3DEvent event, final Color color) {
        final class_238 render1 = class_259.method_1077().method_1107();
        final class_238 render2 = new class_238(blockPos.method_10263() + render1.field_1323, blockPos.method_10264() + render1.field_1322, blockPos.method_10260() + render1.field_1321, blockPos.method_10263() + render1.field_1320, blockPos.method_10264() + render1.field_1322, blockPos.method_10260() + render1.field_1324);
        RenderUtil.drawBoxFilled(event.getMatrixStack(), render2, color);
        final Color lineColor = new Color(color.getRed(), color.getGreen(), color.getBlue(), this.lineAlpha.getValue());
        RenderUtil.drawBox(event.getMatrixStack(), render2, lineColor, this.lineWidth.getValue());
    }
    
    private void ProneBoxRender(final class_2338 blockPos, final Render3DEvent event, final Color color) {
        final class_238 render1 = class_259.method_1077().method_1107();
        final Color lineColor = new Color(color.getRed(), color.getGreen(), color.getBlue(), this.lineAlpha.getValue());
        switch (this.renderMode.getValue().ordinal()) {
            case 0: {
                final class_238 render2 = new class_238(blockPos.method_10263() + render1.field_1323, blockPos.method_10264() + render1.field_1325, blockPos.method_10260() + render1.field_1321, blockPos.method_10263() + render1.field_1320, blockPos.method_10264() + render1.field_1325, blockPos.method_10260() + render1.field_1324);
                RenderUtil.drawBoxFilled(event.getMatrixStack(), render2, color);
                RenderUtil.drawBox(event.getMatrixStack(), render2, lineColor, this.lineWidth.getValue());
                break;
            }
            case 1: {
                final class_238 render2 = new class_238(blockPos.method_10263() + render1.field_1323, blockPos.method_10264() + render1.field_1322, blockPos.method_10260() + render1.field_1321, blockPos.method_10263() + render1.field_1320, blockPos.method_10264() + render1.field_1322, blockPos.method_10260() + render1.field_1324);
                RenderUtil.drawBoxFilled(event.getMatrixStack(), render2, color);
                RenderUtil.drawBox(event.getMatrixStack(), render2, lineColor, this.lineWidth.getValue());
                break;
            }
            case 2: {
                final class_238 render2 = new class_238(blockPos.method_10263() + render1.field_1323, blockPos.method_10264() + render1.field_1322, blockPos.method_10260() + render1.field_1321, blockPos.method_10263() + render1.field_1320, blockPos.method_10264() + render1.field_1325, blockPos.method_10260() + render1.field_1324);
                RenderUtil.drawBoxFilled(event.getMatrixStack(), render2, color);
                RenderUtil.drawBox(event.getMatrixStack(), render2, lineColor, this.lineWidth.getValue());
                break;
            }
        }
    }
    
    public enum boxMode
    {
        TOP, 
        BOTTOM, 
        BOX;
    }
}
