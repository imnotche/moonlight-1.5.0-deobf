package me.twerknation28.moonlight.features.modules.combat;

import org.jetbrains.annotations.NotNull;
import me.twerknation28.moonlight.util.Util;
import net.minecraft.class_1268;
import net.minecraft.class_1297;
import net.minecraft.class_1657;
import net.minecraft.class_1922;
import net.minecraft.class_2338;
import net.minecraft.class_2350;
import net.minecraft.class_238;
import net.minecraft.class_243;
import net.minecraft.class_259;
import net.minecraft.class_2596;
import net.minecraft.class_265;
import net.minecraft.class_2680;
import net.minecraft.class_2846;
import net.minecraft.class_3532;
import net.minecraft.class_4587;
import net.minecraft.class_5253;
import net.minecraft.class_742;
import me.twerknation28.moonlight.manager.RotationManager;
import me.twerknation28.moonlight.manager.NetworkManager;
import java.util.List;
import me.twerknation28.moonlight.manager.HoleManager;
import me.twerknation28.moonlight.util.RenderUtil;
import java.awt.Color;
import me.twerknation28.moonlight.event.impl.Render3DEvent;
import me.twerknation28.moonlight.event.impl.PacketEvent;
import me.twerknation28.moonlight.event.impl.AttackBlockEvent;
import me.twerknation28.moonlight.event.EventListener;
import java.util.PriorityQueue;
import java.util.Iterator;
import me.twerknation28.moonlight.manager.FriendManager;
import me.twerknation28.moonlight.manager.InteractionManager;
import me.twerknation28.moonlight.manager.PositionManager;
import me.twerknation28.moonlight.manager.InventoryManager;
import me.twerknation28.moonlight.util.EvictingQueue;
import me.twerknation28.moonlight.features.api.Category;
import java.util.Deque;
import me.twerknation28.moonlight.features.settings.Setting;
import me.twerknation28.moonlight.features.modules.Module;

public class AutoMine extends Module
{
    private static AutoMine INSTANCE;
    public final Setting<Boolean> multitaskConfig;
    public final Setting<Boolean> autoConfig;
    public final Setting<Boolean> autoRemineConfig;
    public final Setting<Boolean> strictDirectionConfig;
    public final Setting<Float> enemyRangeConfig;
    public final Setting<Boolean> doubleBreakConfig;
    public final Setting<Boolean> safetyConfig;
    public final Setting<Float> rangeConfig;
    public final Setting<Float> speedConfig;
    public final Setting<Boolean> rotateConfig;
    public final Setting<Boolean> switchResetConfig;
    public final Setting<Boolean> instantConfig;
    public final Setting<Boolean> headFreeConfig;
    public final Setting<Double> linewidthConfig;
    public final Setting<Integer> alphaConfig;
    public final Setting<Integer> lineAlphaConfig;
    private Deque<MiningData> miningQueue;
    private long lastBreak;
    private boolean manualOverride;
    
    public AutoMine() {
        super("AutoMine", "Mines blocks for you...", Category.COMBAT, true, false, true);
        this.multitaskConfig = this.register(new Setting<Boolean>("Multitask", false));
        this.autoConfig = this.register(new Setting<Boolean>("Auto", true));
        this.autoRemineConfig = this.register(new Setting<Boolean>("AutoRemine", true, v -> this.autoConfig.getValue()));
        this.strictDirectionConfig = this.register(new Setting<Boolean>("StrictDirection", false, v -> this.autoConfig.getValue()));
        this.enemyRangeConfig = this.register(new Setting<Float>("EnemyRange", 5.0f, 1.0f, 10.0f, 0.1f, v -> this.autoConfig.getValue()));
        this.doubleBreakConfig = this.register(new Setting<Boolean>("DoubleBreak", true));
        this.safetyConfig = this.register(new Setting<Boolean>("Safety", true));
        this.rangeConfig = this.register(new Setting<Float>("Range", 4.0f, 0.1f, 5.0f, 0.1f));
        this.speedConfig = this.register(new Setting<Float>("Speed", 1.0f, 0.1f, 1.0f, 0.1f));
        this.rotateConfig = this.register(new Setting<Boolean>("Rotate", true));
        this.switchResetConfig = this.register(new Setting<Boolean>("SwitchReset", false));
        this.instantConfig = this.register(new Setting<Boolean>("Instant", true));
        this.headFreeConfig = this.register(new Setting<Boolean>("FreeHead", true));
        this.linewidthConfig = this.register(new Setting<Double>("Linewidth", 2.0, 0.1, 4.0, 0.1));
        this.alphaConfig = this.register(new Setting<Integer>("Box Alpha", 20, 0, 255, 1));
        this.lineAlphaConfig = this.register(new Setting<Integer>("Line Alpha", 70, 0, 255, 1));
        this.miningQueue = new EvictingQueue<MiningData>(2);
        this.setInstance();
    }
    
    public static AutoMine getInstance() {
        if (AutoMine.INSTANCE == null) {
            AutoMine.INSTANCE = new AutoMine();
        }
        return AutoMine.INSTANCE;
    }
    
    private void setInstance() {
        AutoMine.INSTANCE = this;
    }
    
    @Override
    public void onEnable() {
        if (this.doubleBreakConfig.getValue()) {
            this.miningQueue = new EvictingQueue<MiningData>(2);
        }
        else {
            this.miningQueue = new EvictingQueue<MiningData>(1);
        }
    }
    
    @Override
    public void onDisable() {
        this.miningQueue.clear();
        this.manualOverride = false;
        InventoryManager.syncToClient();
    }
    
    @EventListener
    @Override
    public void onTick() {
        InventoryManager.syncToClient();
        MiningData miningData = null;
        if (!this.miningQueue.isEmpty()) {
            miningData = this.miningQueue.getFirst();
        }
        if (AutoMine.mc.field_1724.method_20232() && this.headFreeConfig.getValue()) {
            final class_2338 headBreakPos = PositionManager.getPlayerPos().method_10086(1);
            if (AutoMine.mc.field_1687.method_8320(headBreakPos).method_26204().method_36555() != -1.0f && !AutoMine.mc.field_1687.method_8320(headBreakPos).method_26215() && !AutoMine.mc.field_1724.method_7337()) {
                final MiningData headBreak = new MiningData(headBreakPos, this.strictDirectionConfig.getValue() ? InteractionManager.getPlaceDirectionGrim(headBreakPos) : class_2350.field_11036);
                this.overrideSet(headBreak);
            }
        }
        if (this.autoConfig.getValue() && !this.manualOverride && (miningData == null || AutoMine.mc.field_1687.method_22347(miningData.getPos()))) {
            class_1657 playerTarget = null;
            double distance = 3.4028234663852886E38;
            for (final class_1657 entity : AutoMine.mc.field_1687.method_18456()) {
                final class_742 abstractClientPlayerEntity = (class_742)entity;
                if (entity != AutoMine.mc.field_1724 && !FriendManager.isFriend(entity.method_5477().getString())) {
                    final double dist = AutoMine.mc.field_1724.method_5739((class_1297)entity);
                    if (dist > this.enemyRangeConfig.getValue() || dist >= distance) {
                        continue;
                    }
                    distance = dist;
                    playerTarget = entity;
                }
            }
            if (playerTarget != null) {
                final PriorityQueue<AutoMineCalc> miningPositions = this.getMiningPosition(playerTarget);
                final PriorityQueue<AutoMineCalc> miningPositionsNoAir = this.getNoAir(miningPositions);
                final PriorityQueue<AutoMineCalc> cityPositions = this.autoRemineConfig.getValue() ? miningPositions : miningPositionsNoAir;
                if (cityPositions.isEmpty()) {
                    return;
                }
                if (this.doubleBreakConfig.getValue()) {
                    final AutoMineCalc cityPos = cityPositions.poll();
                    if (cityPos != null) {
                        miningPositionsNoAir.remove(cityPos);
                        class_2338 cityPos2 = null;
                        if (!miningPositionsNoAir.isEmpty()) {
                            cityPos2 = miningPositionsNoAir.poll().pos();
                        }
                        if (cityPos2 != null && cityPos.pos() != cityPos2) {
                            if (!AutoMine.mc.field_1687.method_22347(cityPos.pos()) && !AutoMine.mc.field_1687.method_22347(cityPos2) && !this.isBlockDelayGrim()) {
                                final AutoMiningData data1 = new AutoMiningData(cityPos2, this.strictDirectionConfig.getValue() ? InteractionManager.getPlaceDirectionGrim(cityPos2) : class_2350.field_11036);
                                final MiningData data2 = new AutoMiningData(cityPos.pos(), this.strictDirectionConfig.getValue() ? InteractionManager.getPlaceDirectionGrim(cityPos.pos()) : class_2350.field_11036);
                                this.startMining(data1);
                                this.startMining(data2);
                                this.miningQueue.addFirst(data1);
                                this.miningQueue.addFirst(data2);
                            }
                        }
                        else if (!AutoMine.mc.field_1687.method_22347(cityPos.pos()) && !this.isBlockDelayGrim()) {
                            final AutoMiningData data1 = new AutoMiningData(cityPos.pos(), this.strictDirectionConfig.getValue() ? InteractionManager.getPlaceDirectionGrim(cityPos.pos()) : class_2350.field_11036);
                            this.startMining(data1);
                            this.miningQueue.addFirst(data1);
                        }
                    }
                }
                else {
                    final AutoMineCalc cityPos = cityPositions.poll();
                    if (cityPos != null && !this.isBlockDelayGrim()) {
                        if (miningData instanceof AutoMiningData && miningData.isInstantRemine() && !AutoMine.mc.field_1687.method_22347(miningData.getPos()) && this.autoRemineConfig.getValue()) {
                            this.stopMining(miningData);
                            InventoryManager.syncToClient();
                        }
                        else if (!AutoMine.mc.field_1687.method_22347(cityPos.pos()) && !this.isBlockDelayGrim()) {
                            final MiningData data3 = new AutoMiningData(cityPos.pos(), this.strictDirectionConfig.getValue() ? InteractionManager.getPlaceDirectionGrim(cityPos.pos()) : class_2350.field_11036);
                            this.startMining(data3);
                            this.miningQueue.addFirst(data3);
                        }
                    }
                }
            }
        }
        if (!this.miningQueue.isEmpty()) {
            for (final MiningData data4 : this.miningQueue) {
                if (data4.getState().method_26215()) {
                    InventoryManager.swapBack();
                    if (this.isDataPacketMine(data4)) {
                        this.miningQueue.remove(data4);
                        return;
                    }
                }
                final float damageDelta = InteractionManager.calcBlockBreakingDelta(data4.getState(), (class_1922)AutoMine.mc.field_1687, data4.getPos());
                data4.damage(damageDelta);
                if (data4.getBlockDamage() >= 1.0f && this.isDataPacketMine(data4)) {
                    if (AutoMine.mc.field_1724.method_6115() && !this.multitaskConfig.getValue()) {
                        return;
                    }
                    if (data4.getSlot() == -1) {
                        continue;
                    }
                    InventoryManager.setSlotLoud(data4.getSlot());
                }
            }
            final MiningData miningData2 = this.miningQueue.getFirst();
            if (miningData2 != null) {
                final double distance = AutoMine.mc.field_1724.method_33571().method_1025(miningData2.getPos().method_46558());
                if (distance > this.rangeConfig.getValue() * (double)this.rangeConfig.getValue()) {
                    this.miningQueue.remove(miningData2);
                    return;
                }
                if (miningData2.getState().method_26215()) {
                    if (this.manualOverride) {
                        this.manualOverride = false;
                        this.miningQueue.remove(miningData2);
                        return;
                    }
                    if (this.instantConfig.getValue()) {
                        if (miningData2 instanceof AutoMiningData && !this.autoRemineConfig.getValue()) {
                            this.miningQueue.remove(miningData2);
                            return;
                        }
                        miningData2.setInstantRemine();
                        miningData2.setDamage(1.0f);
                    }
                    else {
                        miningData2.resetDamage();
                    }
                    return;
                }
                else if (miningData2.getBlockDamage() >= this.speedConfig.getValue() || miningData2.isInstantRemine()) {
                    if (AutoMine.mc.field_1724.method_6115() && !this.multitaskConfig.getValue()) {
                        return;
                    }
                    this.stopMining(miningData2);
                    InventoryManager.syncToClient();
                }
            }
        }
        InventoryManager.syncToClient();
    }
    
    @EventListener
    @Override
    public void onAttackBlock(final AttackBlockEvent event) {
        if (event.getState().method_26204().method_36555() != -1.0f && !event.getState().method_26215() && !AutoMine.mc.field_1724.method_7337()) {
            event.cancel();
            final MiningData miningData = new MiningData(event.getPos(), event.getDirection());
            this.overrideSet(miningData);
        }
    }
    
    public void overrideSet(final MiningData miningData) {
        final int queueSize = this.miningQueue.size();
        if (queueSize == 0) {
            this.attemptMine(miningData.getPos(), miningData.getDirection());
        }
        else if (queueSize == 1) {
            final MiningData data1 = this.miningQueue.getFirst();
            if (data1.getPos().equals((Object)miningData.getPos())) {
                return;
            }
            if (data1 instanceof AutoMiningData) {
                this.manualOverride = true;
            }
            this.attemptMine(miningData.getPos(), miningData.getDirection());
        }
        else if (queueSize == 2) {
            final MiningData data1 = this.miningQueue.getFirst();
            final MiningData data2 = this.miningQueue.getLast();
            if (data1.getPos().equals((Object)miningData.getPos()) || data2.getPos().equals((Object)miningData.getPos())) {
                return;
            }
            if (data1 instanceof AutoMiningData || data2 instanceof AutoMiningData) {
                this.manualOverride = true;
            }
            this.attemptMine(miningData.getPos(), miningData.getDirection());
        }
        AutoMine.mc.field_1724.method_6104(class_1268.field_5808);
    }
    
    @EventListener
    @Override
    public void onPacketSend(final PacketEvent.Send event) {
        if (event.getPacket() instanceof class_2596 && this.switchResetConfig.getValue()) {
            for (final MiningData data : this.miningQueue) {
                data.resetDamage();
            }
        }
    }
    
    @EventListener
    @Override
    public void onRender3D(final Render3DEvent event) {
        for (final MiningData data : this.miningQueue) {
            this.renderMiningData(event.getMatrixStack(), data);
        }
    }
    
    private void renderMiningData(final class_4587 matrixStack, final MiningData data) {
        if (data != null && !AutoMine.mc.field_1724.method_7337() && data.getBlockDamage() > 0.01f) {
            final float miningSpeed = this.isDataPacketMine(data) ? 1.0f : this.speedConfig.getValue();
            final class_2338 mining = data.getPos();
            class_265 outlineShape = class_259.method_1077();
            if (!data.isInstantRemine()) {
                outlineShape = data.getState().method_26218((class_1922)AutoMine.mc.field_1687, mining);
                outlineShape = (outlineShape.method_1110() ? class_259.method_1077() : outlineShape);
            }
            final class_238 render1 = outlineShape.method_1107();
            final class_238 render2 = new class_238(mining.method_10263() + render1.field_1323, mining.method_10264() + render1.field_1322, mining.method_10260() + render1.field_1321, mining.method_10263() + render1.field_1320, mining.method_10264() + render1.field_1325, mining.method_10260() + render1.field_1324);
            final class_243 center = render2.method_1005();
            final float scale = class_3532.method_15363(data.getBlockDamage() / miningSpeed, 0.0f, 1.0f);
            final double dx = (render1.field_1320 - render1.field_1323) / 2.0;
            final double dy = (render1.field_1325 - render1.field_1322) / 2.0;
            final double dz = (render1.field_1324 - render1.field_1321) / 2.0;
            final class_238 scaled = new class_238(center, center).method_1009(dx * scale, dy * scale, dz * scale);
            final int colourint = (data.getBlockDamage() > 0.95f * miningSpeed) ? 1610678016 : 1627324416;
            final Color colour = new Color(class_5253.class_5254.method_27765(colourint), class_5253.class_5254.method_27766(colourint), class_5253.class_5254.method_27767(colourint), this.alphaConfig.getValue());
            final Color linecolour = new Color(class_5253.class_5254.method_27765(colourint), class_5253.class_5254.method_27766(colourint), class_5253.class_5254.method_27767(colourint), this.lineAlphaConfig.getValue());
            RenderUtil.drawBoxFilled(matrixStack, scaled, colour);
            RenderUtil.drawBox(matrixStack, scaled, linecolour, this.linewidthConfig.getValue());
        }
    }
    
    private PriorityQueue<AutoMineCalc> getNoAir(final PriorityQueue<AutoMineCalc> calcs) {
        final PriorityQueue<AutoMineCalc> noAir = new PriorityQueue<AutoMineCalc>();
        for (final AutoMineCalc calc : calcs) {
            if (!AutoMine.mc.field_1687.method_22347(calc.pos())) {
                noAir.add(calc);
            }
        }
        return noAir;
    }
    
    private PriorityQueue<AutoMineCalc> getMiningPosition(final class_1657 entity) {
        final List<class_2338> entityIntersections = HoleManager.getSurroundEntities((class_1297)entity);
        final PriorityQueue<AutoMineCalc> miningPositions = new PriorityQueue<AutoMineCalc>();
        for (final class_2338 blockPos : entityIntersections) {
            final double dist = AutoMine.mc.field_1724.method_33571().method_1025(blockPos.method_46558());
            if (dist <= this.rangeConfig.getValue() * (double)this.rangeConfig.getValue() && !AutoMine.mc.field_1687.method_8320(blockPos).method_45474() && !this.isSelfBlock(blockPos)) {
                miningPositions.add(new AutoMineCalc(blockPos, Double.MAX_VALUE));
            }
        }
        final List<class_2338> surroundBlocks = HoleManager.getEntitySurroundNoSupport((class_1297)entity);
        for (final class_2338 blockPos2 : surroundBlocks) {
            final double dist2 = AutoMine.mc.field_1724.method_33571().method_1025(blockPos2.method_46558());
            if (dist2 <= this.rangeConfig.getValue() * (double)this.rangeConfig.getValue()) {
                final double damage = 15.0;
                if (this.isSelfBlock(blockPos2)) {
                    continue;
                }
                miningPositions.add(new AutoMineCalc(blockPos2, damage));
            }
        }
        return miningPositions;
    }
    
    private void attemptMine(final class_2338 pos, final class_2350 direction) {
        if (!this.isBlockDelayGrim()) {
            final MiningData miningData = new MiningData(pos, direction);
            this.startMining(miningData);
            this.miningQueue.addFirst(miningData);
        }
    }
    
    private void startMining(final MiningData data) {
        if (!data.getState().method_26215() && !data.isStarted()) {
            NetworkManager.sendSequencedPacket(id -> new class_2846(class_2846.class_2847.field_12973, data.getPos(), data.getDirection(), id));
            NetworkManager.sendSequencedPacket(id -> new class_2846(class_2846.class_2847.field_12968, data.getPos(), data.getDirection(), id));
            if (this.doubleBreakConfig.getValue()) {
                NetworkManager.sendSequencedPacket(id -> new class_2846(class_2846.class_2847.field_12973, data.getPos(), data.getDirection(), id));
            }
            data.setStarted();
        }
    }
    
    private void abortMining(final MiningData data) {
        if (data.isStarted() && !data.getState().method_26215() && !data.isInstantRemine() && data.getBlockDamage() < 1.0f) {
            NetworkManager.sendSequencedPacket(id -> new class_2846(class_2846.class_2847.field_12971, data.getPos(), data.getDirection(), id));
            InventoryManager.syncToClient();
        }
    }
    
    private boolean isSelfBlock(final class_2338 target) {
        return this.safetyConfig.getValue() && target.equals((Object)PositionManager.getPlayerPos());
    }
    
    private void stopMining(final MiningData data) {
        if (data.isStarted() && !data.getState().method_26215()) {
            final boolean canSwap = data.getSlot() != -1;
            if (canSwap) {
                InventoryManager.setSlotLoud(data.getSlot());
            }
            if (this.rotateConfig.getValue()) {
                final float[] rotations = RotationManager.getRotationsTo(AutoMine.mc.field_1724.method_33571(), data.getPos().method_46558());
                RotationManager.setRotationSilent(rotations[0], rotations[1], true);
            }
            NetworkManager.sendSequencedPacket(id -> new class_2846(class_2846.class_2847.field_12973, data.getPos(), data.getDirection(), id));
            this.lastBreak = System.currentTimeMillis();
            if (canSwap) {
                InventoryManager.syncToClient();
            }
            if (this.rotateConfig.getValue()) {
                RotationManager.setRotationSilentSync(true);
            }
        }
    }
    
    private boolean isDataPacketMine(final MiningData data) {
        return this.miningQueue.size() == 2 && data == this.miningQueue.getLast();
    }
    
    public boolean isBlockDelayGrim() {
        return System.currentTimeMillis() - this.lastBreak <= 280L;
    }
    
    static {
        AutoMine.INSTANCE = new AutoMine();
    }
    
    public static class MiningData
    {
        private final class_2338 pos;
        private final class_2350 direction;
        private float blockDamage;
        private boolean instantRemine;
        private boolean started;
        
        public MiningData(final class_2338 pos, final class_2350 direction) {
            this.pos = pos;
            this.direction = direction;
        }
        
        public boolean isInstantRemine() {
            return this.instantRemine;
        }
        
        public void setInstantRemine() {
            this.instantRemine = true;
        }
        
        public float damage(final float dmg) {
            return this.blockDamage += dmg;
        }
        
        public void setDamage(final float blockDamage) {
            this.blockDamage = blockDamage;
        }
        
        public void resetDamage() {
            this.instantRemine = false;
            this.blockDamage = 0.0f;
        }
        
        public class_2338 getPos() {
            return this.pos;
        }
        
        public class_2350 getDirection() {
            return this.direction;
        }
        
        public int getSlot() {
            return InventoryManager.getBestToolNoFallback(this.getState());
        }
        
        public class_2680 getState() {
            return Util.mc.field_1687.method_8320(this.pos);
        }
        
        public boolean isStarted() {
            return this.started;
        }
        
        public void setStarted() {
            this.started = true;
        }
        
        public float getBlockDamage() {
            return this.blockDamage;
        }
    }
    
    record AutoMineCalc(class_2338 pos, double entityDamage) implements Comparable<AutoMineCalc> {
        @Override
        public int compareTo(@NotNull final AutoMineCalc o) {
            return Double.compare(-this.entityDamage(), -o.entityDamage());
        }
    }
    
    public static class AutoMiningData extends MiningData
    {
        public AutoMiningData(final class_2338 pos, final class_2350 direction) {
            super(pos, direction);
        }
    }
}
