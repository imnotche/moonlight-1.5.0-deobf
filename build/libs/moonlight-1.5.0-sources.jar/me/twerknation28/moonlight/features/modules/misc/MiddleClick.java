package me.twerknation28.moonlight.features.modules.misc;

import me.twerknation28.moonlight.features.commands.Command;
import me.twerknation28.moonlight.Moonlight;
import me.twerknation28.moonlight.manager.FriendManager;
import me.twerknation28.moonlight.manager.InventoryManager;
import net.minecraft.class_124;
import net.minecraft.class_1268;
import net.minecraft.class_1297;
import net.minecraft.class_1657;
import net.minecraft.class_1776;
import net.minecraft.class_1781;
import net.minecraft.class_1799;
import net.minecraft.class_1802;
import org.lwjgl.glfw.GLFW;
import me.twerknation28.moonlight.features.api.Category;
import me.twerknation28.moonlight.features.settings.Setting;
import me.twerknation28.moonlight.features.modules.Module;

public class MiddleClick extends Module
{
    private boolean pressed;
    public final Setting<Boolean> friend;
    public final Setting<Boolean> pearl;
    public final Setting<Boolean> firework;
    
    public MiddleClick() {
        super("MiddleClick", "Does things when you middle click", Category.PLAYER, true, false, false);
        this.friend = this.register(new Setting<Boolean>("Friend", true));
        this.pearl = this.register(new Setting<Boolean>("Pearl", true));
        this.firework = this.register(new Setting<Boolean>("Firework", true));
    }
    
    @Override
    public void onTick() {
        if (GLFW.glfwGetMouseButton(MiddleClick.mc.method_22683().method_4490(), 2) == 1) {
            if (!this.pressed) {
                final class_1297 targetedEntity = MiddleClick.mc.field_1692;
                if (MiddleClick.mc.field_1724.method_6128() && this.firework.getValue()) {
                    int rocketSlot = -1;
                    for (int i = 0; i < 9; ++i) {
                        final class_1799 stack = MiddleClick.mc.field_1724.method_31548().method_5438(i);
                        if (stack.method_7909() instanceof class_1781) {
                            rocketSlot = i;
                            break;
                        }
                    }
                    InventoryManager.setSlot(rocketSlot);
                    MiddleClick.mc.field_1761.method_2919((class_1657)MiddleClick.mc.field_1724, class_1268.field_5808);
                    InventoryManager.syncToClient();
                }
                else if (targetedEntity instanceof class_1657 && this.friend.getValue()) {
                    final String name = ((class_1657)targetedEntity).method_7334().getName();
                    if (FriendManager.isFriend(name)) {
                        Moonlight.friendManager.removeFriend(name);
                        Command.sendMessage(String.valueOf(class_124.field_1061) + name + String.valueOf(class_124.field_1061) + " has been unfriended.");
                    }
                    else {
                        Moonlight.friendManager.addFriend(name);
                        Command.sendMessage(String.valueOf(class_124.field_1075) + name + String.valueOf(class_124.field_1075) + " has been friended.");
                    }
                }
                else if (this.pearl.getValue()) {
                    int pearlSlot = -1;
                    for (int i = 0; i < 9; ++i) {
                        assert MiddleClick.mc.field_1724 != null;
                        final class_1799 stack = MiddleClick.mc.field_1724.method_31548().method_5438(i);
                        if (stack.method_7909() instanceof class_1776) {
                            pearlSlot = i;
                            break;
                        }
                    }
                    if (pearlSlot != -1 && !MiddleClick.mc.field_1724.method_7357().method_7904(class_1802.field_8634)) {
                        InventoryManager.setSlot(pearlSlot);
                        MiddleClick.mc.field_1761.method_2919((class_1657)MiddleClick.mc.field_1724, class_1268.field_5808);
                        InventoryManager.syncToClient();
                    }
                }
                this.pressed = true;
            }
        }
        else {
            this.pressed = false;
        }
    }
}
