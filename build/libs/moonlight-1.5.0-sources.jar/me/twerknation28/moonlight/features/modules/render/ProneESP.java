package me.twerknation28.moonlight.features.modules.render;

import me.twerknation28.moonlight.util.RenderUtil;
import net.minecraft.class_2338;
import net.minecraft.class_238;
import net.minecraft.class_243;
import net.minecraft.class_259;
import net.minecraft.class_2680;
import java.awt.Color;
import me.twerknation28.moonlight.features.modules.client.NewGui;
import me.twerknation28.moonlight.event.EventListener;
import me.twerknation28.moonlight.util.DirectionUtil;
import me.twerknation28.moonlight.event.impl.Render3DEvent;
import me.twerknation28.moonlight.features.api.Category;
import me.twerknation28.moonlight.features.settings.Setting;
import me.twerknation28.moonlight.features.modules.Module;

public class ProneESP extends Module
{
    public final Setting<Integer> boxAlpha;
    public final Setting<Integer> lineAlpha;
    public final Setting<Double> lineWidth;
    public final Setting<Double> fadeDistance;
    public Setting<Boolean> whileAirborne;
    public Setting<boxMode> renderMode;
    
    public ProneESP() {
        super("ProneESP", "Shows where to phase out of crawl", Category.RENDER, true, false, false);
        this.boxAlpha = this.register(new Setting<Integer>("BoxAlpha", 15, 0, 255, 1));
        this.lineAlpha = this.register(new Setting<Integer>("LineAlpha", 50, 0, 255, 1));
        this.lineWidth = this.register(new Setting<Double>("LineWidth", 2.0, 0.1, 4.0, 0.1));
        this.fadeDistance = this.register(new Setting<Double>("FadeDist", 0.5, 0.0, 1.0, 0.1));
        this.whileAirborne = this.register(new Setting<Boolean>("WhileAirborne", false));
        this.renderMode = this.register(new Setting<boxMode>("RenderMode", boxMode.TOP));
    }
    
    @EventListener
    @Override
    public void onRender3D(final Render3DEvent event) {
        if (ProneESP.mc.field_1724 != null && ProneESP.mc.field_1687 != null && ProneESP.mc.field_1724.method_20232()) {
            if (!ProneESP.mc.field_1724.method_24828() && !this.whileAirborne.getValue()) {
                return;
            }
            final class_2338 playerPos = ProneESP.mc.field_1724.method_24515();
            for (final DirectionUtil.EightWayDirections direction : DirectionUtil.EightWayDirections.values()) {
                if (DirectionUtil.isCardinal(direction)) {
                    final class_2338 blockPos = direction.offset(playerPos);
                    this.proneESPRender(blockPos, event, direction);
                }
            }
        }
    }
    
    private void proneESPRender(final class_2338 blockPos, final Render3DEvent event, final DirectionUtil.EightWayDirections direction) {
        if (!ProneESP.mc.field_1687.method_8320(blockPos).method_45474()) {
            final class_2680 state = ProneESP.mc.field_1687.method_8320(blockPos.method_10084());
            Color color = null;
            if (!state.method_45474()) {
                return;
            }
            color = new Color(NewGui.getInstance().red.getValue(), NewGui.getInstance().green.getValue(), NewGui.getInstance().blue.getValue(), this.boxAlpha.getValue());
            final class_2338 playerPos = ProneESP.mc.field_1724.method_24515();
            final class_243 pos = ProneESP.mc.field_1724.method_19538();
            final double dx = pos.method_10216() - playerPos.method_10263();
            final double dz = pos.method_10215() - playerPos.method_10260();
            final double far = this.fadeDistance.getValue();
            final double near = 1.0 - this.fadeDistance.getValue();
            if (direction == DirectionUtil.EightWayDirections.EAST && dx >= far) {
                this.BoxRender(blockPos, event, color);
            }
            else if (direction == DirectionUtil.EightWayDirections.WEST && dx <= near) {
                this.BoxRender(blockPos, event, color);
            }
            else if (direction == DirectionUtil.EightWayDirections.SOUTH && dz >= far) {
                this.BoxRender(blockPos, event, color);
            }
            else if (direction == DirectionUtil.EightWayDirections.NORTH && dz <= near) {
                this.BoxRender(blockPos, event, color);
            }
            else if (direction == DirectionUtil.EightWayDirections.NORTHEAST && dz <= near && dx >= far) {
                this.BoxRender(blockPos, event, color);
            }
            else if (direction == DirectionUtil.EightWayDirections.NORTHWEST && dz <= near && dx <= near) {
                this.BoxRender(blockPos, event, color);
            }
            else if (direction == DirectionUtil.EightWayDirections.SOUTHEAST && dz >= far && dx >= far) {
                this.BoxRender(blockPos, event, color);
            }
            else if (direction == DirectionUtil.EightWayDirections.SOUTHWEST && dz >= far && dx <= near) {
                this.BoxRender(blockPos, event, color);
            }
        }
    }
    
    private void BoxRender(final class_2338 blockPos, final Render3DEvent event, final Color color) {
        final class_238 render1 = class_259.method_1077().method_1107();
        final Color lineColor = new Color(color.getRed(), color.getGreen(), color.getBlue(), this.lineAlpha.getValue());
        switch (this.renderMode.getValue().ordinal()) {
            case 0: {
                final class_238 render2 = new class_238(blockPos.method_10263() + render1.field_1323, blockPos.method_10264() + render1.field_1325, blockPos.method_10260() + render1.field_1321, blockPos.method_10263() + render1.field_1320, blockPos.method_10264() + render1.field_1325, blockPos.method_10260() + render1.field_1324);
                RenderUtil.drawBoxFilled(event.getMatrixStack(), render2, color);
                RenderUtil.drawBox(event.getMatrixStack(), render2, lineColor, this.lineWidth.getValue());
                break;
            }
            case 1: {
                final class_238 render2 = new class_238(blockPos.method_10263() + render1.field_1323, blockPos.method_10264() + render1.field_1322, blockPos.method_10260() + render1.field_1321, blockPos.method_10263() + render1.field_1320, blockPos.method_10264() + render1.field_1322, blockPos.method_10260() + render1.field_1324);
                RenderUtil.drawBoxFilled(event.getMatrixStack(), render2, color);
                RenderUtil.drawBox(event.getMatrixStack(), render2, lineColor, this.lineWidth.getValue());
                break;
            }
            case 2: {
                final class_238 render2 = new class_238(blockPos.method_10263() + render1.field_1323, blockPos.method_10264() + render1.field_1322, blockPos.method_10260() + render1.field_1321, blockPos.method_10263() + render1.field_1320, blockPos.method_10264() + render1.field_1325, blockPos.method_10260() + render1.field_1324);
                RenderUtil.drawBoxFilled(event.getMatrixStack(), render2, color);
                RenderUtil.drawBox(event.getMatrixStack(), render2, lineColor, this.lineWidth.getValue());
                break;
            }
        }
    }
    
    public enum boxMode
    {
        TOP, 
        BOTTOM, 
        BOX;
    }
}
