package me.twerknation28.moonlight.features.modules.client;

import me.twerknation28.moonlight.features.commands.Command;
import java.util.Iterator;
import java.util.concurrent.CopyOnWriteArrayList;
import me.twerknation28.moonlight.features.api.Category;
import java.util.List;
import me.twerknation28.moonlight.features.settings.Setting;
import net.minecraft.class_742;
import me.twerknation28.moonlight.features.modules.Module;

public class Notifications extends Module
{
    private static Notifications INSTANCE;
    public final Setting<Boolean> modToggles;
    public final Setting<Boolean> visualRange;
    public final Setting<Boolean> compact;
    private final List<class_742> players;
    
    public Notifications() {
        super("Notifications", "Turning this off gets your discord token logged and your pc nuked", Category.CLIENT, true, false, true);
        this.modToggles = this.register(new Setting<Boolean>("Modules", true));
        this.visualRange = this.register(new Setting<Boolean>("VisualRange", true));
        this.compact = this.register(new Setting<Boolean>("Compact", true));
        this.players = new CopyOnWriteArrayList<class_742>();
        this.setInstance();
    }
    
    @Override
    public void onEnable() {
        if (this.visualRange.getValue()) {
            super.onEnable();
            this.players.clear();
            if (fullNullCheck()) {
                return;
            }
            for (final class_742 entity : Notifications.mc.field_1687.method_18456()) {
                if (entity == Notifications.mc.field_1724) {
                    continue;
                }
                this.players.add(entity);
            }
        }
    }
    
    @Override
    public void onUpdate() {
        if (this.visualRange.getValue()) {
            final List<class_742> currentPlayers = Notifications.mc.field_1687.method_18456();
            for (class_742 entity : currentPlayers) {
                if (!this.players.contains(entity)) {
                    if (this.compact.getValue()) {
                        Command.visualRangeMessage(entity.method_5477().getString(), true);
                    }
                    else {
                        Command.sendMessage(entity.method_5477().getString() + " has entered your visual range");
                    }
                    this.players.add(entity);
                }
            }
            for (class_742 entity : this.players) {
                if (!currentPlayers.contains(entity)) {
                    if (this.compact.getValue()) {
                        Command.visualRangeMessage(entity.method_5477().getString(), false);
                    }
                    else {
                        Command.sendMessage(entity.method_5477().getString() + " has left your visual range");
                    }
                    this.players.remove(entity);
                }
            }
        }
    }
    
    public static Notifications getInstance() {
        if (Notifications.INSTANCE == null) {
            Notifications.INSTANCE = new Notifications();
        }
        return Notifications.INSTANCE;
    }
    
    private void setInstance() {
        Notifications.INSTANCE = this;
    }
    
    static {
        Notifications.INSTANCE = new Notifications();
    }
}
