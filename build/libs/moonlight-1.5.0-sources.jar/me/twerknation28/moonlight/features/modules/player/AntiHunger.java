package me.twerknation28.moonlight.features.modules.player;

import com.google.common.eventbus.Subscribe;
import me.twerknation28.moonlight.event.impl.PacketEvent;
import me.twerknation28.moonlight.features.api.Category;
import me.twerknation28.moonlight.features.settings.Setting;
import net.minecraft.class_2596;
import net.minecraft.class_2828;
import net.minecraft.class_2848;
import me.twerknation28.moonlight.features.modules.Module;

public class AntiHunger extends Module
{
    public Setting<Boolean> ground;
    public Setting<Boolean> sprint;
    
    public AntiHunger() {
        super("AntiHunger", "Conserves food by cancelling certain packets", Category.PLAYER, true, false, false);
        this.ground = this.register(new Setting<Boolean>("Ground", true));
        this.sprint = this.register(new Setting<Boolean>("Sprint", true));
    }
    
    @Subscribe
    @Override
    public void onPacketSend(final PacketEvent.Send event) {
        if (event.getPacket() instanceof class_2828 && this.ground.getValue()) {
            assert AntiHunger.mc.field_1724 != null;
            AntiHunger.mc.field_1724.method_24830(false);
        }
        final class_2596<?> packet = event.getPacket();
        if (packet instanceof final class_2848 pac) {
            if (this.sprint.getValue() && pac.method_12365() == class_2848.class_2849.field_12981) {
                event.cancel();
            }
        }
    }
}
