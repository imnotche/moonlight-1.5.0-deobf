package me.twerknation28.moonlight.features.modules.movement;

import com.google.common.eventbus.Subscribe;
import me.twerknation28.moonlight.event.impl.PlayerMoveEvent;
import me.twerknation28.moonlight.features.api.Category;
import me.twerknation28.moonlight.features.settings.Setting;
import me.twerknation28.moonlight.features.modules.Module;

public class Speed extends Module
{
    private boolean jumping;
    public Setting<speedMode> mode;
    public Setting<Float> speedFactor;
    public Setting<Boolean> autoJump;
    
    public Speed() {
        super("Speed", "Makes you faster", Category.PLAYER, true, false, false);
        this.mode = this.register(new Setting<speedMode>("Mode", speedMode.OnGround));
        this.speedFactor = this.register(new Setting<Float>("Speed", 1.0f, 1.0f, 30.0f, 1.0f));
        this.autoJump = this.register(new Setting<Boolean>("AutoJump", true, v -> this.mode.getValue() == speedMode.OnGround));
    }
    
    @Subscribe
    public void onMove(final PlayerMoveEvent event) {
        if (Speed.mc.field_1690.field_1903.method_1434() || Speed.mc.field_1724.field_6017 > 0.25) {
            return;
        }
        final float speed = 1.0f + this.speedFactor.getValue() / 30.0f;
        if (this.jumping && Speed.mc.field_1724.method_23318() >= Speed.mc.field_1724.field_6036 + 0.399994) {
            Speed.mc.field_1724.method_18800(Speed.mc.field_1724.method_18798().field_1352, -0.9, Speed.mc.field_1724.method_18798().field_1350);
            Speed.mc.field_1724.method_23327(Speed.mc.field_1724.method_23317(), Speed.mc.field_1724.field_6036, Speed.mc.field_1724.method_23321());
            this.jumping = false;
        }
        if (Speed.mc.field_1724.field_6250 != 0.0f && !Speed.mc.field_1724.field_5976) {
            if (Speed.mc.field_1724.field_5992) {
                Speed.mc.field_1724.method_18800(Speed.mc.field_1724.method_18798().field_1352 * speed, Speed.mc.field_1724.method_18798().field_1351, Speed.mc.field_1724.method_18798().field_1350 * speed);
                if (this.autoJump.getValue()) {
                    this.jumping = true;
                    Speed.mc.field_1724.method_6043();
                }
            }
            if (this.jumping && Speed.mc.field_1724.method_23318() >= Speed.mc.field_1724.field_6036 + 0.399994) {
                Speed.mc.field_1724.method_18800(Speed.mc.field_1724.method_18798().field_1352, -100.0, Speed.mc.field_1724.method_18798().field_1350);
                this.jumping = false;
            }
        }
    }
    
    public enum speedMode
    {
        OnGround;
    }
}
