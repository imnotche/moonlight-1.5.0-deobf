package me.twerknation28.moonlight.features.modules.movement;

import com.google.common.eventbus.Subscribe;
import me.twerknation28.moonlight.event.impl.UpdateWalkingPlayerEvent;
import me.twerknation28.moonlight.features.api.Category;
import me.twerknation28.moonlight.features.settings.Setting;
import me.twerknation28.moonlight.features.modules.Module;

public class Sprint extends Module
{
    public Setting<sprintMode> mode;
    
    public Sprint() {
        super("Sprint", "Automatically sprints", Category.PLAYER, true, false, false);
        this.mode = this.register(new Setting<sprintMode>("Mode", sprintMode.LEGIT));
    }
    
    @Subscribe
    private void onUpdateWalkingPlayer(final UpdateWalkingPlayerEvent event) {
        if (this.mode.getValue() == sprintMode.RAGE) {
            if (Sprint.mc.field_1724.field_6250 != 0.0f || Sprint.mc.field_1724.field_5973 != 0.0f) {
                Sprint.mc.field_1724.method_5728(true);
            }
        }
        else if (Sprint.mc.field_1724.field_6250 >= 0.8f && Sprint.mc.field_1724.method_7344().method_7586() > 6.0f) {
            Sprint.mc.field_1724.method_5728(true);
        }
    }
    
    public enum sprintMode
    {
        LEGIT, 
        RAGE;
    }
}
