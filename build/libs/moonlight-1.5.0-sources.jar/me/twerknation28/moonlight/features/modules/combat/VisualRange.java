package me.twerknation28.moonlight.features.modules.combat;

import me.twerknation28.moonlight.features.commands.Command;
import java.util.Iterator;
import java.util.concurrent.CopyOnWriteArrayList;
import me.twerknation28.moonlight.features.api.Category;
import java.util.List;
import me.twerknation28.moonlight.features.settings.Setting;
import net.minecraft.class_742;
import me.twerknation28.moonlight.features.modules.Module;

public class VisualRange extends Module
{
    public Setting<Boolean> compact;
    private final List<class_742> players;
    
    public VisualRange() {
        super("VisualRange", "Notifies about players getting in or out of render", Category.COMBAT, true, false, false);
        this.compact = this.register(new Setting<Boolean>("Compact", false));
        this.players = new CopyOnWriteArrayList<class_742>();
    }
    
    @Override
    public void onEnable() {
        super.onEnable();
        this.players.clear();
        if (fullNullCheck()) {
            return;
        }
        for (final class_742 entity : VisualRange.mc.field_1687.method_18456()) {
            if (entity == VisualRange.mc.field_1724) {
                continue;
            }
            this.players.add(entity);
        }
    }
    
    @Override
    public void onUpdate() {
        final List<class_742> currentPlayers = VisualRange.mc.field_1687.method_18456();
        for (class_742 entity : currentPlayers) {
            if (!this.players.contains(entity)) {
                if (this.compact.getValue()) {
                    Command.visualRangeMessage(entity.method_5477().getString(), true);
                }
                else {
                    Command.sendMessage(entity.method_5477().getString() + " has entered your visual range");
                }
                this.players.add(entity);
            }
        }
        for (class_742 entity : this.players) {
            if (!currentPlayers.contains(entity)) {
                if (this.compact.getValue()) {
                    Command.visualRangeMessage(entity.method_5477().getString(), false);
                }
                else {
                    Command.sendMessage(entity.method_5477().getString() + " has left your visual range");
                }
                this.players.remove(entity);
            }
        }
    }
}
