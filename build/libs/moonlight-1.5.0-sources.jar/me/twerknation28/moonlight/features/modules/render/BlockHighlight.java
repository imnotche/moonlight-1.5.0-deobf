package me.twerknation28.moonlight.features.modules.render;

import com.google.common.eventbus.Subscribe;
import me.twerknation28.moonlight.util.RenderUtil;
import net.minecraft.class_1922;
import net.minecraft.class_238;
import net.minecraft.class_239;
import net.minecraft.class_265;
import net.minecraft.class_3965;
import java.awt.Color;
import me.twerknation28.moonlight.features.modules.client.NewGui;
import me.twerknation28.moonlight.event.impl.Render3DEvent;
import me.twerknation28.moonlight.features.api.Category;
import me.twerknation28.moonlight.features.settings.Setting;
import me.twerknation28.moonlight.features.modules.Module;

public class BlockHighlight extends Module
{
    public final Setting<Float> lineWidth;
    public final Setting<Integer> lineAlpha;
    public final Setting<Integer> boxAlpha;
    
    public BlockHighlight() {
        super("BlockHighlight", "Highlights the block you're looking at", Category.RENDER, true, false, false);
        this.lineWidth = this.register(new Setting<Float>("Line Width", 1.0f, 0.1f, 3.0f, 0.1f));
        this.lineAlpha = this.register(new Setting<Integer>("Line Alpha", 255, 0, 255, 1));
        this.boxAlpha = this.register(new Setting<Integer>("Box Alpha", 150, 0, 255, 1));
    }
    
    @Subscribe
    @Override
    public void onRender3D(final Render3DEvent event) {
        final Color boxColor = new Color(NewGui.getInstance().red.getValue(), NewGui.getInstance().green.getValue(), NewGui.getInstance().blue.getValue(), this.boxAlpha.getValue());
        final Color lineColor = new Color(NewGui.getInstance().red.getValue(), NewGui.getInstance().green.getValue(), NewGui.getInstance().blue.getValue(), this.lineAlpha.getValue());
        final class_239 crosshairTarget = BlockHighlight.mc.field_1765;
        if (crosshairTarget instanceof final class_3965 result) {
            final class_265 shape = BlockHighlight.mc.field_1687.method_8320(result.method_17777()).method_26218((class_1922)BlockHighlight.mc.field_1687, result.method_17777());
            if (shape.method_1110()) {
                return;
            }
            class_238 box = shape.method_1107();
            box = box.method_996(result.method_17777());
            RenderUtil.drawBoxFilled(event.getMatrix(), box, boxColor);
            RenderUtil.drawBox(event.getMatrix(), box, lineColor, this.lineWidth.getValue());
        }
    }
}
