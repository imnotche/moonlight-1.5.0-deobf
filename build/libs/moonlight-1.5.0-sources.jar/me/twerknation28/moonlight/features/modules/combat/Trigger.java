package me.twerknation28.moonlight.features.modules.combat;

import java.util.Random;
import me.twerknation28.moonlight.util.WorldUtil;
import net.minecraft.class_1268;
import net.minecraft.class_1297;
import net.minecraft.class_1299;
import net.minecraft.class_1657;
import net.minecraft.class_1829;
import java.util.ArrayList;
import me.twerknation28.moonlight.manager.RotationManager;
import me.twerknation28.moonlight.util.MathUtil;
import me.twerknation28.moonlight.features.api.Category;
import me.twerknation28.moonlight.features.settings.Setting;
import me.twerknation28.moonlight.features.modules.Module;

public class Trigger extends Module
{
    public final Setting<Boolean> players;
    public final Setting<Boolean> mobs;
    public final Setting<Boolean> animals;
    public final Setting<Boolean> vehicles;
    public final Setting<Boolean> onlySword;
    public final Setting<Boolean> ignoreWalls;
    public final Setting<Boolean> criticals;
    public final Setting<Boolean> nextTick;
    public final Setting<Boolean> newDelay;
    public final Setting<Float> minRange;
    public final Setting<Float> maxRange;
    int ticks;
    boolean doNextTick;
    int extraTicks;
    float randRange;
    
    public Trigger() {
        super("Trigger", "Highly advanced auto-ban", Category.COMBAT, true, false, false);
        this.players = this.register(new Setting<Boolean>("Players", true));
        this.mobs = this.register(new Setting<Boolean>("Mobs", true));
        this.animals = this.register(new Setting<Boolean>("Animals", false));
        this.vehicles = this.register(new Setting<Boolean>("Vehicles", false));
        this.onlySword = this.register(new Setting<Boolean>("OnlySword", true));
        this.ignoreWalls = this.register(new Setting<Boolean>("IgnoreWalls", true));
        this.criticals = this.register(new Setting<Boolean>("Criticals", false));
        this.nextTick = this.register(new Setting<Boolean>("TickSkip", true));
        this.newDelay = this.register(new Setting<Boolean>("1.20 Delay", true));
        this.minRange = this.register(new Setting<Float>("Min Range", 2.7f, 0.0f, 4.0f, 0.1f));
        this.maxRange = this.register(new Setting<Float>("Max Range", 3.0f, 0.0f, 4.0f, 0.1f));
        this.ticks = 0;
        this.doNextTick = false;
        this.extraTicks = 0;
    }
    
    @Override
    public void onEnable() {
        super.onEnable();
        this.extraTicks = MathUtil.getRandomInt(0, 2);
        this.randRange = (float)this.getRandomRange(this.minRange.getValue(), this.maxRange.getValue());
    }
    
    @Override
    public void onTick() {
        if (Trigger.mc.field_1692 != null && !Trigger.mc.field_1724.method_6115() && (Trigger.mc.field_1724.method_24520(item -> item.method_7909() instanceof class_1829) || !this.onlySword.getValue()) && Trigger.mc.field_1755 == null && (!this.newDelay.getValue() || Trigger.mc.field_1724.method_7261(0.0f) >= 1.0)) {
            if (this.nextTick.getValue() && !this.doNextTick) {
                if (this.ticks < this.extraTicks) {
                    ++this.ticks;
                }
                else {
                    this.doNextTick = true;
                    this.ticks = 0;
                }
            }
            else if (Trigger.mc.field_1724.method_24828() || Trigger.mc.field_1724.field_6017 >= 0.1 || !Trigger.mc.field_1690.field_1903.method_1434() || !this.criticals.getValue()) {
                final class_1297 target = RotationManager.getCrosshairTarget(Trigger.mc.field_1724.method_36454(), Trigger.mc.field_1724.method_36455(), this.randRange, this.ignoreWalls.getValue());
                final ArrayList<class_1299> toTarget = new ArrayList<class_1299>();
                if (this.players.getValue()) {
                    toTarget.add(class_1299.field_6097);
                }
                if (this.mobs.getValue()) {
                    toTarget.add(class_1299.field_6051);
                }
                if (this.animals.getValue()) {
                    toTarget.add(class_1299.field_6093);
                }
                if (this.vehicles.getValue()) {
                    toTarget.add(class_1299.field_6096);
                }
                if (WorldUtil.canTarget(target, toTarget)) {
                    Trigger.mc.field_1761.method_2918((class_1657)Trigger.mc.field_1724, target);
                    Trigger.mc.field_1724.method_6104(class_1268.field_5808);
                    this.doNextTick = false;
                    this.ticks = 0;
                    this.extraTicks = MathUtil.getRandomInt(0, 1);
                    this.randRange = (float)this.getRandomRange(this.minRange.getValue(), this.maxRange.getValue());
                }
            }
        }
    }
    
    public double getRandomRange(final float min, final float max) {
        final Random random = new Random();
        final float randomValue = min + random.nextFloat() * (max - min);
        return Math.round(randomValue * 10.0f) / 10.0f;
    }
}
