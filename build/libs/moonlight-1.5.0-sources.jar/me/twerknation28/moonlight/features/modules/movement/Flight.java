package me.twerknation28.moonlight.features.modules.movement;

import me.twerknation28.moonlight.manager.RotationManager;
import net.minecraft.class_2338;
import net.minecraft.class_2374;
import net.minecraft.class_243;
import net.minecraft.class_2596;
import net.minecraft.class_2828;
import net.minecraft.class_2848;
import com.google.common.eventbus.Subscribe;
import me.twerknation28.moonlight.event.impl.PacketEvent;
import me.twerknation28.moonlight.features.api.Category;
import me.twerknation28.moonlight.features.settings.Setting;
import me.twerknation28.moonlight.features.modules.Module;

public class Flight extends Module
{
    private final Setting<Double> baseSpeed;
    private final Setting<Double> maxSpeed;
    private final Setting<Boolean> veloSpeed;
    private final Setting<AntiKickMode> antiKick;
    private float speedDelta;
    
    public Flight() {
        super("Flight", "Zooooom", Category.PLAYER, true, false, true);
        this.baseSpeed = this.register(new Setting<Double>("Base Speed", Double.valueOf(Float.valueOf(1.0f)), Double.valueOf(Float.valueOf(0.0f)), Double.valueOf(Float.valueOf(1.0f)), Double.valueOf(Float.valueOf(0.1f))));
        this.maxSpeed = this.register(new Setting<Double>("Max Speed", Double.valueOf(Float.valueOf(5.0f)), Double.valueOf(Float.valueOf(0.0f)), Double.valueOf(Float.valueOf(10.0f)), Double.valueOf(Float.valueOf(0.1f))));
        this.veloSpeed = this.register(new Setting<Boolean>("Velocity Speed", true));
        this.antiKick = this.register(new Setting<AntiKickMode>("AntiKick", AntiKickMode.PACKET));
        this.speedDelta = 0.0f;
    }
    
    @Subscribe
    @Override
    public void onPacketSend(final PacketEvent.Send event) {
        if (event.getPacket() instanceof class_2848) {
            event.cancel();
        }
    }
    
    @Override
    public void onDisable() {
        if (Flight.mc.field_1724.method_31549().field_7477) {
            return;
        }
        Flight.mc.field_1724.method_31549().field_7478 = false;
    }
    
    @Override
    public void onTick() {
        if (this.isDisabled()) {
            return;
        }
        if (Flight.mc.field_1724.method_31549().field_7477) {
            return;
        }
        Flight.mc.field_1724.method_31549().field_7478 = true;
        if (this.veloSpeed.getValue() && this.isMoving()) {
            this.speedDelta += 0.1f;
        }
        if (!this.isMoving() && this.speedDelta > 0.0f) {
            this.speedDelta = 0.0f;
            Flight.mc.field_1724.method_18799(class_243.field_1353);
        }
        double speed;
        if (this.veloSpeed.getValue()) {
            speed = this.baseSpeed.getValue() * this.speedDelta;
            if (speed >= this.maxSpeed.getValue()) {
                speed = this.maxSpeed.getValue();
            }
        }
        else {
            speed = this.baseSpeed.getValue();
        }
        final class_243 antiKickVel = this.getAntiKickVec();
        Flight.mc.field_1724.method_18799(antiKickVel);
        final class_243 forward = new class_243(0.0, 0.0, speed).method_1024(-(float)Math.toRadians(Flight.mc.field_1724.method_36454()));
        final class_243 strafe = forward.method_1024((float)Math.toRadians(90.0));
        if (Flight.mc.field_1690.field_1903.method_1434()) {
            if (speed == 0.0) {
                Flight.mc.field_1724.method_18799(Flight.mc.field_1724.method_18798().method_1031(0.0, (double)this.baseSpeed.getValue(), 0.0));
            }
            else {
                Flight.mc.field_1724.method_18799(Flight.mc.field_1724.method_18798().method_1031(0.0, speed, 0.0));
            }
        }
        if (Flight.mc.field_1690.field_1832.method_1434()) {
            if (speed == 0.0) {
                Flight.mc.field_1724.method_18799(Flight.mc.field_1724.method_18798().method_1031(0.0, -this.baseSpeed.getValue(), 0.0));
            }
            else {
                Flight.mc.field_1724.method_18799(Flight.mc.field_1724.method_18798().method_1031(0.0, -speed, 0.0));
            }
        }
        if (Flight.mc.field_1690.field_1881.method_1434()) {
            Flight.mc.field_1724.method_18799(Flight.mc.field_1724.method_18798().method_1031(-forward.field_1352, 0.0, -forward.field_1350));
        }
        if (Flight.mc.field_1690.field_1894.method_1434()) {
            Flight.mc.field_1724.method_18799(Flight.mc.field_1724.method_18798().method_1031(forward.field_1352, 0.0, forward.field_1350));
        }
        if (Flight.mc.field_1690.field_1913.method_1434()) {
            Flight.mc.field_1724.method_18799(Flight.mc.field_1724.method_18798().method_1031(strafe.field_1352, 0.0, strafe.field_1350));
        }
        if (Flight.mc.field_1690.field_1849.method_1434()) {
            Flight.mc.field_1724.method_18799(Flight.mc.field_1724.method_18798().method_1031(-strafe.field_1352, 0.0, -strafe.field_1350));
        }
    }
    
    private class_243 getAntiKickVec() {
        return switch (this.antiKick.getValue().ordinal()) {
            default -> throw new IncompatibleClassChangeError();
            case 0 -> class_243.field_1353;
            case 1 -> {
                final class_243 position = Flight.mc.field_1724.method_19538().method_1031(0.0, -0.069, 0.0);
                final class_2338 blockPos = RotationManager.from((class_2374)position);
                yield (Flight.mc.field_1724.field_6012 % 7 == 0 && Flight.mc.field_1687.method_8320(blockPos).method_45474()) ? class_243.field_1353.method_1031(0.0, -0.069, 0.0) : class_243.field_1353;
            }
            case 2 -> {
                if (Flight.mc.field_1724.field_6012 % 40 == 0) {
                    final class_243 position = Flight.mc.field_1724.method_19538().method_1031(0.0, 0.15, 0.0);
                    if (Flight.mc.field_1687.method_8320(RotationManager.from((class_2374)position)).method_45474()) {
                        yield class_243.field_1353.method_1031(0.0, 0.15, 0.0);
                    }
                }
                else if (Flight.mc.field_1724.field_6012 % 20 == 0) {
                    final class_243 position = Flight.mc.field_1724.method_19538().method_1031(0.0, -0.15, 0.0);
                    if (Flight.mc.field_1687.method_8320(RotationManager.from((class_2374)position)).method_45474()) {
                        yield class_243.field_1353.method_1031(0.0, -0.15, 0.0);
                    }
                }
                yield class_243.field_1353;
            }
            case 3 -> {
                if (Flight.mc.field_1724.field_6012 % 20 == 0) {
                    Flight.mc.field_1724.field_3944.method_52787((class_2596)new class_2828.class_2829(Flight.mc.field_1724.method_23317(), Flight.mc.field_1724.method_23318() - 0.069, Flight.mc.field_1724.method_23321(), false));
                    Flight.mc.field_1724.field_3944.method_52787((class_2596)new class_2828.class_2829(Flight.mc.field_1724.method_23317(), Flight.mc.field_1724.method_23318() + 0.069, Flight.mc.field_1724.method_23321(), true));
                }
                yield class_243.field_1353;
            }
        };
    }
    
    private boolean isMoving() {
        return Flight.mc.field_1690.field_1832.method_1434() || Flight.mc.field_1690.field_1881.method_1434() || Flight.mc.field_1690.field_1894.method_1434() || Flight.mc.field_1690.field_1913.method_1434() || Flight.mc.field_1690.field_1849.method_1434();
    }
    
    public enum AntiKickMode
    {
        NONE, 
        FALL, 
        BOB, 
        PACKET;
    }
}
