package me.twerknation28.moonlight.features.modules.combat;

import me.twerknation28.moonlight.event.EventListener;
import me.twerknation28.moonlight.manager.InventoryManager;
import net.minecraft.class_1657;
import net.minecraft.class_1713;
import net.minecraft.class_1792;
import net.minecraft.class_1799;
import net.minecraft.class_1802;
import me.twerknation28.moonlight.features.api.Category;
import me.twerknation28.moonlight.features.settings.Setting;
import java.util.List;
import me.twerknation28.moonlight.features.modules.Module;

public class SuperTotem extends Module
{
    private static final int INVENTORY_SYNC_ID = 0;
    private static final List<class_1792> HOTBAR_ITEMS;
    public Setting<Boolean> fastEquip;
    public Setting<Boolean> inInventory;
    private int lastSlot;
    
    public SuperTotem() {
        super("AutoTotem", "Totally Tubular Totemic Technologies", Category.COMBAT, true, false, false);
        this.fastEquip = this.register(new Setting<Boolean>("FastEquip", true));
        this.inInventory = this.register(new Setting<Boolean>("InInventory", true));
    }
    
    @Override
    public void onEnable() {
        this.lastSlot = -1;
    }
    
    @EventListener
    @Override
    public void onUpdate() {
        if (SuperTotem.mc.field_1755 == null || this.inInventory.getValue()) {
            final class_1792 itemToWield = class_1802.field_8288;
            if (!InventoryManager.isHolding(itemToWield)) {
                final int itemSlot = this.getSlotFor(itemToWield);
                if (itemSlot != -1) {
                    if (itemSlot < 9) {
                        this.lastSlot = itemSlot;
                    }
                    if (this.fastEquip.getValue()) {
                        SuperTotem.mc.field_1761.method_2906(0, (itemSlot < 9) ? (itemSlot + 36) : itemSlot, 40, class_1713.field_7791, (class_1657)SuperTotem.mc.field_1724);
                    }
                    else {
                        SuperTotem.mc.field_1761.method_2906(0, (itemSlot < 9) ? (itemSlot + 36) : itemSlot, 0, class_1713.field_7790, (class_1657)SuperTotem.mc.field_1724);
                        SuperTotem.mc.field_1761.method_2906(0, 45, 0, class_1713.field_7790, (class_1657)SuperTotem.mc.field_1724);
                        if (!SuperTotem.mc.field_1724.field_7512.method_34255().method_7960()) {
                            SuperTotem.mc.field_1761.method_2906(0, (itemSlot < 9) ? (itemSlot + 36) : itemSlot, 0, class_1713.field_7790, (class_1657)SuperTotem.mc.field_1724);
                        }
                    }
                }
            }
        }
    }
    
    private int getSlotFor(final class_1792 item) {
        if (this.lastSlot != -1 && item.equals(SuperTotem.mc.field_1724.method_31548().method_5438(this.lastSlot).method_7909())) {
            final int slot = this.lastSlot;
            this.lastSlot = -1;
            return slot;
        }
        for (int startSlot = SuperTotem.HOTBAR_ITEMS.contains(item) ? 0 : 9, slot2 = 35; slot2 >= startSlot; --slot2) {
            final class_1799 itemStack = SuperTotem.mc.field_1724.method_31548().method_5438(slot2);
            if (!itemStack.method_7960() && itemStack.method_7909().equals(item)) {
                return slot2;
            }
        }
        return -1;
    }
    
    static {
        HOTBAR_ITEMS = List.of(class_1802.field_8288);
    }
}
