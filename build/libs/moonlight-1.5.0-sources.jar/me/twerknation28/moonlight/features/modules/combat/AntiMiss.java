package me.twerknation28.moonlight.features.modules.combat;

import me.twerknation28.moonlight.event.impl.HandleBlockBreakingEvent;
import com.google.common.eventbus.Subscribe;
import me.twerknation28.moonlight.event.impl.AttackEvent;
import me.twerknation28.moonlight.features.api.Category;
import me.twerknation28.moonlight.features.settings.Setting;
import net.minecraft.class_1829;
import net.minecraft.class_3966;
import me.twerknation28.moonlight.features.modules.Module;

public class AntiMiss extends Module
{
    public Setting<Boolean> onlySword;
    
    public AntiMiss() {
        super("AntiMiss", "Prevents you from swinging if you aren't in range of an enemy", Category.COMBAT, true, false, false);
        this.onlySword = this.register(new Setting<Boolean>("OnlySword", false));
    }
    
    @Subscribe
    public void onAttack(final AttackEvent e) {
        if (!(AntiMiss.mc.field_1765 instanceof class_3966) && e.isPre() && (!this.onlySword.getValue() || (this.onlySword.getValue() && (AntiMiss.mc.field_1724.method_6047().method_7909() instanceof class_1829 || AntiMiss.mc.field_1724.method_6079().method_7909() instanceof class_1829)))) {
            e.cancel();
        }
    }
    
    @Subscribe
    public void onBlockBreaking(final HandleBlockBreakingEvent e) {
        if (!(AntiMiss.mc.field_1765 instanceof class_3966) && (!this.onlySword.getValue() || (this.onlySword.getValue() && (AntiMiss.mc.field_1724.method_6047().method_7909() instanceof class_1829 || AntiMiss.mc.field_1724.method_6079().method_7909() instanceof class_1829)))) {
            e.cancel();
        }
    }
}
