package me.twerknation28.moonlight.features.modules.player;

import me.twerknation28.moonlight.features.commands.Command;
import me.twerknation28.moonlight.manager.InventoryManager;
import net.minecraft.class_1268;
import net.minecraft.class_1657;
import net.minecraft.class_1770;
import net.minecraft.class_1792;
import net.minecraft.class_1799;
import net.minecraft.class_1802;
import me.twerknation28.moonlight.features.api.Category;
import me.twerknation28.moonlight.features.modules.Module;

public class ElytraSwap extends Module
{
    private boolean inHotbar;
    
    public ElytraSwap() {
        super("ElytraSwap", "Swaps Chestplate and Elytra", Category.PLAYER, true, false, true);
    }
    
    @Override
    public void onEnable() {
        class_1792 chestPiece;
        if (!(ElytraSwap.mc.field_1724.method_31548().method_7372(2).method_7909() instanceof class_1770)) {
            chestPiece = class_1802.field_8833;
        }
        else {
            chestPiece = class_1802.field_22028;
        }
        int elytraSlot = -1;
        for (int i = 0; i <= 44; ++i) {
            assert ElytraSwap.mc.field_1724 != null;
            final class_1792 item = ElytraSwap.mc.field_1724.method_31548().method_5438(i).method_7909();
            if (item == chestPiece || (chestPiece == class_1802.field_22028 && item == class_1802.field_8058)) {
                if (i < 9) {
                    this.inHotbar = true;
                }
                else {
                    this.inHotbar = false;
                }
                elytraSlot = i;
            }
        }
        if (this.inHotbar) {
            InventoryManager.setSlot(elytraSlot);
            ElytraSwap.mc.field_1761.method_2919((class_1657)ElytraSwap.mc.field_1724, class_1268.field_5808);
            InventoryManager.syncToClient();
            Command.sendMessage("Swapped chestpiece");
        }
        else {
            final class_1799 elytraStack = ElytraSwap.mc.field_1724.method_31548().method_7372(2);
            InventoryManager.pickupSlot(elytraSlot);
            final boolean rt = !elytraStack.method_7960();
            InventoryManager.pickupSlot(6);
            if (rt) {
                InventoryManager.pickupSlot(elytraSlot);
            }
            Command.sendMessage("Swapped chestpiece");
        }
        this.toggle();
    }
}
