package me.twerknation28.moonlight.features.modules.client;

import java.awt.Color;
import java.io.BufferedReader;
import java.io.InputStreamReader;
import java.util.Comparator;
import java.util.List;
import java.util.stream.Collectors;
import me.twerknation28.moonlight.Moonlight;
import me.twerknation28.moonlight.event.impl.Render2DEvent;
import me.twerknation28.moonlight.features.api.Category;
import me.twerknation28.moonlight.features.modules.Module;
import me.twerknation28.moonlight.features.modules.client.NewGui;
import me.twerknation28.moonlight.features.modules.misc.NameProtect;
import me.twerknation28.moonlight.features.settings.Setting;
import me.twerknation28.moonlight.manager.ServerManager;
import me.twerknation28.moonlight.util.ColorUtil;
import me.twerknation28.moonlight.util.MathUtil;
import net.minecraft.class_1291;
import net.minecraft.class_1293;
import net.minecraft.class_1297;
import net.minecraft.class_1802;
import net.minecraft.class_746;

public class HudModule extends Module
{
    public Setting<colorMode> colorModeSetting;
    public Setting<String> firstGradientColor;
    public Setting<String> secondGradientColor;
    public Setting<Boolean> watermark;
    public Setting<Boolean> gaymark;
    public Setting<Boolean> indicators;
    public Setting<Boolean> textRadar;
    public Setting<Integer> yOffset;
    public Setting<Boolean> welcomer;
    public Setting<welcomerMode> mode;
    public Setting<Boolean> coords;
    public Setting<Boolean> info;
    public Setting<Boolean> arrayList;
    public Setting<Boolean> ping;
    public Setting<Boolean> fps;
    public Setting<Boolean> potions;
    float gradientCount;
    boolean gradientDirection;
    int audioTimer;
    int REFRESH_INTERVAL;
    String songString;

    public HudModule() {
        super("HUD", "swag", Category.CLIENT, true, false, false);
        this.colorModeSetting = this.register(new Setting<colorMode>("Color", colorMode.GLOBAL));
        this.firstGradientColor = this.register(new Setting<String>("FirstGradientColor", "#FF0000", v -> this.colorModeSetting.getValue() == colorMode.CYCLE));
        this.secondGradientColor = this.register(new Setting<String>("SecondGradientColor", "#0000FF", v -> this.colorModeSetting.getValue() == colorMode.CYCLE));
        this.watermark = this.register(new Setting<Boolean>("Watermark", true));
        this.gaymark = this.register(new Setting<Boolean>("GayMark", false));
        this.indicators = this.register(new Setting<Boolean>("Indicators", false, v -> this.gaymark.getValue()));
        this.textRadar = this.register(new Setting<Boolean>("TextRadar", true));
        this.yOffset = this.register(new Setting<Integer>("Offset", 0, 0, 45, 1));
        this.welcomer = this.register(new Setting<Boolean>("Welcomer", false));
        this.mode = this.register(new Setting<welcomerMode>("Mode", welcomerMode.TIME, v -> this.welcomer.getValue()));
        this.coords = this.register(new Setting<Boolean>("Coords", true));
        this.info = this.register(new Setting<Boolean>("Info", true));
        this.arrayList = this.register(new Setting<Boolean>("ArrayList", true));
        this.ping = this.register(new Setting<Boolean>("Ping", true, v -> this.info.getValue()));
        this.fps = this.register(new Setting<Boolean>("FPS", true, v -> this.info.getValue()));
        this.potions = this.register(new Setting<Boolean>("Potions", true, v -> this.info.getValue()));
        this.gradientCount = 0.0f;
        this.gradientDirection = true;
        this.audioTimer = 20;
        this.REFRESH_INTERVAL = 20;
        this.songString = "";
    }

    @Override
    public void onTick() {
        if (this.welcomer.getValue().booleanValue() && this.mode.getValue() == welcomerMode.LINUXAUDIO) {
            ++this.audioTimer;
            if (this.audioTimer >= this.REFRESH_INTERVAL) {
                this.songString = this.getCurrentSong();
                this.audioTimer = 0;
            }
        }
    }

    @Override
    public void onRender2D(Render2DEvent event) {
        int globalColor;
        if (this.colorModeSetting.getValue() == colorMode.GLOBAL) {
            globalColor = ColorUtil.toARGB(NewGui.getInstance().red.getValue(), NewGui.getInstance().green.getValue(), NewGui.getInstance().blue.getValue(), 255);
        } else {
            Color color1 = Color.decode(this.firstGradientColor.getValue());
            Color color2 = Color.decode(this.secondGradientColor.getValue());
            globalColor = ColorUtil.lerpRGB(color1, color2, this.gradientCount);
            if (this.gradientDirection) {
                this.gradientCount += 0.01f;
                this.gradientCount = MathUtil.clamp(this.gradientCount, 0.0f, 1.0f);
                if (this.gradientCount == 1.0f) {
                    this.gradientDirection = false;
                }
            } else {
                this.gradientCount -= 0.01f;
                this.gradientCount = MathUtil.clamp(this.gradientCount, 0.0f, 1.0f);
                if (this.gradientCount == 0.0f) {
                    this.gradientDirection = true;
                }
            }
        }
        if (this.watermark.getValue().booleanValue()) {
            event.getContext().method_25303(HudModule.mc.field_1772, "moonlight", 2, 2 + this.yOffset.getValue(), globalColor);
            int firstWordWidth = HudModule.mc.field_1772.method_1727("moonlight");
            event.getContext().method_25303(HudModule.mc.field_1772, " 1.5.0-beta", 2 + firstWordWidth, 2 + this.yOffset.getValue(), 0xFFFFFF);
        }
        if (this.gaymark.getValue().booleanValue()) {
            event.getContext().method_25303(HudModule.mc.field_1772, "gayretard.club", 2, 150, globalColor);
            if (this.indicators.getValue().booleanValue()) {
                boolean isInRange = false;
                boolean isInPlaceRange = false;
                boolean bl = false;
                event.getContext().method_25303(HudModule.mc.field_1772, "HTR", 2, 160, 14224393);
                event.getContext().method_25303(HudModule.mc.field_1772, "PLR", 2, 169, 14224393);
                int totems = 0;
                for (int i = 0; i <= 45; ++i) {
                    if (HudModule.mc.field_1724.method_31548().method_5438(i).method_7909() != class_1802.field_8288) continue;
                    ++totems;
                }
                event.getContext().method_25303(HudModule.mc.field_1772, Integer.toString(totems), 2, 178, totems != 0 ? 8453123 : 14224393);
                int ping = ServerManager.getPing();
                event.getContext().method_25303(HudModule.mc.field_1772, "PING " + ping, 2, 187, ping <= 100 ? 8453123 : 14224393);
                event.getContext().method_25303(HudModule.mc.field_1772, "LBY", 2, 196, 14224393);
            }
        }
        if (this.coords.getValue().booleanValue()) {
            event.getContext().method_25303(HudModule.mc.field_1772, "XYZ:", 2, mc.method_22683().method_4502() - 9, globalColor);
            int xyzLength = HudModule.mc.field_1772.method_1727("XYZ:");
            event.getContext().method_25303(HudModule.mc.field_1772, " " + HudModule.mc.field_1724.method_31477() + ", " + HudModule.mc.field_1724.method_31478() + ", " + HudModule.mc.field_1724.method_31479(), 2 + xyzLength, mc.method_22683().method_4502() - 9, 0xFFFFFF);
        }
        if (this.welcomer.getValue().booleanValue()) {
            switch (this.mode.getValue().ordinal()) {
                case 1: {
                    event.getContext().method_25303(HudModule.mc.field_1772, this.songString, (int)((float)mc.method_22683().method_4486() / 2.0f - (float)HudModule.mc.field_1772.method_1727(this.songString) / 2.0f + 2.0f), 2, globalColor);
                    break;
                }
                case 3: {
                    int welcomerLength = HudModule.mc.field_1772.method_1727("welcome, " + this.getSpoofedName() + " :^)");
                    int welcomeX = (int)((float)mc.method_22683().method_4486() / 2.0f - (float)welcomerLength / 2.0f + 2.0f);
                    int n = welcomeX + HudModule.mc.field_1772.method_1727("welcome, ");
                    int faceX = welcomeX + HudModule.mc.field_1772.method_1727("welcome, " + this.getSpoofedName());
                    event.getContext().method_25303(HudModule.mc.field_1772, "welcome, ", (int)((float)mc.method_22683().method_4486() / 2.0f - (float)welcomerLength / 2.0f + 2.0f), 2, globalColor);
                    event.getContext().method_25303(HudModule.mc.field_1772, this.getSpoofedName(), n, 2, 0xFFFFFF);
                    event.getContext().method_25303(HudModule.mc.field_1772, " :^)", faceX, 2, globalColor);
                    break;
                }
                case 0: {
                    int welcomerLength = HudModule.mc.field_1772.method_1727(MathUtil.getTimeOfDay() + ", " + this.getSpoofedName());
                    int welcomeX = (int)((float)mc.method_22683().method_4486() / 2.0f - (float)welcomerLength / 2.0f + 2.0f);
                    int n = welcomeX + HudModule.mc.field_1772.method_1727(MathUtil.getTimeOfDay() + ", ");
                    event.getContext().method_25303(HudModule.mc.field_1772, MathUtil.getTimeOfDay() + ", ", (int)((float)mc.method_22683().method_4486() / 2.0f - (float)welcomerLength / 2.0f + 2.0f), 2, globalColor);
                    event.getContext().method_25303(HudModule.mc.field_1772, this.getSpoofedName(), n, 2, 0xFFFFFF);
                    break;
                }
                case 2: {
                    int welcomerLength = HudModule.mc.field_1772.method_1727("welcome to moonlight, " + this.getSpoofedName());
                    int welcomeX = (int)((float)mc.method_22683().method_4486() / 2.0f - (float)welcomerLength / 2.0f + 2.0f);
                    int n = welcomeX + HudModule.mc.field_1772.method_1727("welcome to moonlight, ");
                    event.getContext().method_25303(HudModule.mc.field_1772, "welcome to moonlight, ", (int)((float)mc.method_22683().method_4486() / 2.0f - (float)welcomerLength / 2.0f + 2.0f), 2, globalColor);
                    event.getContext().method_25303(HudModule.mc.field_1772, this.getSpoofedName(), n, 2, 0xFFFFFF);
                    break;
                }
                case 4: {
                    String welcomerText = "Welcome " + this.getSpoofedName() + " :^)";
                    int welcomerLength = HudModule.mc.field_1772.method_1727("Welcome " + this.getSpoofedName() + " :^)");
                    int n = (int)((float)mc.method_22683().method_4486() / 2.0f - (float)welcomerLength / 2.0f + 2.0f);
                    event.getContext().method_25303(HudModule.mc.field_1772, welcomerText, n, 2, globalColor);
                    break;
                }
            }
        }
        if (this.arrayList.getValue().booleanValue()) {
            int moduleOffset = 0;
            for (int k = 0; k < Moonlight.moduleManager.sortedModules.size(); ++k) {
                if (!Moonlight.moduleManager.sortedModules.get((int)k).drawn.getValue().booleanValue()) continue;
                String string = Moonlight.moduleManager.sortedModules.get(k).getName();
                int modLength = HudModule.mc.field_1772.method_1727(string);
                int modX = mc.method_22683().method_4486() - modLength - 2;
                int modY = 2 + moduleOffset;
                event.getContext().method_25303(HudModule.mc.field_1772, string, modX, modY, globalColor);
                moduleOffset += 9;
            }
        }
        if (this.textRadar.getValue().booleanValue()) {
            int count = 1;
            for (class_1297 entity : HudModule.mc.field_1687.method_18456().stream().filter(e -> e != HudModule.mc.field_1724).sorted(Comparator.comparing(arg_0 -> ((class_746)HudModule.mc.field_1724).method_5739(arg_0))).toList()) {
                int dist = Math.round(HudModule.mc.field_1724.method_5739(entity));
                event.getContext().method_25303(HudModule.mc.field_1772, entity.method_5476().getString(), 2, 11 + count * 9 + this.yOffset.getValue(), globalColor);
                event.getContext().method_25303(HudModule.mc.field_1772, " " + dist + "m", 2 + HudModule.mc.field_1772.method_1727(entity.method_5476().getString()), 11 + count * 9 + this.yOffset.getValue(), 0xFFFFFF);
                ++count;
            }
        }
        if (this.info.getValue().booleanValue()) {
            int yOffset = 0;
            if (this.potions.getValue().booleanValue()) {
                for (class_1293 statusEffectInstance : HudModule.mc.field_1724.method_6026()) {
                    class_1291 potion = (class_1291)statusEffectInstance.method_5579().comp_349();
                    int potionLength = HudModule.mc.field_1772.method_1727(potion.method_5560().getString() + " " + HudModule.getDuration(statusEffectInstance));
                    int potionX = mc.method_22683().method_4486() - potionLength - 3;
                    int potionY = mc.method_22683().method_4502() - (yOffset += 9);
                    int potionIntX = potionX + HudModule.mc.field_1772.method_1727(potion.method_5560().getString() + ":");
                    event.getContext().method_25303(HudModule.mc.field_1772, potion.method_5560().getString(), potionX, potionY, potion.method_5556());
                    event.getContext().method_25303(HudModule.mc.field_1772, " " + HudModule.getDuration(statusEffectInstance), potionIntX, potionY, 0xFFFFFF);
                }
            }
            if (this.fps.getValue().booleanValue()) {
                int fpsLength = HudModule.mc.field_1772.method_1727("FPS: " + HudModule.mc.field_1770.split(" ", 2)[0]);
                int n = mc.method_22683().method_4486() - fpsLength - 2;
                int intX = n + HudModule.mc.field_1772.method_1727("FPS:");
                event.getContext().method_25303(HudModule.mc.field_1772, "FPS:", n, mc.method_22683().method_4502() - (yOffset += 9), globalColor);
                event.getContext().method_25303(HudModule.mc.field_1772, " " + HudModule.mc.field_1770.split(" ", 2)[0], intX, mc.method_22683().method_4502() - yOffset, 0xFFFFFF);
            }
            if (this.ping.getValue().booleanValue()) {
                int pingLength = HudModule.mc.field_1772.method_1727("Ping: " + ServerManager.getPing());
                int n = mc.method_22683().method_4486() - pingLength - 2;
                int pingY = mc.method_22683().method_4502() - (yOffset += 9);
                int pingIntX = n + HudModule.mc.field_1772.method_1727("Ping:");
                event.getContext().method_25303(HudModule.mc.field_1772, "Ping:", n, pingY, globalColor);
                event.getContext().method_25303(HudModule.mc.field_1772, " " + ServerManager.getPing(), pingIntX, pingY, 0xFFFFFF);
            }
        }
    }

    public static String getDuration(class_1293 pe) {
        if (pe.method_48559()) {
            return "*:*";
        }
        int var1 = pe.method_5584();
        int mins = var1 / 1200;
        String sec = String.format("%02d", var1 % 1200 / 20);
        return mins + ":" + sec;
    }

    public String getCurrentSong() {
        try {
            String line;
            ProcessBuilder builder = new ProcessBuilder("playerctl", "metadata", "--format", "{{ artist }} - {{ title }}");
            builder.redirectErrorStream(true);
            Process process = builder.start();
            BufferedReader reader = new BufferedReader(new InputStreamReader(process.getInputStream()));
            StringBuilder song = new StringBuilder();
            while ((line = reader.readLine()) != null) {
                song.append(line);
            }
            process.waitFor();
            return song.toString();
        }
        catch (Exception e) {
            e.printStackTrace();
            return "";
        }
    }

    public String getSpoofedName() {
        NameProtect nameHiderModule = Moonlight.moduleManager.getModuleByClass(NameProtect.class);
        return nameHiderModule.isEnabled() ? nameHiderModule.newName.getValue() : HudModule.mc.field_1724.method_5477().getString();
    }

    public int[] getPlayerSize() {
        List nameLengths = HudModule.mc.field_1687.method_18456().stream().filter(e -> e != HudModule.mc.field_1724).map(e -> HudModule.mc.field_1772.method_1727(e.method_5476().getString() + " | " + e.method_24515().method_10263() + " " + e.method_24515().method_10264() + " " + e.method_24515().method_10260() + " (" + Math.round(HudModule.mc.field_1724.method_5739((class_1297)e)) + "m)")).collect(Collectors.toList());
        nameLengths.add(HudModule.mc.field_1772.method_1727("Players:"));
        nameLengths.sort(Comparator.reverseOrder());
        return new int[]{(Integer)nameLengths.get(0) + 2, nameLengths.size() * 10 + 1};
    }

    public static enum colorMode {
        GLOBAL,
        CYCLE;

    }

    public static enum welcomerMode {
        TIME,
        LINUXAUDIO,
        MOONLIGHT,
        CLASSIC,
        BITCH;

    }
}
