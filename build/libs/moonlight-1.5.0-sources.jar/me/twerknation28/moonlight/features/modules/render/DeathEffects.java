package me.twerknation28.moonlight.features.modules.render;

import java.util.Iterator;
import me.twerknation28.moonlight.features.api.Category;
import me.twerknation28.moonlight.features.settings.Setting;
import net.minecraft.class_1297;
import net.minecraft.class_1299;
import net.minecraft.class_1538;
import net.minecraft.class_1657;
import net.minecraft.class_1937;
import net.minecraft.class_3417;
import me.twerknation28.moonlight.features.modules.Module;

public class DeathEffects extends Module
{
    public final Setting<Boolean> sound;
    
    public DeathEffects() {
        super("DeathEffects", "Effects when you death.", Category.RENDER, true, false, false);
        this.sound = this.register(new Setting<Boolean>("Sound", true));
    }
    
    @Override
    public void onTick() {
        for (final class_1657 player : DeathEffects.mc.field_1687.method_18456()) {
            if (player.method_29504() || player.method_6032() == 0.0f) {
                int i = 0;
                if (i == 0) {
                    final class_1538 bolt = new class_1538(class_1299.field_6112, (class_1937)DeathEffects.mc.field_1687);
                    bolt.method_5641(player.method_23317(), player.method_23318(), player.method_23321(), player.method_36454(), player.method_36455());
                    DeathEffects.mc.field_1687.method_53875((class_1297)bolt);
                    player.method_5650(class_1297.class_5529.field_26998);
                    ++i;
                }
                if (!this.sound.getValue()) {
                    continue;
                }
                DeathEffects.mc.field_1724.method_5783(class_3417.field_14865, 0.5f, 1.0f);
            }
        }
    }
}
