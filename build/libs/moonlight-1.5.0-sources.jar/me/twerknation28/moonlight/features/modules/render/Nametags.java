package me.twerknation28.moonlight.features.modules.render;

import java.util.Iterator;
import com.google.common.eventbus.Subscribe;
import me.twerknation28.moonlight.event.impl.RenderLabelEvent;
import me.twerknation28.moonlight.event.impl.Render2DEvent;
import me.twerknation28.moonlight.features.api.Category;
import me.twerknation28.moonlight.features.modules.Module;
import net.minecraft.class_1297;
import net.minecraft.class_1657;
import net.minecraft.class_243;
import net.minecraft.class_4184;

public class Nametags extends Module
{
    public Nametags() {
        super("Nametags", "Shows additional information above the players", Category.RENDER, true, false, false);
    }
    
    private void render(final Render2DEvent event, final class_1657 entity) {
        final float distance = entity.method_5739((class_1297)Nametags.mc.field_1724);
        final class_4184 camera = Nametags.mc.field_1773.method_19418();
        final class_243 cameraPos = camera.method_19326();
        final class_243 entityPos = entity.method_19538();
        final float size = 0.025f;
    }
    
    @Subscribe
    public void onRenderLabel(final RenderLabelEvent event) {
        if (this.isDisabled()) {
            return;
        }
        event.cancel();
    }
    
    @Override
    public void onRender2D(final Render2DEvent event) {
        for (final class_1657 player : Nametags.mc.field_1687.method_18456()) {
            if (player == Nametags.mc.field_1724) {
                continue;
            }
            this.render(event, player);
        }
    }
}
