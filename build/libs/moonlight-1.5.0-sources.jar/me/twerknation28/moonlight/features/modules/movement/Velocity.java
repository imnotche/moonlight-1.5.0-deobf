package me.twerknation28.moonlight.features.modules.movement;

import me.twerknation28.moonlight.util.MathUtil;
import net.minecraft.class_1657;
import net.minecraft.class_2664;
import net.minecraft.class_2743;
import net.minecraft.class_465;
import me.twerknation28.moonlight.features.Feature;
import com.google.common.eventbus.Subscribe;
import me.twerknation28.moonlight.event.impl.PacketEvent;
import me.twerknation28.moonlight.features.api.Category;
import me.twerknation28.moonlight.features.settings.Setting;
import me.twerknation28.moonlight.features.modules.Module;

public class Velocity extends Module
{
    public Setting<veloMode> velocityMode;
    public Setting<Float> jumpChance;
    public Setting<Boolean> blocks;
    public static Velocity INSTANCE;
    
    public Velocity() {
        super("Velocity", "Reduces knockback", Category.PLAYER, true, false, false);
        this.velocityMode = this.register(new Setting<veloMode>("Mode", veloMode.anarchy));
        this.jumpChance = this.register(new Setting<Float>("Chance", 100.0f, 1.0f, 100.0f, 1.0f, v -> this.velocityMode.getValue() == veloMode.jump));
        this.blocks = this.register(new Setting<Boolean>("Blocks", true, v -> this.velocityMode.getValue() == veloMode.anarchy));
        Velocity.INSTANCE = this;
    }
    
    @Subscribe
    @Override
    public void onPacketReceive(final PacketEvent.Receive event) {
        if ((event.getPacket() instanceof class_2743 || event.getPacket() instanceof class_2664) && this.velocityMode.getValue() == veloMode.anarchy) {
            event.cancel();
        }
    }
    
    @Override
    public void onTick() {
        if (!Feature.fullNullCheck() && this.velocityMode.getValue() == veloMode.jump && !Velocity.mc.field_1724.method_6039() && !Velocity.mc.field_1724.method_6115() && !(Velocity.mc.field_1755 instanceof class_465) && Velocity.mc.field_1724.method_24828() && Velocity.mc.field_1724.field_6254 != 0 && Velocity.mc.field_1724.field_6235 != 0 && Velocity.mc.field_1724.method_6065() instanceof class_1657 && !Velocity.mc.field_1724.method_5816() && !Velocity.mc.field_1724.method_5757() && !Velocity.mc.field_1724.method_5799()) {
            final float chance = this.jumpChance.getValue();
            final int randomNumber = MathUtil.getRandomInt(100, 1);
            if (Velocity.mc.field_1724.field_6235 == Velocity.mc.field_1724.field_6254 - 1 && randomNumber <= chance) {
                Velocity.mc.field_1724.method_6043();
            }
        }
    }
    
    public String getMetadata() {
        return String.valueOf(this.jumpChance.getValue());
    }
    
    public enum veloMode
    {
        anarchy, 
        jump;
    }
}
