package me.twerknation28.moonlight.features.clickgui.buttons;

import me.twerknation28.moonlight.util.FontUtil;
import me.twerknation28.moonlight.util.ColorUtil;
import me.twerknation28.moonlight.features.modules.client.NewGui;
import me.twerknation28.moonlight.util.RenderUtil;
import me.twerknation28.moonlight.features.settings.Bind;
import me.twerknation28.moonlight.util.Util;
import net.minecraft.class_1109;
import net.minecraft.class_1113;
import net.minecraft.class_332;
import net.minecraft.class_3417;
import net.minecraft.class_6880;
import me.twerknation28.moonlight.features.clickgui.Window;
import me.twerknation28.moonlight.features.clickgui.BaseButton;

public class SubBind extends BaseButton
{
    private final Button parent;
    private final Window window;
    private boolean accepting;
    
    public SubBind(final Button parent) {
        super(parent.getWindow().getX() + 4, parent.getY() + 4, parent.getWindow().getWidth() - 7, 14);
        this.accepting = false;
        parent.getSubEntries().add(this);
        this.parent = parent;
        this.window = parent.getWindow();
    }
    
    @Override
    public void processMouseClick(final int mouseX, final int mouseY, final int button) {
        this.updateIsMouseHovered(mouseX, mouseY);
        if (!this.isMouseHovered()) {
            return;
        }
        if (button == 0) {
            this.accepting = true;
            Util.mc.method_1483().method_4873((class_1113)class_1109.method_47978((class_6880)class_3417.field_15015, 1.0f));
        }
    }
    
    @Override
    public void processKeyPress(final char character, final int key) {
        if (!this.accepting) {
            return;
        }
        Bind bind = new Bind(character);
        if (character == '\u0105' || character == '\u0103' || character == '\u0100') {
            bind = new Bind(-1);
        }
        this.parent.getModule().bind.setValue(bind);
        this.accepting = false;
    }
    
    @Override
    public void draw(final class_332 context, final int mouseX, final int mouseY) {
        String str = this.parent.getModule().getBind().toString().toUpperCase();
        str = str.replace("KEY.KEYBOARD", "").replace(".", " ");
        final String keyName = this.accepting ? "Press a key..." : ("bind: " + str);
        this.y = this.window.getRenderYButton();
        this.x = this.window.getX() + 4;
        this.updateIsMouseHovered(mouseX, mouseY);
        RenderUtil.rect(context.method_51448(), (float)this.getX(), (float)this.getY(), (float)(this.getWidth() + this.getX()), (float)(this.getHeight() + this.getY()), this.getColor());
        RenderUtil.rect(context.method_51448(), (float)this.getX(), (float)this.getY(), (float)(-1 + this.getX()), (float)(this.getHeight() + this.getY()), ColorUtil.toARGB(NewGui.getInstance().red.getValue(), NewGui.getInstance().green.getValue(), NewGui.getInstance().blue.getValue(), 255));
        FontUtil.drawStringWithShadow(keyName.toLowerCase(), this.getX() + 2, this.getY() + 3, -1, context);
    }
    
    @Override
    public int getColor() {
        if (!this.isMouseHovered()) {
            return ColorUtil.toARGB(0, 0, 0, 50);
        }
        return ColorUtil.toARGB(150, 150, 150, 50);
    }
    
    @Override
    public boolean shouldRender() {
        return this.parent.isOpen() && this.parent.shouldRender();
    }
    
    public Button getParent() {
        return this.parent;
    }
}
