package me.twerknation28.moonlight.features.clickgui;

import me.twerknation28.moonlight.util.RenderUtil;
import me.twerknation28.moonlight.util.ColorUtil;
import java.util.Iterator;
import me.twerknation28.moonlight.features.api.Category;
import me.twerknation28.moonlight.util.Util;
import net.minecraft.class_2561;
import net.minecraft.class_332;
import net.minecraft.class_437;
import java.util.LinkedHashSet;
import java.util.Set;

public class ClickGUI extends class_437
{
    private static ClickGUI INSTANCE;
    private final Set<Window> windows;
    private final int margin = 22;
    
    public ClickGUI() {
        super((class_2561)class_2561.method_43470("ClickGUI"));
        this.windows = new LinkedHashSet<Window>();
        ClickGUI.INSTANCE = this;
        this.windows.add(new Window(Util.mc.method_22683().method_4486() / 2 + 11 + 100 + 22, 22, "client", Category.CLIENT));
        this.windows.add(new Window(Util.mc.method_22683().method_4486() / 2 - 11 - 200 - 22, 22, "combat", Category.COMBAT));
        this.windows.add(new Window(Util.mc.method_22683().method_4486() / 2 + 11, 22, "player", Category.PLAYER));
        this.windows.add(new Window(Util.mc.method_22683().method_4486() / 2 - 11 - 100, 22, "render", Category.RENDER));
        for (final Window window : this.windows) {
            window.init(window.getCategory());
        }
    }
    
    public boolean method_25422() {
        return false;
    }
    
    public void method_25394(final class_332 context, final int mouseX, final int mouseY, final float delta) {
        this.method_25420(context, mouseX, mouseY, delta);
        RenderUtil.rect(context.method_51448(), 0.0f, 0.0f, (float)this.field_22789, (float)this.field_22790, ColorUtil.toARGB(0, 0, 0, 150));
        for (final Window window : this.windows) {
            window.draw(context, mouseX, mouseY);
        }
    }
    
    public boolean method_25402(final double mouseX, final double mouseY, final int button) {
        for (final Window window : this.windows) {
            window.processMouseClick((int)mouseX, (int)mouseY, button);
        }
        return super.method_25402(mouseX, mouseY, button);
    }
    
    public boolean method_25406(final double mouseX, final double mouseY, final int button) {
        for (final Window window : this.windows) {
            window.processMouseRelease((int)mouseX, (int)mouseY, button);
        }
        return super.method_25406(mouseX, mouseY, button);
    }
    
    public boolean method_25404(final int keyCode, final int scanCode, final int modifiers) {
        if (keyCode == 256) {
            this.field_22787.method_1507((class_437)null);
            return true;
        }
        for (final Window window : this.windows) {
            window.processKeyPress((char)keyCode, scanCode);
        }
        return super.method_25404(keyCode, scanCode, modifiers);
    }
    
    public static ClickGUI getInstance() {
        if (ClickGUI.INSTANCE == null) {
            ClickGUI.INSTANCE = new ClickGUI();
        }
        return ClickGUI.INSTANCE;
    }
    
    public Set<Window> getWindows() {
        return this.windows;
    }
}
