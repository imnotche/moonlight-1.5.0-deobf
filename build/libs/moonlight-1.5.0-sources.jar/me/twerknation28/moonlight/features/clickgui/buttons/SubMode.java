package me.twerknation28.moonlight.features.clickgui.buttons;

import me.twerknation28.moonlight.util.FontUtil;
import me.twerknation28.moonlight.util.RenderUtil;
import me.twerknation28.moonlight.util.ColorUtil;
import me.twerknation28.moonlight.features.modules.client.NewGui;
import me.twerknation28.moonlight.util.Util;
import net.minecraft.class_1109;
import net.minecraft.class_1113;
import net.minecraft.class_332;
import net.minecraft.class_3417;
import net.minecraft.class_6880;
import me.twerknation28.moonlight.features.settings.Setting;
import me.twerknation28.moonlight.features.clickgui.Window;
import me.twerknation28.moonlight.features.clickgui.BaseButton;

public class SubMode extends BaseButton
{
    private final Button parent;
    private final Window window;
    private final Setting<Enum> option;
    
    public SubMode(final Button parent, final Setting<Enum> option) {
        super(parent.getWindow().getX() + 4, parent.getY() + 4, parent.getWindow().getWidth() - 7, 14);
        parent.getSubEntries().add(this);
        this.parent = parent;
        this.window = parent.getWindow();
        this.option = option;
    }
    
    @Override
    public void processMouseClick(final int mouseX, final int mouseY, final int button) {
        this.updateIsMouseHovered(mouseX, mouseY);
        if (this.isMouseHovered() && this.parent.isOpen()) {
            if (button == 0) {
                final int arrayNumber = this.option.getValue().ordinal() + 1;
                if (arrayNumber != ((Enum[])this.option.getValue().getClass().getEnumConstants()).length) {
                    this.option.setValue(((Enum[])this.option.getValue().getClass().getEnumConstants())[arrayNumber]);
                }
                else {
                    this.option.setValue(((Enum[])this.option.getValue().getClass().getEnumConstants())[0]);
                }
                Util.mc.method_1483().method_4873((class_1113)class_1109.method_47978((class_6880)class_3417.field_15015, 1.0f));
            }
            else if (button == 1) {
                final int arrayNumber = this.option.getValue().ordinal() - 1;
                if (arrayNumber != -1) {
                    this.option.setValue(((Enum[])this.option.getValue().getClass().getEnumConstants())[arrayNumber]);
                }
                else {
                    this.option.setValue(((Enum[])this.option.getValue().getClass().getEnumConstants())[((Enum[])this.option.getValue().getClass().getEnumConstants()).length - 1]);
                }
                Util.mc.method_1483().method_4873((class_1113)class_1109.method_47978((class_6880)class_3417.field_15015, 1.0f));
            }
        }
    }
    
    @Override
    public void draw(final class_332 context, final int mouseX, final int mouseY) {
        this.y = this.window.getRenderYButton();
        this.x = this.window.getX() + 4;
        this.updateIsMouseHovered(mouseX, mouseY);
        RenderUtil.rect(context.method_51448(), (float)this.getX(), (float)this.getY(), (float)(this.getWidth() + this.getX()), (float)(this.getHeight() + this.getY()), ColorUtil.toARGB(NewGui.getInstance().red.getValue(), NewGui.getInstance().green.getValue(), NewGui.getInstance().blue.getValue(), 255));
        RenderUtil.rect(context.method_51448(), (float)this.getX(), (float)this.getY(), (float)(-1 + this.getX()), (float)(this.getHeight() + this.getY()), ColorUtil.toARGB(NewGui.getInstance().red.getValue(), NewGui.getInstance().green.getValue(), NewGui.getInstance().blue.getValue(), 255));
        FontUtil.drawStringWithShadow(this.option.getName().toLowerCase() + ": " + this.option.getValue().name().toLowerCase(), this.getX() + 2, this.getY() + 3, -1, context);
    }
    
    @Override
    public int getColor() {
        return ColorUtil.getColorForGuiEntry(2, this.isMouseHovered(), false);
    }
    
    @Override
    public boolean shouldRender() {
        return this.parent.isOpen() && this.parent.shouldRender() && this.option.isVisible();
    }
    
    public Button getParent() {
        return this.parent;
    }
}
