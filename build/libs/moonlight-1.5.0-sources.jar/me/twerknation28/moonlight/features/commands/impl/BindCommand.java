package me.twerknation28.moonlight.features.commands.impl;

import com.google.common.eventbus.Subscribe;
import me.twerknation28.moonlight.features.settings.Bind;
import me.twerknation28.moonlight.util.KeyboardUtil;
import net.minecraft.class_124;
import me.twerknation28.moonlight.features.Feature;
import me.twerknation28.moonlight.event.impl.KeyEvent;
import me.twerknation28.moonlight.Moonlight;
import me.twerknation28.moonlight.features.modules.Module;
import me.twerknation28.moonlight.features.commands.Command;

public class BindCommand extends Command
{
    private boolean listening;
    private Module module;
    
    public BindCommand() {
        super("bind", new String[] { "<module>" });
        BindCommand.EVENT_BUS.register(this);
    }
    
    @Override
    public void execute(final String[] commands) {
        if (commands.length == 1) {
            Command.sendMessage("Please specify a module.");
            return;
        }
        final String moduleName = commands[0];
        final Module module = Moonlight.moduleManager.getModuleByName(moduleName);
        if (module == null) {
            Command.sendMessage("Unknown module '" + String.valueOf(module) + "'!");
            return;
        }
        Command.sendMessage(String.valueOf(class_124.field_1080) + "Press a key.");
        this.listening = true;
        this.module = module;
    }
    
    @Subscribe
    private void onKey(final KeyEvent event) {
        if (Feature.nullCheck() || !this.listening) {
            return;
        }
        this.listening = false;
        if (event.getKey() == 256) {
            Command.sendMessage(String.valueOf(class_124.field_1080) + "Operation cancelled.");
            return;
        }
        Command.sendMessage("Bind for " + String.valueOf(class_124.field_1060) + this.module.getName() + String.valueOf(class_124.field_1068) + " set to " + String.valueOf(class_124.field_1080) + KeyboardUtil.getKeyName(event.getKey()));
        this.module.bind.setValue(new Bind(event.getKey()));
    }
}
