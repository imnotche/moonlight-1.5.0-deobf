package me.twerknation28.moonlight.features.commands;

import me.twerknation28.moonlight.features.modules.client.Notifications;
import java.util.Objects;
import me.twerknation28.moonlight.util.ChatUtil;
import net.minecraft.class_124;
import net.minecraft.class_2561;
import net.minecraft.class_2583;
import net.minecraft.class_5250;
import net.minecraft.class_5253;
import me.twerknation28.moonlight.features.modules.client.NewGui;
import me.twerknation28.moonlight.Moonlight;
import me.twerknation28.moonlight.features.Feature;

public abstract class Command extends Feature
{
    protected String name;
    protected String[] commands;
    
    public Command(final String name) {
        super(name);
        this.name = name;
        this.commands = new String[] { "" };
    }
    
    public Command(final String name, final String[] commands) {
        super(name);
        this.name = name;
        this.commands = commands;
    }
    
    public static void sendMessage(final String message) {
        final class_5250 prefixText = class_2561.method_43470(Moonlight.commandManager.getClientMessage()).method_10862(class_2583.field_24360.method_36139(class_5253.class_5254.method_27764(255, (int)NewGui.getInstance().red.getValue(), (int)NewGui.getInstance().green.getValue(), (int)NewGui.getInstance().blue.getValue())));
        final class_2561 messageText = (class_2561)class_2561.method_43470(" " + message).method_10862(class_2583.field_24360.method_10977(class_124.field_1080));
        final class_2561 finalMessage = (class_2561)prefixText.method_10852(messageText);
        ChatUtil.send(finalMessage);
    }
    
    public static void toggleMessage(final String module, final Boolean enabling) {
        if (Objects.equals(module, "ClickGui") || Objects.equals(module, "ElytraSwap") || Objects.equals(module, "Phase")) {
            return;
        }
        final class_5250 prefixText = class_2561.method_43470(Moonlight.commandManager.getClientMessage()).method_10862(class_2583.field_24360.method_36139(class_5253.class_5254.method_27764(255, (int)NewGui.getInstance().red.getValue(), (int)NewGui.getInstance().green.getValue(), (int)NewGui.getInstance().blue.getValue())));
        class_2561 finalMessage;
        if (Notifications.getInstance().compact.getValue()) {
            class_5250 openBracket;
            class_5250 toggleSign;
            class_5250 closeBracket;
            if (enabling) {
                openBracket = class_2561.method_43470(" [").method_10862(class_2583.field_24360.method_10977(class_124.field_1077));
                toggleSign = class_2561.method_43470("+").method_10862(class_2583.field_24360.method_10977(class_124.field_1060));
                closeBracket = class_2561.method_43470("]").method_10862(class_2583.field_24360.method_10977(class_124.field_1077));
            }
            else {
                openBracket = class_2561.method_43470(" [").method_10862(class_2583.field_24360.method_10977(class_124.field_1079));
                toggleSign = class_2561.method_43470("-").method_10862(class_2583.field_24360.method_10977(class_124.field_1061));
                closeBracket = class_2561.method_43470("]").method_10862(class_2583.field_24360.method_10977(class_124.field_1079));
            }
            final class_5250 toggleText = openBracket.method_10852((class_2561)toggleSign.method_10852((class_2561)closeBracket));
            final class_2561 messageText = (class_2561)class_2561.method_43470(" " + module).method_10862(class_2583.field_24360.method_10977(class_124.field_1068));
            finalMessage = (class_2561)prefixText.method_10852((class_2561)toggleText.method_10852(messageText));
        }
        else {
            final class_5250 toggleText = class_2561.method_43470(" " + module + " toggled ").method_10862(class_2583.field_24360.method_10977(class_124.field_1080));
            class_5250 enabledText;
            if (enabling) {
                enabledText = class_2561.method_43470("on").method_10862(class_2583.field_24360.method_10977(class_124.field_1060));
            }
            else {
                enabledText = class_2561.method_43470("off").method_10862(class_2583.field_24360.method_10977(class_124.field_1061));
            }
            final class_5250 periodText = class_2561.method_43470(".").method_10862(class_2583.field_24360.method_10977(class_124.field_1080));
            finalMessage = (class_2561)prefixText.method_10852((class_2561)toggleText.method_10852((class_2561)enabledText.method_10852((class_2561)periodText)));
        }
        ChatUtil.send(finalMessage);
    }
    
    public static void visualRangeMessage(final String playerName, final Boolean entering) {
        final class_5250 prefixText = class_2561.method_43470(Moonlight.commandManager.getClientMessage()).method_10862(class_2583.field_24360.method_36139(class_5253.class_5254.method_27764(255, (int)NewGui.getInstance().red.getValue(), (int)NewGui.getInstance().green.getValue(), (int)NewGui.getInstance().blue.getValue())));
        class_5250 openBracket;
        class_5250 toggleSign;
        class_5250 closeBracket;
        if (entering) {
            openBracket = class_2561.method_43470(" [").method_10862(class_2583.field_24360.method_10977(class_124.field_1077));
            toggleSign = class_2561.method_43470("\ud83d\udc41").method_10862(class_2583.field_24360.method_10977(class_124.field_1060));
            closeBracket = class_2561.method_43470("]").method_10862(class_2583.field_24360.method_10977(class_124.field_1077));
        }
        else {
            openBracket = class_2561.method_43470(" [").method_10862(class_2583.field_24360.method_10977(class_124.field_1079));
            toggleSign = class_2561.method_43470("\ud83d\udc41").method_10862(class_2583.field_24360.method_10977(class_124.field_1061));
            closeBracket = class_2561.method_43470("]").method_10862(class_2583.field_24360.method_10977(class_124.field_1079));
        }
        final class_5250 toggleText = openBracket.method_10852((class_2561)toggleSign.method_10852((class_2561)closeBracket));
        final class_2561 messageText = (class_2561)class_2561.method_43470(" " + playerName).method_10862(class_2583.field_24360.method_10977(class_124.field_1068));
        final class_2561 finalMessage = (class_2561)prefixText.method_10852((class_2561)toggleText.method_10852(messageText));
        ChatUtil.send(finalMessage);
    }
    
    public static void enableMessage(final String module) {
        final class_5250 prefixText = class_2561.method_43470(Moonlight.commandManager.getClientMessage()).method_10862(class_2583.field_24360.method_36139(class_5253.class_5254.method_27764(255, (int)NewGui.getInstance().red.getValue(), (int)NewGui.getInstance().green.getValue(), (int)NewGui.getInstance().blue.getValue())));
        class_2561 finalMessage;
        if (Notifications.getInstance().compact.getValue()) {
            final class_5250 openBracket = class_2561.method_43470(" [").method_10862(class_2583.field_24360.method_10977(class_124.field_1077));
            final class_5250 toggleSign = class_2561.method_43470("+").method_10862(class_2583.field_24360.method_10977(class_124.field_1060));
            final class_5250 closeBracket = class_2561.method_43470("]").method_10862(class_2583.field_24360.method_10977(class_124.field_1077));
            final class_5250 toggleText = openBracket.method_10852((class_2561)toggleSign.method_10852((class_2561)closeBracket));
            final class_2561 messageText = (class_2561)class_2561.method_43470(" " + module).method_10862(class_2583.field_24360.method_10977(class_124.field_1068));
            finalMessage = (class_2561)prefixText.method_10852((class_2561)toggleText.method_10852(messageText));
        }
        else {
            final class_5250 toggleText = class_2561.method_43470(" " + module + " toggled ").method_10862(class_2583.field_24360.method_10977(class_124.field_1080));
            final class_5250 enabledText = class_2561.method_43470("on").method_10862(class_2583.field_24360.method_10977(class_124.field_1060));
            final class_5250 periodText = class_2561.method_43470(".").method_10862(class_2583.field_24360.method_10977(class_124.field_1080));
            finalMessage = (class_2561)prefixText.method_10852((class_2561)toggleText.method_10852((class_2561)enabledText.method_10852((class_2561)periodText)));
        }
        ChatUtil.send(finalMessage);
    }
    
    public static void sendSilentMessage(final String message) {
        if (nullCheck()) {
            return;
        }
        Command.mc.field_1705.method_1743().method_1812((class_2561)class_2561.method_43470(message));
    }
    
    public static String getCommandPrefix() {
        return Moonlight.commandManager.getPrefix();
    }
    
    public abstract void execute(final String[] p0);
    
    @Override
    public String getName() {
        return this.name;
    }
    
    public String[] getCommands() {
        return this.commands;
    }
}
