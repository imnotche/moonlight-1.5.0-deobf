package me.twerknation28.moonlight.features.commands.impl;

import me.twerknation28.moonlight.Moonlight;
import me.twerknation28.moonlight.features.commands.Command;
import net.minecraft.class_124;

public class PrefixCommand extends Command
{
    public PrefixCommand() {
        super("prefix", new String[] { "<char>" });
    }
    
    @Override
    public void execute(final String[] commands) {
        if (commands.length == 1) {
            Command.sendMessage(String.valueOf(class_124.field_1060) + "Current prefix is " + Moonlight.commandManager.getPrefix());
            return;
        }
        Moonlight.commandManager.setPrefix(commands[0]);
        Command.sendMessage("Prefix changed to " + String.valueOf(class_124.field_1080) + commands[0]);
    }
}
