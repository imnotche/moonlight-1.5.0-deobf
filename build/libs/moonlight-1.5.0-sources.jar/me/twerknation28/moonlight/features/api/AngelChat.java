package me.twerknation28.moonlight.features.api;

import net.minecraft.class_2561;
import net.minecraft.class_7469;
import net.minecraft.class_7591;
import org.jetbrains.annotations.Nullable;

public interface AngelChat
{
    void invokeAddMessage(final class_2561 p0, @Nullable final class_7469 p1, @Nullable final class_7591 p2);
    
    void angel$remove(final class_7591 p0, final boolean p1);
}
