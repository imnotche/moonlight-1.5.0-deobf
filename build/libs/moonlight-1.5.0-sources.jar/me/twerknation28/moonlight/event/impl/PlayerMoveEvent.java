package me.twerknation28.moonlight.event.impl;

import net.minecraft.class_1313;
import net.minecraft.class_243;

public class PlayerMoveEvent
{
    public class_1313 type;
    public class_243 movement;
    
    public class_1313 getType() {
        return this.type;
    }
    
    public class_243 getMovement() {
        return this.movement;
    }
}
