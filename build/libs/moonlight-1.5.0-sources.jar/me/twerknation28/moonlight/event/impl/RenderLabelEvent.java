package me.twerknation28.moonlight.event.impl;

import me.twerknation28.moonlight.event.Event;
import net.minecraft.class_1297;

public class RenderLabelEvent extends Event
{
    private class_1297 entity;
    
    public RenderLabelEvent(final class_1297 entity) {
    }
    
    public class_1297 getEntity() {
        return this.entity;
    }
}
