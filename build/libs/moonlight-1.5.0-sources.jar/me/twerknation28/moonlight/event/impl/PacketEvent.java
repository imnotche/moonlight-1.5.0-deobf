package me.twerknation28.moonlight.event.impl;

import me.twerknation28.moonlight.manager.NetworkManager;
import net.minecraft.class_2596;
import me.twerknation28.moonlight.event.Event;

public abstract class PacketEvent extends Event
{
    private final class_2596<?> packet;
    
    public PacketEvent(final class_2596<?> packet) {
        this.packet = packet;
    }
    
    public class_2596<?> getPacket() {
        return this.packet;
    }
    
    public static class Receive extends PacketEvent
    {
        public Receive(final class_2596<?> packet) {
            super(packet);
        }
    }
    
    @Cancelable
    public static class Send extends PacketEvent
    {
        private final boolean cached;
        
        public Send(final class_2596<?> packet) {
            super(packet);
            this.cached = NetworkManager.isCached(packet);
        }
        
        public boolean isClientPacket() {
            return this.cached;
        }
    }
}
