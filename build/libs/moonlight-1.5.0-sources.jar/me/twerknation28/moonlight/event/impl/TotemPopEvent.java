package me.twerknation28.moonlight.event.impl;

import me.twerknation28.moonlight.event.Event;
import net.minecraft.class_1657;

public class TotemPopEvent extends Event
{
    private final class_1657 entity;
    private int pops;
    
    public TotemPopEvent(final class_1657 entity, final int pops) {
        this.entity = entity;
        this.pops = pops;
    }
    
    public class_1657 getEntity() {
        return this.entity;
    }
    
    public int getPops() {
        return this.pops;
    }
}
