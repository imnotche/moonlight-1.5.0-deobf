package me.twerknation28.moonlight.event.impl;

import me.twerknation28.moonlight.event.Event;
import net.minecraft.class_4587;

public class Render3DEvent extends Event
{
    private final class_4587 matrix;
    private final float delta;
    
    public Render3DEvent(final class_4587 matrix, final float delta) {
        this.matrix = matrix;
        this.delta = delta;
    }
    
    public class_4587 getMatrix() {
        return this.matrix;
    }
    
    public float getDelta() {
        return this.delta;
    }
    
    public class_4587 getMatrixStack() {
        return this.matrix;
    }
}
