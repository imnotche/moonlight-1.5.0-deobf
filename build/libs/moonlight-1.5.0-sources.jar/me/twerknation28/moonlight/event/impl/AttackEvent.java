package me.twerknation28.moonlight.event.impl;

import me.twerknation28.moonlight.event.Event;
import net.minecraft.class_1297;

public class AttackEvent extends Event
{
    boolean pre;
    private final class_1297 entity;
    
    public AttackEvent(final class_1297 entity, final boolean pre) {
        this.entity = entity;
        this.pre = pre;
    }
    
    public class_1297 getEntity() {
        return this.entity;
    }
    
    public boolean isPre() {
        return this.pre;
    }
}
