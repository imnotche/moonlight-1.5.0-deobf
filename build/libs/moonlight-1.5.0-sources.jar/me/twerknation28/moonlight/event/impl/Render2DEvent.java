package me.twerknation28.moonlight.event.impl;

import me.twerknation28.moonlight.event.Event;
import net.minecraft.class_332;

public class Render2DEvent extends Event
{
    private final class_332 context;
    private final float delta;
    
    public Render2DEvent(final class_332 context, final float delta) {
        this.context = context;
        this.delta = delta;
    }
    
    public class_332 getContext() {
        return this.context;
    }
    
    public float getDelta() {
        return this.delta;
    }
}
